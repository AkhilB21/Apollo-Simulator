"""Two-Layer Bucket Classifier for Apollo Backtest Engine.

Data-driven 5-bucket classification using 3 primary metrics validated
across 759 NSE stocks (2-year analysis):

  Primary metrics (r > 0.62 with forward returns):
    1. 200 DMA Slope (annualized %)         — r = 0.675
    2. 50 DMA vs 200 DMA gap (%)             — r = 0.639
    3. 6-Month Return (%)                     — r = 0.628

Architecture
------------
  Layer 1 — Stock classification (computed ONCE before scoring loop):
    - Classifies the stock into one of 7 buckets for DISPLAY purposes.
    - As of v3.4.1, NO stock is ever skipped — every stock reaches the
      Apollo engine with its raw score intact. The bucket is a label,
      not a gate. The 21-signal system itself is the quality filter:
      a "Structural Decline" stock will naturally score low (RSI troughs
      won't fire, recovery momentum won't trigger, etc.) and never reach
      the 70-point entry threshold.

  Layer 2 — Per-bar classification + score modifier (RECORDED, NOT APPLIED):
    - Runs inside the scoring loop on each daily bar.
    - Classifies into one of 5 actionable buckets.
    - Returns a score multiplier that is RECORDED alongside the raw score
      for transparency, but NEVER APPLIED. `total = raw_total` always.
        - Trending Up:              multiplier 0.95  (slight dampen —
                                     works on pullbacks, not core thesis)
        - Recovery — Strengthening: multiplier 1.05  (bonus — confirmed
                                     structure + Apollo recovery)
        - Recovery — Early:         multiplier 1.00  (native — primary
                                     Apollo hunting ground)
        - Weak / Beaten Down:       multiplier 0.70  (penalty — too
                                     early, selling may resume)
        - Range-Bound:              multiplier 0.50  (heavy penalty —
                                     false signal zone)
        - Structural Decline:       multiplier 0.00  (blocked by Layer 1,
                                     but if somehow reached, zero out)

  Note: Layer 2 multipliers are gentle (except Weak/Range).  The scoring
  engine's own 21-signal system is the primary quality gate.  Buckets
  provide *contextual adjustment*, not a replacement for signal quality.

Functions
---------
  compute_bucket_metrics    — compute the 3 primary metrics from daily OHLC
  classify_stock_bucket     — classify a stock into a bucket (reference only)
  classify_bucket           — classify a single bar into a bucket (Layer 2)
  get_score_multiplier      — map bucket → score multiplier (recorded, not applied)
  BUCKET_DEFS               — dict of bucket metadata (colour, description, etc.)

NOTE: As of v3.4.1, the bucket classifier is REFERENCE-ONLY. Every stock
reaches the Apollo engine with its raw score intact. The bucket is recorded
for display in the UI and used for colour-coding, but NEVER used to skip
scoring. The `should_skip` return value has been removed.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


# ═══════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════

BUCKET_ORDER = [
    "Trending Up",
    "Recovery — Strengthening",
    "Recovery — Early",
    "Weak / Beaten Down",
    "Range-Bound",
    "Structural Decline",
    "IPO / New Listing",
    "Unclassified",
]

# Score multiplier per bucket — applied to raw Apollo total score
SCORE_MULTIPLIERS = {
    "Trending Up":              0.95,
    "Recovery — Strengthening": 1.05,
    "Recovery — Early":         1.00,
    "Weak / Beaten Down":       0.70,
    "Range-Bound":              0.50,
    "Structural Decline":       0.00,
    "IPO / New Listing":        1.00,  # IPO scores are pre-normalized; no extra multiplier
    "Unclassified":             0.80,
}

# Pre-filter: skip scoring entirely for these buckets
SKIP_BUCKETS = {"Structural Decline", "Range-Bound"}

# Colour coding for UI display
BUCKET_COLOURS = {
    "Trending Up":              "#22c55e",
    "Recovery — Strengthening": "#3b82f6",
    "Recovery — Early":         "#f59e0b",
    "Weak / Beaten Down":       "#f97316",
    "Range-Bound":              "#8b5cf6",
    "Structural Decline":       "#ef4444",
    "IPO / New Listing":        "#06b6d4",  # cyan — distinct from all other buckets
    "Unclassified":             "#6b7280",
}

# Short descriptions for UI tooltips
BUCKET_DESC = {
    "Trending Up": (
        "200 DMA rising (>5%/yr), price above 200 DMA, 6M return > 0%. "
        "Confirmed uptrend — Apollo works on pullbacks within the trend."
    ),
    "Recovery — Strengthening": (
        "200 DMA slope >= 0%, 50 DMA > 200 DMA, 6M return > -15%. "
        "Golden cross territory — structural recovery confirmed."
    ),
    "Recovery — Early": (
        "200 DMA slope > -15%, 50-200 gap > -8%, 6M return > -15% "
        "(but slope < 0 or 50 < 200). Early recovery — Apollo's PRIMARY target."
    ),
    "Weak / Beaten Down": (
        "200 DMA falling, price >10% below it, 6M return < 0%, new-low rate <= 10%. "
        "Selling exhaustion — too early for entry but not dead."
    ),
    "Range-Bound": (
        "|200 DMA slope| < 5%, ADX < 20, |6M return| < 15%. "
        "No trend — generates false RSI signals."
    ),
    "Structural Decline": (
        "200 DMA slope < -15%, 50 DMA > 8% below 200 DMA, 6M return < -15%. "
        "Death spiral — capital destruction."
    ),
    "Unclassified": (
        "Does not fit any bucket cleanly. Review individually."
    ),
    "IPO / New Listing": (
        "Insufficient trading history (<60 days) for 200-DMA or trough "
        "detection. Scored via dedicated IPO profile (12 momentum/structure/"
        "volume signals) and normalized to the 0-100 scale."
    ),
}

# Apollo relevance labels
BUCKET_APOLLO_FIT = {
    "Trending Up":              "Secondary",
    "Recovery — Strengthening": "Strong Fit",
    "Recovery — Early":         "Primary Target",
    "Weak / Beaten Down":       "Watch Only",
    "Range-Bound":              "Avoid",
    "Structural Decline":       "Avoid",
    "IPO / New Listing":        "IPO Profile",
    "Unclassified":             "Review",
}

# Data-driven thresholds (validated on 759 NSE stocks, 2-year data)
THRESHOLDS = {
    # Structural Decline: all three must be true
    "decline_slope_max":      -15.0,   # 200 DMA slope more negative than this
    "decline_dma_gap_max":    -8.0,    # 50 DMA more than 8% below 200 DMA
    "decline_ret6m_max":      -15.0,   # 6M return worse than -15%

    # Weak / Beaten Down
    "weak_slope_max":          0.0,    # 200 DMA must be declining
    "weak_vs_dma_max":        -10.0,   # price > 10% below 200 DMA
    "weak_ret6m_max":          0.0,    # 6M return negative
    "weak_newlow_max":        10.0,    # new-low rate <= 10% (selling exhaustion)

    # Recovery zone (shared between Early and Strengthening)
    "recovery_slope_min":     -15.0,   # 200 DMA slope not steeper than -15%
    "recovery_dma_gap_min":   -8.0,    # 50-200 gap not wider than -8%
    "recovery_ret6m_min":     -15.0,   # 6M return not worse than -15%

    # Trending Up
    "trend_slope_min":         5.0,    # 200 DMA rising > 5% annualized
    "trend_vs_dma_min":        0.0,    # price above 200 DMA
    "trend_ret6m_min":         0.0,    # positive 6M return

    # Range-Bound
    "range_slope_max":         5.0,    # |slope| < 5%
    "range_adx_max":          20.0,    # weak trend strength
    "range_ret6m_max":        15.0,    # |6M return| < 15%
}

# Bundle all metadata into a single dict for easy import
BUCKET_DEFS = {
    name: {
        "colour": BUCKET_COLOURS.get(name, "#6b7280"),
        "multiplier": SCORE_MULTIPLIERS.get(name, 0.80),
        "apollo_fit": BUCKET_APOLLO_FIT.get(name, "Review"),
        "description": BUCKET_DESC.get(name, ""),
    }
    for name in BUCKET_ORDER
}


# ═══════════════════════════════════════════════════════════════════════════
# Metric Computation
# ═══════════════════════════════════════════════════════════════════════════

def _dma_slope_annualized(dma_series: pd.Series) -> pd.Series:
    """Compute annualized slope (%) of a DMA series.

    Uses a 20-day linear regression slope, annualized by multiplying
    by 252 (trading days/year).

    Returns a series of the same length, with NaN where insufficient data.
    """
    window = 20
    slope = dma_series.diff(window) / window  # per-day change
    annualized = slope * 252.0 * 100.0 / dma_series.shift(window)
    return annualized


def compute_bucket_metrics(df_d: pd.DataFrame) -> dict[str, pd.Series]:
    """Compute the 3 primary bucket classification metrics from daily data.

    Parameters
    ----------
    df_d : pd.DataFrame
        Daily OHLCV data (must have 'close', 'high', 'low' columns).
        Should include at least 250+ rows for 200 DMA warmup.

    Returns
    -------
    dict with keys:
        "dma200"          — 200-day SMA of close
        "dma50"           — 50-day SMA of close
        "dma200_slope"    — annualized slope of 200 DMA (%)
        "dma50_vs_dma200" — (DMA50 - DMA200) / DMA200 * 100 (%)
        "vs_dma200"       — (close - DMA200) / DMA200 * 100 (%)
        "ret_6m"          — 6-month return (%)
        "adx"             — ADX (14-period), from df_d if available
        "new_low_rate"    — % of last 126 bars hitting 126-day low
    """
    close = df_d["close"]

    dma200 = close.rolling(window=200, min_periods=200).mean()
    dma50 = close.rolling(window=50, min_periods=50).mean()
    dma200_slope = _dma_slope_annualized(dma200)
    dma50_vs_dma200 = (dma50 - dma200) / dma200 * 100.0
    vs_dma200 = (close - dma200) / dma200 * 100.0
    ret_6m = close.pct_change(periods=126) * 100.0

    # New-low rate: % of last 126 bars that hit a 126-day low
    rolling_min_126 = close.rolling(window=126, min_periods=126).min()
    is_new_low = close <= rolling_min_126
    new_low_rate = is_new_low.rolling(window=126, min_periods=50).mean() * 100.0

    # ADX — use pre-computed if available (from indicators.py), else compute
    if "adx" in df_d.columns:
        adx = df_d["adx"]
    else:
        # Fallback: import and compute
        try:
            from apollo_core.indicators import compute_adx
            _, _, adx = compute_adx(df_d, 14)
        except Exception:
            adx = pd.Series(np.nan, index=df_d.index)

    return {
        "dma200": dma200,
        "dma50": dma50,
        "dma200_slope": dma200_slope,
        "dma50_vs_dma200": dma50_vs_dma200,
        "vs_dma200": vs_dma200,
        "ret_6m": ret_6m,
        "adx": adx,
        "new_low_rate": new_low_rate,
    }


# ═══════════════════════════════════════════════════════════════════════════
# Stock Classification (reference-only — NEVER used as a gate)
# ═══════════════════════════════════════════════════════════════════════════
# As of v3.4.1, the bucket classifier is REFERENCE-ONLY.  Every stock reaches
# the Apollo engine with its raw score intact.  The bucket is recorded for
# display in the UI and used for colour-coding, but NEVER used to skip a
# stock from scoring.  See "BUCKET IS REFERENCE-ONLY" guard in trade_engine.py.
#
# The `SKIP_BUCKETS` set is retained for UI colour-coding only; the `should_skip`
# return value has been removed from this function.
# ═══════════════════════════════════════════════════════════════════════════

def classify_stock_bucket(
    df_d: pd.DataFrame,
    lookback_bars: int = 250,
    min_trading_days: int = 60,
) -> tuple[str, dict]:
    """Classify a stock into a bucket for DISPLAY purposes only.

    Evaluates the LAST `lookback_bars` bars of daily data to determine
    which bucket the stock falls into.  The bucket is recorded alongside
    the stock's raw Apollo score — it is NEVER used to skip scoring.

    IPO Detection
    -------------
    If the daily DataFrame has fewer than `min_trading_days` rows, the stock
    is classified as "IPO / New Listing" immediately.  It is then scored via
    the dedicated IPO signal profile in the backtest engine and its score
    normalized to 0-100.

    Parameters
    ----------
    df_d : pd.DataFrame
        Daily OHLCV data (must have 'close' column).
    lookback_bars : int
        Number of trailing bars to evaluate. Default 250 (~1 year).
    min_trading_days : int
        Minimum rows for a stock to be treated as "mature".
        Below this → IPO / New Listing bucket.

    Returns
    -------
    (bucket, metrics)
        bucket : str
            The bucket name (e.g. "Trending Up", "Recovery — Early",
            "Structural Decline", "IPO / New Listing", "Unclassified").
        metrics : dict
            The 3 primary metric values at the last bar (for display).
    """
    # ── IPO gate: check BEFORE trying to compute 200-DMA ──
    if len(df_d) < min_trading_days:
        return "IPO / New Listing", {
            "n_bars": len(df_d),
            "min_required": min_trading_days,
        }

    if len(df_d) < 200:
        # Not enough data for 200 DMA — cannot classify
        return "Unclassified", {}

    metrics = compute_bucket_metrics(df_d)

    # Evaluate at the last available bar
    slope = metrics["dma200_slope"].iloc[-1]
    dma_gap = metrics["dma50_vs_dma200"].iloc[-1]
    ret6m = metrics["ret_6m"].iloc[-1]
    vs_dma = metrics["vs_dma200"].iloc[-1]
    adx = metrics["adx"].iloc[-1]
    new_low = metrics["new_low_rate"].iloc[-1]

    # Handle NaN
    slope = slope if not np.isnan(slope) else 0.0
    dma_gap = dma_gap if not np.isnan(dma_gap) else 0.0
    ret6m = ret6m if not np.isnan(ret6m) else 0.0
    vs_dma = vs_dma if not np.isnan(vs_dma) else 0.0
    adx = adx if not np.isnan(adx) else 25.0  # default to moderate
    new_low = new_low if not np.isnan(new_low) else 5.0

    # Classify (reference only — never skips)
    bucket = _classify_by_values(slope, dma_gap, ret6m, vs_dma, adx, new_low)

    display_metrics = {
        "dma200_slope": round(slope, 2),
        "dma50_vs_dma200": round(dma_gap, 2),
        "ret_6m": round(ret6m, 2),
        "vs_dma200": round(vs_dma, 2),
        "adx": round(adx, 2),
        "new_low_rate": round(new_low, 2),
    }

    return bucket, display_metrics


# Backward-compat alias (deprecated — use classify_stock_bucket)
def pre_filter_bucket(df_d, lookback_bars=250, min_trading_days=60):
    """DEPRECATED — use classify_stock_bucket. Returns (False, bucket, metrics)
    for backward compatibility with any caller expecting the old 3-tuple.
    The should_skip value is always False because buckets are reference-only.
    """
    bucket, metrics = classify_stock_bucket(df_d, lookback_bars, min_trading_days)
    return False, bucket, metrics


# ═══════════════════════════════════════════════════════════════════════════
# Layer 2: Per-Bar Classification
# ═══════════════════════════════════════════════════════════════════════════

def _classify_by_values(
    slope: float,
    dma_gap: float,
    ret6m: float,
    vs_dma: float,
    adx: float,
    new_low: float,
) -> str:
    """Pure-function classifier from metric values to bucket name.

    Uses the data-driven thresholds from the 759-stock analysis.
    Order matters: more specific buckets are checked first.
    """
    T = THRESHOLDS

    # ── 1. Structural Decline (most specific — strictest criteria) ──
    if (slope < T["decline_slope_max"]
            and dma_gap < T["decline_dma_gap_max"]
            and ret6m < T["decline_ret6m_max"]):
        return "Structural Decline"

    # ── 2. Trending Up (clear uptrend) ──
    if (slope > T["trend_slope_min"]
            and vs_dma > T["trend_vs_dma_min"]
            and ret6m > T["trend_ret6m_min"]):
        return "Trending Up"

    # ── 3. Weak / Beaten Down ──
    if (slope < T["weak_slope_max"]
            and vs_dma < T["weak_vs_dma_max"]
            and ret6m < T["weak_ret6m_max"]
            and new_low <= T["weak_newlow_max"]):
        return "Weak / Beaten Down"

    # ── 4. Range-Bound (no trend) ──
    if (abs(slope) < T["range_slope_max"]
            and adx < T["range_adx_max"]
            and abs(ret6m) < T["range_ret6m_max"]):
        return "Range-Bound"

    # ── 5. Recovery zone (split into Strengthening vs Early) ──
    if (slope > T["recovery_slope_min"]
            and dma_gap > T["recovery_dma_gap_min"]
            and ret6m > T["recovery_ret6m_min"]):
        if slope > 0 and dma_gap > 0:
            return "Recovery — Strengthening"
        else:
            return "Recovery — Early"

    # ── 6. Fallback ──
    # If none matched but stock isn't in a clear bad zone, default to
    # Weak / Beaten Down if bearish indicators present
    if slope < -5 and ret6m < -10:
        return "Weak / Beaten Down"

    return "Unclassified"


def classify_bucket(metrics: dict[str, pd.Series], bar_pos: int) -> str:
    """Layer 2: Classify a single bar into a bucket.

    Parameters
    ----------
    metrics : dict[str, pd.Series]
        Output from ``compute_bucket_metrics()``.
    bar_pos : int
        Integer position in the DataFrame.

    Returns
    -------
    str — bucket name from BUCKET_ORDER.
    """
    def _safe(series, pos, default=0.0):
        val = series.iloc[pos]
        return val if not np.isnan(val) else default

    slope = _safe(metrics["dma200_slope"], bar_pos)
    dma_gap = _safe(metrics["dma50_vs_dma200"], bar_pos)
    ret6m = _safe(metrics["ret_6m"], bar_pos)
    vs_dma = _safe(metrics["vs_dma200"], bar_pos)
    adx = _safe(metrics["adx"], bar_pos, default=25.0)
    new_low = _safe(metrics["new_low_rate"], bar_pos, default=5.0)

    return _classify_by_values(slope, dma_gap, ret6m, vs_dma, adx, new_low)


def get_score_multiplier(bucket: str) -> float:
    """Map a bucket name to its score multiplier.

    This multiplier is applied to the raw Apollo total score before
    the entry/exit threshold comparison.
    """
    return SCORE_MULTIPLIERS.get(bucket, 0.80)
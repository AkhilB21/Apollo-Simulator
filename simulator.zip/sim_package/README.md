# Apollo Indicator-Exit Simulator

Extended version of the apollo guidance_engine backtest that adds an
`INDICATOR_SL` exit mode (indicator-based exit + disaster stop-loss backstop).

## Files

- `apollo_integration/` — engine copy with INDICATOR_SL mode added to
  `apollo_core/trade_engine.py`, `apollo_core/types.py`,
  `backtest_engine/backtest.py`.
- `scripts/indicator_engine_test.py` — engine-based sweep (gap-aware fills).
- `scripts/indicator_sweep_consistent.py` — consistent close-to-close metric,
  reproduces recorded baseline (FIXED_SL 5% = n=79, +309.9%).
- `scripts/walk_forward_indicator.py` — config selected on prior data only,
  evaluated out-of-sample (the honest test).
- `scripts/regime_analysis.py` — drawdown-regime analysis (no VIX available).
- `data/apollo.csv` — 2018-01-22 to 2026-08-04 daily OHLCV+indicators.

## Usage

    python3 scripts/indicator_sweep_consistent.py
    python3 scripts/walk_forward_indicator.py
    python3 scripts/regime_analysis.py

## Key results (close-to-close metric)

- Baseline: FIXED_SL 5% = n=79, +309.9%; FIXED_SL 20% = +1043.7%.
- Full-period best: RSI_SAT + disaster 20% = +1294.6%.
- Walk-forward (selected on prior data): advantage over SL20% does not
  survive; config selection is unstable across folds (RSI_SAT vs MACD_HIST).
- Regime analysis: null result — trades entered in >20% corrections earn
  the same as bull entries.

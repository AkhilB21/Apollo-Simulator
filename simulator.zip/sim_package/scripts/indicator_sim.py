import sys
sys.path.insert(0, '/tmp/opencode/apollo4101/apollo_integration')

import pandas as pd
import numpy as np
from backtest_engine.backtest import run_stock_backtest
from backtest_engine.eod2_loader import load_eod2_stock

DATA = '/tmp/opencode/apollo_data_bt'
SYM = 'apollo'
START = '2018-01-22'
END = '2026-08-04'
ENTRY_TH = 70
EXIT_TH = 50

df_d, _, _ = load_eod2_stock(DATA, SYM)
close = df_d['close'].values
open_ = df_d['open'].values
high = df_d['high'].values
idx = pd.DatetimeIndex(df_d.index)
n = len(df_d)

# Engine-produced daily_results (score, rsi21, action) — same entry signal source
r = run_stock_backtest(data_dir=DATA, symbol=SYM, start_date=START, end_date=END,
                       exit_mode='FIXED_SL', sl_percent=5.0, entry_threshold=ENTRY_TH,
                       exit_threshold=EXIT_TH)
dr = pd.DataFrame(r['daily_results'])
dr['date'] = pd.to_datetime(dr['date'])
dr['close'] = df_d['close'].reindex(dr['date']).values
dr['rsi21'] = df_d['rsi21'].reindex(dr['date']).values
dr['total'] = dr['total'].values
# bar-level extras from df_d
for col in ['plus_di', 'minus_di', 'sma20', 'sma50', 'macd', 'macd_sig', 'adx', 'stoch_k', 'stoch_d']:
    if col in df_d.columns:
        dr[col] = df_d[col].reindex(dr['date']).values

pos_index = {pd.Timestamp(d): i for i, d in enumerate(idx)}
bars = [None] * len(dr)
for i in range(len(dr)):
    date = dr['date'].iloc[i]
    j = pos_index.get(date)
    if j is None:
        continue
    bars[i] = j


def simulate(exit_cfg, sl_pct, cooldown=5, divergence_drop=3.0):
    """Custom simulator faithful to engine conventions.
    exit_cfg: dict describing exit rules.
      - 'mode': 'FIXED_SL' | 'INDICATOR' | 'HYBRID'
      - 'indicator': 'DI' | 'SMA20' | 'SMA50' | 'MACD' | 'ADX' | 'RSI_SAT' | 'STOCH'
      - 'disaster_sl': float pct (0 = none)
      - 'trail': bool
    Entry: score>=70, fill at close. Exit priority matches engine.
    """
    entries = []
    exits = []
    in_trade = False
    entry_price = 0.0
    entry_date = None
    peak_rsi = None
    peak_rsi_price = None
    prev_plus_di = None
    prev_minus_di = None
    cooldown_until = -1

    for i in range(len(dr)):
        date = dr['date'].iloc[i]
        total = float(dr['total'].iloc[i])
        c = float(dr['close'].iloc[i])
        j = pos_index[date]
        o = float(open_[j])
        rsi = float(dr['rsi21'].iloc[i])
        cur_plus_di = dr['plus_di'].iloc[i] if 'plus_di' in dr.columns else np.nan
        cur_minus_di = dr['minus_di'].iloc[i] if 'minus_di' in dr.columns else np.nan

        if in_trade:
            if c > peak_close:
                peak_close = c
            if peak_rsi is not None and rsi > peak_rsi:
                peak_rsi = rsi
                peak_rsi_price = high[pos_index[date]]

            # --- exit detection (engine priority order) ---
            reasons = []
            fill = None
            # 1. disaster SL / hard SL
            if sl_pct > 0:
                sl_price = entry_price * (1 - sl_pct / 100.0)
                if c <= sl_price or o <= sl_price:
                    fill = min(o, sl_price)
                    reasons.append('SL')
            # 2. indicator exit
            if fill is None and exit_cfg.get('indicator'):
                ind = exit_cfg['indicator']
                hit = False
                if ind == 'DI':
                    if (prev_plus_di is not None and prev_minus_di is not None
                            and not np.isnan(cur_plus_di) and not np.isnan(cur_minus_di)
                            and prev_plus_di > prev_minus_di and cur_plus_di < cur_minus_di):
                        hit = True
                elif ind == 'SMA20':
                    if i > 0 and 'sma20' in dr.columns and not np.isnan(dr['sma20'].iloc[i]):
                        hit = c < dr['sma20'].iloc[i]
                elif ind == 'SMA50':
                    if 'sma50' in dr.columns and not np.isnan(dr['sma50'].iloc[i]):
                        hit = c < dr['sma50'].iloc[i]
                elif ind == 'MACD':
                    if 'macd' in dr.columns and 'macd_sig' in dr.columns and not np.isnan(dr['macd'].iloc[i]):
                        hit = dr['macd'].iloc[i] < dr['macd_sig'].iloc[i]
                elif ind == 'ADX':
                    if 'adx' in dr.columns and not np.isnan(dr['adx'].iloc[i]):
                        hit = dr['adx'].iloc[i] < 20
                elif ind == 'RSI_SAT':
                    hit = rsi > 85 or rsi < 40
                elif ind == 'STOCH':
                    if 'stoch_k' in dr.columns and not np.isnan(dr['stoch_k'].iloc[i]):
                        hit = dr['stoch_k'].iloc[i] < 20
                if hit:
                    fill = c
                    reasons.append(ind)
            # 3. divergence
            if fill is None:
                if (peak_rsi is not None and peak_rsi_price is not None
                        and c > peak_rsi_price and rsi < (peak_rsi - divergence_drop)):
                    fill = c
                    reasons.append('DIV')
            # 4. score exit
            if fill is None and total < EXIT_TH:
                fill = c
                reasons.append('SCORE')
            # 5. trailing
            if fill is None and exit_cfg.get('trail'):
                if peak_close is not None:
                    trail_price = peak_close * 0.95
                    if c <= trail_price or o <= trail_price:
                        fill = min(o, trail_price)
                        reasons.append('TRAIL')

            if reasons:
                exits.append({'entry_date': entry_date, 'exit_date': date,
                              'ret': fill / entry_price - 1, 'reason': reasons[0]})
                in_trade = False
                cooldown_until = i + cooldown
                entry_price = 0.0
            prev_plus_di = cur_plus_di
            prev_minus_di = cur_minus_di
            continue

        # --- entry ---
        if not in_trade and total >= ENTRY_TH and i >= cooldown_until:
            in_trade = True
            entry_price = c
            entry_date = date
            peak_rsi = rsi
            peak_rsi_price = high[pos_index[date]]
            peak_close = c
            entries.append(date)

        prev_plus_di = cur_plus_di
        prev_minus_di = cur_minus_di

    if in_trade:
        exits.append({'entry_date': entry_date, 'exit_date': dr['date'].iloc[-1],
                      'ret': close[-1] / entry_price - 1, 'reason': 'PERIOD_END'})
    return entries, exits


def summarize(exits):
    if not exits:
        return 'n=0'
    rets = np.array([e['ret'] for e in exits])
    comp = np.prod(1 + rets) - 1
    win = (rets > 0).mean() * 100
    from collections import Counter
    reasons = Counter(e['reason'] for e in exits)
    return f"n={len(rets)} comp={comp*100:+7.1f}% win={win:.0f}%  reasons={dict(reasons)}"


# ===== VALIDATION: must reproduce engine FIXED_SL 5% exactly =====
_, exits = simulate({'mode': 'FIXED_SL'}, sl_pct=5.0)
# engine reference
r5 = run_stock_backtest(data_dir=DATA, symbol=SYM, start_date=START, end_date=END,
                        exit_mode='FIXED_SL', sl_percent=5.0, entry_threshold=ENTRY_TH,
                        exit_threshold=EXIT_TH)
eng = []
for c in r5['completed']:
    ei = pos_index.get(pd.Timestamp(c['entry_date'])); xi = pos_index.get(pd.Timestamp(c['date']))
    if xi is not None and xi > ei:
        eng.append(close[xi] / close[ei] - 1)
eng = np.array(eng)
mine = np.array([e['ret'] for e in exits])
print('VALIDATION (FIXED_SL 5%):')
print(f'  engine: n={len(eng)} comp={np.prod(1+eng)-1:.4f}')
print(f'  mine:   n={len(mine)} comp={np.prod(1+mine)-1:.4f}')
print(f'  match within tol: {np.allclose(np.sort(eng), np.sort(mine), atol=1e-6)}')

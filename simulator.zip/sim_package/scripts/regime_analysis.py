import sys, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, '/tmp/opencode/apollo4101/apollo_integration')
import pandas as pd
import numpy as np
from backtest_engine.eod2_loader import load_eod2_stock

DATA='/tmp/opencode/apollo_data_bt'; SYM='apollo'
df_d,_,_ = load_eod2_stock(DATA,SYM)
close=df_d['close'].values
high=df_d['high'].values
idx=pd.DatetimeIndex(df_d.index)

# Regime proxy: drawdown of close from rolling 60d high of high
roll_high = pd.Series(high, index=idx).rolling(60, min_periods=20).max()
dd = pd.Series(close, index=idx)/roll_high - 1
ddf = dd.to_frame('dd')

# Tag regime by dd threshold
def regime_tag(dd):
    if dd <= -0.20: return 'CRASH(>20% dd)'
    if dd <= -0.10: return 'BEAR(10-20% dd)'
    if dd <= -0.05: return 'CORR(5-10% dd)'
    return 'BULL(<5% dd)'
ddf['regime']=ddf['dd'].map(regime_tag)
ddf['date']=idx

# Time spent and forward returns per regime
print('=== Time distribution & 20d forward return by drawdown regime ===')
ddf['fwd20'] = np.nan
c = close
for i in range(len(ddf)-20):
    ddf.iloc[i, ddf.columns.get_loc('fwd20')] = c[i+20]/c[i]-1

for reg, grp in ddf.groupby('regime'):
    n=len(grp)
    pct=n/len(ddf)*100
    fw=grp['fwd20'].mean()*100
    # P(enter trade here) proxy
    print(f'  {reg:18s}: {pct:5.1f}% of days (n={n:4d})  20d fwd mean {fw:+6.1f}%')

# Which regimes did engine trades live in? Recompute with current engine from trades
print('\n=== Regime at TRADE ENTRY (FIXED_SL 20%) ===')
from backtest_engine.backtest import run_stock_backtest
r = run_stock_backtest(data_dir=DATA,symbol=SYM,start_date='2018-01-22',end_date='2026-08-04',
                       exit_mode='FIXED_SL',sl_percent=20.0,entry_threshold=70,exit_threshold=50)
from collections import Counter
ent_reg=Counter(); exc=[]
for e in r['entries']:
    d=pd.Timestamp(e['date'])
    ent_reg[regime_tag(dd.loc[d])]+=1
for reg,cnt in ent_reg.most_common():
    print(f'  {reg:18s}: {cnt}')
# per-trade max DD experienced inside trade (from entry, use low)
print('\n=== Per-trade max drawdown vs regime (FIXED_SL 20%) ===')
for c_ in r['completed']:
    ei=idx.get_indexer([pd.Timestamp(c_['entry_date'])],method='nearest')[0]
    xi=idx.get_indexer([pd.Timestamp(c_['date'])],method='nearest')[0]
    low_seg=df_d['low'].iloc[ei:xi+1]
    mdd=(low_seg.min()/c_['entry_price']-1)*100 if low_seg.min()>0 else -99
    exc.append((regime_tag(dd.iloc[ei]), c_['pnl'], mdd, (xi-ei)))
exdf=pd.DataFrame(exc,columns=['regime','pnl','mdd','hold'])
print(exdf.groupby('regime').agg(n=('pnl','size'), avg_pnl=('pnl','mean'),
                                 avg_mdd=('mdd','mean'), avg_hold=('hold','mean')))

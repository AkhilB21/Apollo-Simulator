import sys, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, '/tmp/opencode/apollo4101/apollo_integration')
import numpy as np
from backtest_engine.backtest import run_stock_backtest

DATA='/tmp/opencode/apollo_data_bt'; SYM='apollo'
S='2018-01-22'; E='2026-08-04'

def kpis(r):
    c=r['completed']
    rets=np.array([e['pnl'] for e in c])/100.0
    comp=np.prod(1+rets)-1 if len(rets) else 0
    n=len(c)
    yrs=8.54
    ann=(1+comp)**(1/yrs)-1 if comp>-1 else float('-inf')
    win=(np.mean(rets>0)*100) if n else 0
    tm=0
    # time in market
    from collections import Counter
    reasons=Counter()
    for e in r['trades']:
        if e['type']!='EXIT': continue
        for k in ['HARD_SL','TRAILING_SL','DIVERGENCE','INDICATOR_','SCORE<','DI_CROSSOVER','PERIOD_END']:
            if k in e.get('exit_reason',''):
                reasons[k]=reasons.get(k,0)+1
                break
    return f"n={n:3d} comp={comp*100:+7.1f}% ann={ann*100:+6.1f}% win={win:4.1f}%  {dict(reasons)}"

# ===== VALIDATION 1: modified engine must reproduce FIXED_SL baseline =====
base = run_stock_backtest(data_dir=DATA,symbol=SYM,start_date=S,end_date=E,
                          exit_mode='FIXED_SL',sl_percent=5.0,entry_threshold=70,exit_threshold=50)
print('FIXED_SL 5% (baseline, must be n=79 comp~+310%):')
print(' ', kpis(base))

# ===== SWEEP: INDICATOR_SL modes with disaster SL backstops =====
print()
print('INDICATOR_SL sweep (disaster SL = sl_percent backstop, indicator exit on top):')
modes = [
    ('SMA20',), ('SMA50',), ('MACD',), ('MACD_HIST',), ('ADX',),
    ('RSI_SAT',), ('STOCH',), ('DI',),
]
for ind in modes:
    for sl in (15.0, 20.0, 25.0):
        r = run_stock_backtest(data_dir=DATA,symbol=SYM,start_date=S,end_date=E,
                               exit_mode='INDICATOR_SL',sl_percent=sl,
                               entry_threshold=70,exit_threshold=50,indicator_exit=ind[0])
        print(f"  {ind[0]:10s} +disasterSL {sl:4.1f}% : {kpis(r)}")

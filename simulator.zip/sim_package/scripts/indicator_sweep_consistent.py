import sys, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, '/tmp/opencode/apollo4101/apollo_integration')
import pandas as pd
import numpy as np
from backtest_engine.backtest import run_stock_backtest
from backtest_engine.eod2_loader import load_eod2_stock

DATA='/tmp/opencode/apollo_data_bt'; SYM='apollo'
START='2018-01-22'; END='2026-08-04'

df_d,_,_ = load_eod2_stock(DATA,SYM)
close=df_d['close'].values
idx=pd.DatetimeIndex(df_d.index)

def iof(dt):
    return idx.get_indexer([pd.Timestamp(dt)], method='nearest')[0]

def trades_for(exit_mode, sl, indicator_exit='', start=START, end=END):
    r = run_stock_backtest(data_dir=DATA,symbol=SYM,start_date=start,end_date=end,
                           exit_mode=exit_mode,sl_percent=sl,
                           entry_threshold=70,exit_threshold=50,indicator_exit=indicator_exit)
    rows=[]
    for c in r['completed']:
        ei=iof(c['entry_date']); xi=iof(c['date'])
        if xi>ei and xi<len(close):
            rows.append({'ret': close[xi]/close[ei]-1, 'exit_date': pd.Timestamp(c['date']),
                         'entry_date': pd.Timestamp(c['entry_date']), 'reason': c.get('exit_reason','')})
    return pd.DataFrame(rows)

def perf(df):
    if df.empty: return (0,0.0,0.0,0.0)
    d=df
    comp=np.prod(1+d['ret'])-1
    years=max((d['exit_date'].max()-d['entry_date'].min()).days,30)/365.25
    ann=((1+comp)**(1/years)-1)*100
    return (len(d), comp, ann, (d['ret']>0).mean()*100)

def bh(a,b):
    ai=iof(a); bi=iof(b); y=(idx[bi]-idx[ai]).days/365.25
    r=close[bi]/close[ai]-1
    return r*100, ((1+r)**(1/y)-1)*100

print('=== CONSISTENT-METRIC SWEEP (close-to-close, same as walk_forward baseline) ===')
print('Metric check: FIXED_SL 5% must reproduce n=79 comp=+309.9% (recorded baseline)')

# ---- validation gate ----
df = trades_for('FIXED_SL', 5.0)
n,comp,ann,win = perf(df)
print(f'  VALIDATE FIXED_SL 5%: n={n} comp={comp*100:+7.1f}% ann={ann:+6.1f}% win={win:.1f}%  [expect n=79 comp=+309.9]')

bh_c, bh_a = bh(START,END)
print(f'  Buy&hold: {bh_c:+7.1f}%  {bh_a:+6.1f}%/yr')

# ---- reference: FIXED_SL sweep ----
print('\n=== FIXED_SL reference ===')
for sl in (5.0,10.0,15.0,20.0,25.0):
    d=trades_for('FIXED_SL',sl); n,c,a,w=perf(d)
    print(f'  FIXED_SL {sl:4.1f}: n={n:3d} comp={c*100:+7.1f}% ann={a:+6.1f}% win={w:4.1f}%')

# ---- INDICATOR_SL sweep ----
print('\n=== INDICATOR_SL sweep (disaster SL backstop) ===')
modes=['SMA20','SMA50','MACD','MACD_HIST','ADX','RSI_SAT','STOCH','DI']
for ind in modes:
    for sl in (15.0,20.0,25.0):
        d=trades_for('INDICATOR_SL',sl,ind)
        n,c,a,w=perf(d)
        print(f'  {ind:10s} +disaster {sl:4.1f}: n={n:3d} comp={c*100:+8.1f}% ann={a:+6.1f}% win={w:4.1f}%')

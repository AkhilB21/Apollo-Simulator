"""NSE Data Feed — Fetches OHLCV candles via yfinance.

This is the single data-source layer for the NSE Engine. It downloads
multi-timeframe OHLCV data for NIFTY 500 constituents using yfinance.

Key design decisions:
  - Uses yfinance (free, no auth, no browser)
  - NIFTY 500 constituent list fetched from NSE's official CSV
  - Intraday data (15m, 30m, 1h, 4h) built by resampling daily +
    using yfinance's intraday intervals where available
  - All data cached locally to avoid re-downloading

Caveats:
  - yfinance intraday data is limited to last 60 days for 1m/5m
  - 15min/30m/1h intervals have ~730 day history
  - 4H is not a native yfinance interval — built by resampling 1h
  - Data is 15-20 min delayed during market hours
"""
from __future__ import annotations

import os
import sys
import time
import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import yfinance as yf

# Paths relative to THIS file inside apollo_engine/nse_engine/
_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent  # apollo_engine/
_CACHE_DIR = _PROJECT_ROOT / "nse_cache"
_NIFTY500_CSV = _CACHE_DIR / "nifty500_list.json"

# NSE official CSV for NIFTY 500 constituents
_NSE_NIFTY500_URL = (
    "https://indices.nseindia.com/BackathonData/nifty500_plus.csv"
)

# Fallback: if NSE URL fails, use local smallcap500.json or data/ dir
_FALLBACK_LOCAL = None  # Set at import time after _PROJECT_ROOT is defined

# Timeframe configurations
# yfinance interval -> (yf_interval, history_days, label)
TIMEFRAME_CONFIG = {
    "weekly":  {"interval": "1wk", "days": 730, "label": "Weekly"},
    "daily":   {"interval": "1d",  "days": 730, "label": "Daily"},
    "2day":    {"interval": "1d",  "days": 730, "label": "2-Day"},
    "3day":    {"interval": "1d",  "days": 730, "label": "3-Day"},
    "4hour":   {"interval": "1h",  "days": 58,  "label": "4H"},      # resampled, max 60d
    "1hour":   {"interval": "1h",  "days": 58,  "label": "1H"},
    "30min":   {"interval": "30m", "days": 58,  "label": "30M"},
    "15min":   {"interval": "15m", "days": 55,  "label": "15M"},
    "2week":   {"interval": "1wk", "days": 730, "label": "2-Week"},
    "monthly": {"interval": "1mo", "days": 1825, "label": "Monthly"},
}

# How many stocks to download in each yfinance batch
BATCH_SIZE = 20
BATCH_DELAY = 2.0  # seconds between batches (avoid yfinance rate limit)


def _ensure_cache_dir() -> Path:
    """Create cache directory if needed."""
    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    return _CACHE_DIR


def _fetch_nifty500_list() -> list[str]:
    """Get the list of NIFTY 500 stock symbols.

    Tries:
      1. Cached local file (if < 24h old)
      2. NSE official CSV
      3. Fallback JSON from repo
    """
    cache = _ensure_cache_dir()

    # Check cache (valid for 24 hours)
    if _NIFTY500_CSV.exists():
        age = time.time() - _NIFTY500_CSV.stat().st_mtime
        if age < 86400:
            with open(_NIFTY500_CSV) as f:
                data = json.load(f)
            symbols = data.get("symbols", [])
            if symbols:
                print(f"  NIFTY 500 list loaded from cache ({len(symbols)} stocks)")
                return symbols

    # Method 1: Try NSE official CSV
    import requests
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36"
        )
    }
    symbols = []

    try:
        print("  Fetching NIFTY 500 list from NSE...")
        resp = requests.get(_NSE_NIFTY500_URL, headers=headers, timeout=15)
        if resp.status_code == 200:
            import io
            csv_text = resp.text
            # Parse CSV — first column is symbol
            for line in csv_text.strip().split("\n")[1:]:  # skip header
                parts = line.split(",")
                if parts:
                    sym = parts[0].strip().upper()
                    if sym and sym != "Symbol":
                        symbols.append(sym)
            if symbols:
                print(f"  Got {len(symbols)} symbols from NSE")
    except Exception as e:
        print(f"  NSE fetch failed: {e}")

    # Method 2: Read from local smallcap500.json
    if not symbols:
        local_json = _PROJECT_ROOT / "smallcap500.json"
        try:
            if local_json.exists():
                with open(local_json) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    symbols = [
                        item.get("sym", "").replace(".NS", "").upper()
                        for item in data
                        if isinstance(item, dict) and item.get("sym", "").endswith(".NS")
                    ]
                if symbols:
                    print(f"  Got {len(symbols)} symbols from local smallcap500.json")
        except Exception as e:
            print(f"  Local JSON failed: {e}")

    # Method 3: Read from existing my_watchlist.json
    if not symbols:
        wl_path = _PROJECT_ROOT / "my_watchlist.json"
        try:
            if wl_path.exists():
                with open(wl_path) as f:
                    data = json.load(f)
                if isinstance(data, list):
                    symbols = [
                        item.get("sym", "").replace(".NS", "").upper()
                        for item in data
                        if isinstance(item, dict) and ".NS" in item.get("sym", "")
                    ]
                if symbols:
                    print(f"  Got {len(symbols)} symbols from my_watchlist.json")
        except Exception as e:
            print(f"  Watchlist fallback failed: {e}")

    # Method 4: Last resort — use data/ directory CSVs
    if not symbols:
        print("  WARNING: No symbol list found. Using local data directory.")
        data_dir = _PROJECT_ROOT / "data"
        if data_dir.is_dir():
            for f in data_dir.glob("*.csv"):
                name = f.stem.upper()
                if not name.endswith(("_D", "_4H", "_W")):
                    symbols.append(name)

    # Save to cache
    if symbols:
        with open(_NIFTY500_CSV, "w") as f:
            json.dump({
                "symbols": symbols,
                "fetched_at": datetime.now().isoformat(),
                "count": len(symbols),
            }, f, indent=2)

    print(f"  Total NIFTY 500 symbols: {len(symbols)}")
    return symbols


def _resample_to_4h(df: pd.DataFrame) -> pd.DataFrame:
    """Resample 1H OHLCV data to 4H bars."""
    if df.empty:
        return df

    df = df.copy()
    df.index = pd.to_datetime(df.index)

    resampled = df.resample("4h").agg({
        "open": "first",
        "high": "max",
        "low": "min",
        "close": "last",
        "volume": "sum",
    })

    # Drop rows with NaN (incomplete 4h bars)
    resampled = resampled.dropna()
    return resampled


def _compute_pct_change(df: pd.DataFrame, periods: int = 1) -> pd.Series:
    """Compute percentage change over N periods."""
    return df["close"].pct_change(periods=periods) * 100


class NSEDataFeed:
    """Fetches multi-timeframe OHLCV for NIFTY 500 stocks via yfinance.

    Usage:
        feed = NSEDataFeed()
        daily_data = feed.fetch_timeframe("daily")
        weekly_data = feed.fetch_timeframe("weekly")
        feed.close()
    """

    def __init__(
        self,
        symbols: Optional[list[str]] = None,
        cache_dir: Optional[str] = None,
        use_cache: bool = True,
        progress: bool = True,
    ):
        self._cache_dir = Path(cache_dir) if cache_dir else _ensure_cache_dir()
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._use_cache = use_cache
        self._progress = progress

        if symbols:
            self._symbols = [s.replace(".NS", "").upper() for s in symbols]
        else:
            self._symbols = _fetch_nifty500_list()

        # Add .NS suffix for yfinance
        self._yf_symbols = [f"{s}.NS" for s in self._symbols]

    @property
    def symbols(self) -> list[str]:
        return list(self._symbols)

    def _cache_path(self, timeframe: str) -> Path:
        return self._cache_dir / f"ohlcv_{timeframe}.parquet"

    def _load_cache(self, timeframe: str) -> Optional[pd.DataFrame]:
        """Load cached OHLCV data if fresh (< market hours old for intraday)."""
        if not self._use_cache:
            return None

        path = self._cache_path(timeframe)
        if not path.exists():
            return None

        age_hours = (time.time() - path.stat().st_mtime) / 3600
        config = TIMEFRAME_CONFIG.get(timeframe, {})
        interval = config.get("interval", "1d")

        # Intraday: cache valid for 1 hour during market hours
        # EOD: cache valid until next trading day
        max_age_hours = 1.0 if interval in ("15m", "30m", "1h") else 18.0

        if age_hours > max_age_hours:
            return None

        try:
            df = pd.read_parquet(path)
            if self._progress:
                print(f"  Loaded {timeframe} from cache ({len(df)} rows)")
            return df
        except Exception:
            return None

    def _save_cache(self, timeframe: str, df: pd.DataFrame) -> None:
        """Save OHLCV data to parquet cache."""
        try:
            df.to_parquet(self._cache_path(timeframe))
        except Exception as e:
            print(f"  Cache save warning ({timeframe}): {e}")

    def fetch_timeframe(
        self,
        timeframe: str,
        force_refresh: bool = False,
    ) -> dict[str, pd.DataFrame]:
        """Fetch OHLCV data for all symbols at a given timeframe.

        Returns dict of {symbol: DataFrame} with columns:
            open, high, low, close, volume

        The DataFrames are indexed by datetime.
        """
        if timeframe not in TIMEFRAME_CONFIG:
            raise ValueError(f"Unknown timeframe: {timeframe}")

        config = TIMEFRAME_CONFIG[timeframe]
        interval = config["interval"]
        days = config["days"]
        label = config["label"]

        # Check cache
        if not force_refresh:
            cached = self._load_cache(timeframe)
            if cached is not None:
                return self._split_by_symbol(cached)

        # Fetch from yfinance in batches
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)

        all_data = {}
        total = len(self._yf_symbols)
        failed = []

        if self._progress:
            print(f"\n  Fetching {label} OHLCV ({total} stocks, {interval})...")

        for i in range(0, total, BATCH_SIZE):
            batch = self._yf_symbols[i : i + BATCH_SIZE]
            batch_num = i // BATCH_SIZE + 1
            total_batches = (total + BATCH_SIZE - 1) // BATCH_SIZE

            if self._progress:
                print(
                    f"    Batch {batch_num}/{total_batches} "
                    f"({len(batch)} stocks)...",
                    end="",
                    flush=True,
                )

            try:
                data = yf.download(
                    batch,
                    start=start_date.strftime("%Y-%m-%d"),
                    end=end_date.strftime("%Y-%m-%d"),
                    interval=interval,
                    group_by="ticker",
                    auto_adjust=True,
                    progress=False,
                    threads=True,
                )

                # yfinance returns different formats for 1 vs many tickers
                if len(batch) == 1:
                    # Single ticker — columns may be flat or MultiIndex
                    ticker = batch[0]
                    if isinstance(data.columns, pd.MultiIndex):
                        data.columns = data.columns.droplevel(0)
                    # yfinance returns mixed case: Open, High, Low, Close, Volume
                    data.columns = [c.lower().strip() for c in data.columns]
                    # Keep only OHLCV columns
                    keep = [c for c in ("open", "high", "low", "close", "volume") if c in data.columns]
                    if len(keep) < 4:
                        if self._progress:
                            print(f" FAILED: not enough OHLCV columns")
                        failed.append(ticker)
                        continue
                    data = data[keep].copy()
                    data = data.dropna(subset=["close"])
                    if not data.empty:
                        data["symbol"] = ticker
                        all_data[ticker] = data
                else:
                    # Multiple tickers
                    if isinstance(data.columns, pd.MultiIndex):
                        for ticker in batch:
                            try:
                                sub = data[ticker].copy()
                                sub = sub.dropna(subset=["Close"])
                                if sub.empty:
                                    continue
                                sub.columns = [c.lower() for c in sub.columns]
                                # Ensure we have the right columns
                                col_map = {}
                                for c in sub.columns:
                                    if c in ("open", "high", "low", "close", "volume"):
                                        col_map[c] = c
                                sub = sub[[c for c in ("open", "high", "low", "close", "volume") if c in sub.columns]]
                                if len(sub.columns) >= 4:  # at least OHLC
                                    sub["symbol"] = ticker
                                    all_data[ticker] = sub
                            except Exception:
                                failed.append(ticker)
                    else:
                        # Flat columns (single row or error)
                        data.columns = [c.lower().strip() for c in data.columns]
                        data["symbol"] = batch[0]
                        if "close" in data.columns:
                            all_data[batch[0]] = data

                if self._progress:
                    print(f" OK")

            except Exception as e:
                if self._progress:
                    print(f" FAILED: {e}")
                failed.extend(batch)

            # Rate limiting
            if i + BATCH_SIZE < total:
                time.sleep(BATCH_DELAY)

        if failed and self._progress:
            print(f"  Failed: {len(failed)} stocks")

        # Resample to 4H if needed
        if timeframe == "4hour":
            for sym in all_data:
                all_data[sym] = _resample_to_4h(all_data[sym])

        # Combine and cache
        if all_data:
            combined = pd.concat(all_data.values(), ignore_index=False)
            combined.index.name = "datetime"
            self._save_cache(timeframe, combined)
            if self._progress:
                print(f"  {label}: {len(all_data)} stocks, "
                      f"{sum(len(d) for d in all_data.values())} total bars")

        return all_data

    def _split_by_symbol(self, combined: pd.DataFrame) -> dict[str, pd.DataFrame]:
        """Split a combined DataFrame back into per-symbol dicts."""
        if "symbol" not in combined.columns:
            return {}
        result = {}
        for sym, group in combined.groupby("symbol"):
            df = group.drop(columns=["symbol"]).copy()
            result[sym] = df
        return result

    def fetch_all_timeframes(
        self,
        timeframes: Optional[list[str]] = None,
        force_refresh: bool = False,
    ) -> dict[str, dict[str, pd.DataFrame]]:
        """Fetch multiple timeframes at once.

        Returns {timeframe: {symbol: DataFrame}}
        """
        if timeframes is None:
            timeframes = list(TIMEFRAME_CONFIG.keys())

        results = {}
        for tf in timeframes:
            try:
                results[tf] = self.fetch_timeframe(tf, force_refresh)
            except Exception as e:
                print(f"  ERROR fetching {tf}: {e}")
                results[tf] = {}
        return results

    def close(self):
        """Cleanup (no-op for yfinance, but keeps API consistent)."""
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

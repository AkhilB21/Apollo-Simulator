"""NSE Data Engine v1 — Own-source RSI dashboard + Gainer scanner.

Replaces the Chartink browser-scraping pipeline with direct NSE data
fetching via yfinance. Produces the exact same output format that
chartink_pipeline/watchlist_generator.py expects.

Architecture:
    data_feed.py   — Fetches OHLCV from yfinance for NIFTY 500 stocks
    scanner.py     — Runs 12 scans (6 RSI Dashboard + 6 NIFTY 500 Gainers)
    run_pipeline.py — Orchestrates: fetch -> scan -> score -> watchlist

Usage:
    python -m nse_engine                       # Full pipeline
    python -m nse_engine --dry-run              # Preview, don't write watchlist
    python -m nse_engine --rsi-only             # RSI dashboard scans only
    python -m nse_engine --gainers-only         # NIFTY 500 gainer scans only
    python -m nse_engine --top 50               # Limit watchlist to 50 stocks
"""

__version__ = "1.0.0"

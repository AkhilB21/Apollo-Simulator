"""NSE Scanner — Replicates Chartink's 12 scans using local data.

Takes OHLCV data from data_feed.py and produces the exact same
DataFrame format that chartink_pipeline/watchlist_generator.py expects.

Two scan categories:
  1. RSI Dashboard (6 timeframes): RSI(21), RSI(36), RSI(56) > 0
     → Produces columns: nsecode, name, close, RSI ( 21 , C ), RSI ( 36 , C ),
       RSI ( 56 , C ), % change

  2. NIFTY 500 Gainers (6 timeframes): MACD > 0 (daily) or all NIFTY 500
     sorted by % change over N periods
     → Produces columns: nsecode, name, close, % change

The output DataFrames match the column naming convention used by
watchlist_generator.py regex matches column names like "RSI ( 21 , C )" and extracts period 21.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

# Reuse Apollo's own RSI implementation (Wilder's method, exact match)
_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent

if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from apollo_core.indicators import compute_rsi, compute_macd


# ------------------------------------------------------------------
# Column name format — MUST match watchlist_generator.py's regex
# ------------------------------------------------------------------
# The watchlist_generator uses: re.search(r'rsi[^0-9]*(\d+)', col_lower)
# So columns like "RSI ( 21 , C )" → period=21 ✓

RSI21_COL = "RSI ( 21 , C )"
RSI36_COL = "RSI ( 36 , C )"
RSI56_COL = "RSI ( 56 , C )"
PCT_CHG_COL = "% change"


# ------------------------------------------------------------------
# RSI Dashboard Scans
# ------------------------------------------------------------------
# Original Chartink condition (all 6 timeframes):
#   ( ( RSI ( 21 , C ) greater than 0 )
#     and ( RSI ( 36 , C ) greater than 0 )
#     and ( RSI ( 56 , C ) greater than 0 ) )
#
# Translation: compute all 3 RSIs, filter where ALL > 0
# Then sort by % change descending (same as Chartink's sort_col)

RSI_DASHBOARD_TFS = ["weekly", "daily", "4hour", "1hour", "30min", "15min"]


# ------------------------------------------------------------------
# NIFTY 500 Gainer Scans
# ------------------------------------------------------------------
# Daily: MACD line (12,26,9) > 0, 1 day ago → sort by % change (1-day)
# 2-day: all NIFTY 500 → sort by 2-day % change
# 3-day: all NIFTY 500 → sort by 3-day % change
# weekly: all NIFTY 500 → sort by weekly % change
# 2-week: all NIFTY 500 → sort by 2-week % change
# monthly: all NIFTY 500 → sort by monthly % change

GAINER_TF_CONFIG = {
    "daily":   {"base_tf": "daily",   "pct_periods": 1, "filter_macd": True},
    "2day":    {"base_tf": "daily",   "pct_periods": 2, "filter_macd": False},
    "3day":    {"base_tf": "daily",   "pct_periods": 3, "filter_macd": False},
    "weekly":  {"base_tf": "weekly",  "pct_periods": 1, "filter_macd": False},
    "2week":   {"base_tf": "weekly",  "pct_periods": 2, "filter_macd": False},
    "monthly": {"base_tf": "monthly", "pct_periods": 1, "filter_macd": False},
}


# Min bars needed to compute indicators
MIN_BARS_RSI = 60   # Need at least 60 bars for RSI(56)
MIN_BARS_MACD = 35  # Need ~35 bars for MACD(12,26,9)


def _compute_rsi_row(
    df: pd.DataFrame,
) -> Optional[dict]:
    """Compute RSI(21), RSI(36), RSI(56) and % change for the latest bar.

    Returns a dict with the latest values, or None if insufficient data.
    """
    if len(df) < MIN_BARS_RSI:
        return None

    rsi21 = compute_rsi(df["close"], 21)
    rsi36 = compute_rsi(df["close"], 36)
    rsi56 = compute_rsi(df["close"], 56)

    # Latest values
    latest = df.iloc[-1]
    last_rsi21 = rsi21.iloc[-1]
    last_rsi36 = rsi36.iloc[-1]
    last_rsi56 = rsi56.iloc[-1]

    # All must be valid numbers
    if any(pd.isna(v) for v in [last_rsi21, last_rsi36, last_rsi56]):
        return None

    # % change (1-period)
    if len(df) >= 2:
        pct_chg = (latest["close"] / df.iloc[-2]["close"] - 1) * 100
    else:
        pct_chg = 0.0

    return {
        "rsi21": round(last_rsi21, 2),
        "rsi36": round(last_rsi36, 2),
        "rsi56": round(last_rsi56, 2),
        "close": round(latest["close"], 2),
        "pct_change": round(pct_chg, 2),
    }


def _compute_macd_filter(df: pd.DataFrame) -> bool:
    """Check if MACD line (12,26,9) > 0 as of 1 bar ago.

    Mirrors Chartink condition: [MACD line ( 12 , 26 , 9 ) , 1 day ago] > 0
    """
    if len(df) < MIN_BARS_MACD:
        return False

    macd_line, _, _ = compute_macd(df["close"], fast=12, slow=26, signal_period=9)

    # 1 bar ago
    if len(macd_line) >= 2:
        val = macd_line.iloc[-2]
    else:
        val = macd_line.iloc[-1]

    return not pd.isna(val) and val > 0


def _compute_pct_change(df: pd.DataFrame, periods: int) -> float:
    """Compute % change over N periods."""
    if len(df) < periods + 1:
        return 0.0

    current = df["close"].iloc[-1]
    past = df["close"].iloc[-(periods + 1)]

    if past == 0 or pd.isna(past) or pd.isna(current):
        return 0.0

    return round((current / past - 1) * 100, 2)


class NSEScanner:
    """Runs Apollo-equivalent scans on local NSE data.

    Produces DataFrames in the exact format expected by
    chartink_pipeline/watchlist_generator.py::ChartinkApolloBridge.
    """

    def __init__(self, ohlcv_data: dict[str, dict[str, pd.DataFrame]]):
        """
        Parameters
        ----------
        ohlcv_data : dict
            {timeframe: {symbol: DataFrame}} from NSEDataFeed
        """
        self.ohlcv = ohlcv_data

    def run_rsi_dashboard(self) -> dict[str, pd.DataFrame]:
        """Run all 6 RSI Dashboard scans.

        Returns {timeframe_name: DataFrame} where each DataFrame has columns:
            nsecode, name, close, RSI ( 21 , C ), RSI ( 36 , C ),
            RSI ( 56 , C ), % change
        """
        results = {}

        for tf in RSI_DASHBOARD_TFS:
            print(f"\n  Scanning RSI Dashboard ({tf})...")
            df = self._scan_rsi_timeframe(tf)
            results[tf] = df
            print(f"    {len(df)} stocks with valid RSI")

        return results

    def _scan_rsi_timeframe(self, tf: str) -> pd.DataFrame:
        """Run RSI scan for a single timeframe."""
        tf_data = self.ohlcv.get(tf, {})
        if not tf_data:
            print(f"    No data for {tf}")
            return pd.DataFrame()

        rows = []
        skipped_no_data = 0
        skipped_no_rsi = 0

        for symbol_raw, df in tf_data.items():
            # Extract clean symbol name (remove .NS suffix)
            symbol = symbol_raw.replace(".NS", "").upper()

            if df.empty or len(df) < MIN_BARS_RSI:
                skipped_no_data += 1
                continue

            result = _compute_rsi_row(df)
            if result is None:
                skipped_no_rsi += 1
                continue

            # Chartink's RSI Dashboard shows ALL stocks where RSI > 0
            # (which is essentially all stocks with enough history)
            # But we also want to sort by % change
            rows.append({
                "nsecode": symbol,
                "name": symbol,  # yfinance doesn't always give names
                "close": result["close"],
                RSI21_COL: result["rsi21"],
                RSI36_COL: result["rsi36"],
                RSI56_COL: result["rsi56"],
                PCT_CHG_COL: result["pct_change"],
            })

        if not rows:
            return pd.DataFrame()

        result_df = pd.DataFrame(rows)

        # Sort by % change descending (same as Chartink)
        result_df = result_df.sort_values(PCT_CHG_COL, ascending=False)

        return result_df.reset_index(drop=True)

    def run_nifty500_gainers(self) -> dict[str, pd.DataFrame]:
        """Run all 6 NIFTY 500 Gainer scans.

        Returns {timeframe_name: DataFrame} where each DataFrame has columns:
            nsecode, name, close, % change
        """
        results = {}

        for tf, config in GAINER_TF_CONFIG.items():
            print(f"\n  Scanning NIFTY 500 Gainers ({tf})...")
            df = self._scan_gainer_timeframe(tf, config)
            results[tf] = df
            print(f"    {len(df)} stocks")

        return results

    def _scan_gainer_timeframe(
        self,
        tf: str,
        config: dict,
    ) -> pd.DataFrame:
        """Run Gainer scan for a single timeframe."""
        base_tf = config["base_tf"]
        pct_periods = config["pct_periods"]
        filter_macd = config["filter_macd"]

        # Get OHLCV data for the base timeframe
        base_data = self.ohlcv.get(base_tf, {})
        if not base_data:
            print(f"    No {base_tf} data for {tf} scan")
            return pd.DataFrame()

        # For MACD filter, we need daily data
        daily_data = self.ohlcv.get("daily", {})

        rows = []

        for symbol_raw, df in base_data.items():
            symbol = symbol_raw.replace(".NS", "").upper()

            if df.empty or len(df) < pct_periods + 1:
                continue

            # MACD filter (daily scan only)
            if filter_macd:
                daily_df = daily_data.get(symbol_raw)
                if daily_df is None or len(daily_df) < MIN_BARS_MACD:
                    continue
                if not _compute_macd_filter(daily_df):
                    continue

            pct_chg = _compute_pct_change(df, pct_periods)
            latest_close = round(df["close"].iloc[-1], 2)

            rows.append({
                "nsecode": symbol,
                "name": symbol,
                "close": latest_close,
                PCT_CHG_COL: pct_chg,
            })

        if not rows:
            return pd.DataFrame()

        result_df = pd.DataFrame(rows)

        # For 2-week, compute from weekly data * 2 periods
        if tf == "2week":
            result_df[PCT_CHG_COL] = result_df.apply(
                lambda row: self._compute_2week_change(row["nsecode"]),
                axis=1,
            )

        # Sort by % change descending
        result_df = result_df.sort_values(PCT_CHG_COL, ascending=False)

        return result_df.reset_index(drop=True)

    def _compute_2week_change(self, symbol: str) -> float:
        """Compute 2-week % change from weekly data."""
        weekly_data = self.ohlcv.get("weekly", {})
        for sym_raw, df in weekly_data.items():
            if sym_raw.replace(".NS", "").upper() == symbol:
                return _compute_pct_change(df, 2)
        return 0.0

    def run_all(self) -> tuple[dict[str, pd.DataFrame], dict[str, pd.DataFrame]]:
        """Run all 12 scans.

        Returns (rsi_data, gainer_data) — same format as
        fetch_rsi_dashboard() and fetch_nifty500_gainers() from chartink_pipeline.
        """
        print("\n" + "=" * 60)
        print("  RSI DASHBOARD SCANS (6 timeframes)")
        print("=" * 60)
        rsi_data = self.run_rsi_dashboard()

        print("\n" + "=" * 60)
        print("  NIFTY 500 GAINER SCANS (6 timeframes)")
        print("=" * 60)
        gainer_data = self.run_nifty500_gainers()

        return rsi_data, gainer_data

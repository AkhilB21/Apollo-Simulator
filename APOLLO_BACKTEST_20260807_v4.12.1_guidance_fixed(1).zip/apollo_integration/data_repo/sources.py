"""Apollo Data Sources — loader functions for each source type (v4.8)

Each source returns a standardised daily OHLCV DataFrame.

Source priority (for sync):
    1. eod2 local CSVs — deepest history, primary
    2. Google Sheets — screening analytics, today-only (future)
    3. yfinance — fallback, rate-limited (future)
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd


def load_eod2_csv(
    csv_path: str | Path,
) -> pd.DataFrame:
    """Load a single eod2-format CSV into a standardised daily DataFrame.

    Handles both ``YYYY-MM-DD`` and ``dd-MMM-yyyy`` date formats
    (flexible parsing via ``pd.to_datetime(errors='coerce')``).

    Parameters
    ----------
    csv_path : str or Path
        Path to the eod2 CSV file.

    Returns
    -------
    pd.DataFrame with DatetimeIndex and lowercase OHLCV columns.
    Empty DataFrame if the file doesn't exist or has no valid rows.
    """
    csv_path = Path(csv_path)
    if not csv_path.exists():
        return pd.DataFrame()

    df = pd.read_csv(csv_path)
    df.columns = [c.strip() for c in df.columns]

    # Flexible date parsing (handles both YYYY-MM-DD and dd-MMM-yyyy)
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df.dropna(subset=["Date"])
        df = df.set_index("Date")
        df = df.sort_index()

    # Standardise column names to lowercase
    df.columns = [c.strip().lower() for c in df.columns]

    # Keep only OHLCV
    ohlcv = ["open", "high", "low", "close", "volume"]
    available = [c for c in ohlcv if c in df.columns]
    if not available:
        return pd.DataFrame()

    for col in available:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df[available].dropna(subset=["close"])
    return df


def load_yfinance(symbol: str, period: str = "max") -> pd.DataFrame:
    """Load data from yfinance (fallback source, rate-limited).

    NOTE: Not yet implemented — placeholder for future use.
    Will be used when eod2 CSVs are not available for a symbol.
    """
    # Future: import yfinance; return standardised DataFrame
    return pd.DataFrame()


def load_google_sheets(symbol: str) -> pd.DataFrame:
    """Load today's screening analytics from Google Sheets.

    NOTE: Not yet implemented — placeholder for future use.
    Will provide today-only data points (PE, market cap, etc.)
    merged into the daily DataFrame.
    """
    # Future: use gspread or similar
    return pd.DataFrame()

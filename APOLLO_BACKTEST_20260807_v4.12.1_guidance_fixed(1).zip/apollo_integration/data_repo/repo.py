"""Apollo Central Data Repository - Parquet store & manifest.

v4.12: Robust date handling -- case-insensitive date detection,
timezone stripping, index name normalisation for reliable round-trips.

Each symbol gets one Parquet file: <REPO_DIR>/<SYMBOL>.parquet
Schema (columns): date -- datetime64[ns] (index), open/high/low/close/volume -- float64
A manifest.json at the repo root tracks metadata for every symbol.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd


# Columns stored in every Parquet file
OHLCV_COLS = ["open", "high", "low", "close", "volume"]


def _manifest_path(repo_dir: str | Path) -> Path:
    return Path(repo_dir) / "manifest.json"


def scan_parquet_repo(repo_dir: str | Path) -> list[dict]:
    """Scan the Parquet repo and return metadata for each symbol."""
    repo = Path(repo_dir)
    if not repo.is_dir():
        return []
    results = []
    for pq_file in sorted(repo.glob("*.parquet")):
        try:
            df = pd.read_parquet(pq_file)
            if df.empty:
                continue
            symbol = pq_file.stem.upper()
            date_col = df.index if isinstance(df.index, pd.DatetimeIndex) else df.get("date")
            if date_col is None:
                continue
            results.append({
                "symbol": symbol,
                "rows": len(df),
                "date_start": str(pd.Timestamp(date_col.min()).date()),
                "date_end": str(pd.Timestamp(date_col.max()).date()),
            })
        except Exception:
            continue
    return results


def get_manifest(repo_dir: str | Path) -> dict:
    """Read the manifest.json. Returns empty dict if not found."""
    mp = _manifest_path(repo_dir)
    if not mp.exists():
        return {}
    with open(mp, "r", encoding="utf-8") as f:
        return json.load(f)


def save_manifest(repo_dir: str | Path, manifest: dict) -> None:
    """Write manifest.json to the repo directory."""
    repo = Path(repo_dir)
    repo.mkdir(parents=True, exist_ok=True)
    mp = _manifest_path(repo_dir)
    with open(mp, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, default=str)


def update_manifest_entry(
    repo_dir: str | Path,
    symbol: str,
    source: str = "unknown",
) -> None:
    """Update (or create) one symbol's entry in the manifest."""
    manifest = get_manifest(repo_dir)
    pq_path = Path(repo_dir) / f"{symbol.upper()}.parquet"
    if pq_path.exists():
        df = pd.read_parquet(pq_path)
        rows = len(df)
        date_col = df.index if isinstance(df.index, pd.DatetimeIndex) else df.get("date")
        if date_col is not None and len(date_col) > 0:
            d_start = str(pd.Timestamp(date_col.min()).date())
            d_end = str(pd.Timestamp(date_col.max()).date())
        else:
            d_start = d_end = ""
    else:
        rows = 0
        d_start = d_end = ""

    manifest[symbol.upper()] = {
        "rows": rows,
        "date_start": d_start,
        "date_end": d_end,
        "source": source,
        "last_updated": datetime.now().isoformat(),
    }
    save_manifest(repo_dir, manifest)


def list_symbols(repo_dir: str | Path) -> list[str]:
    """Return sorted list of symbols available in the Parquet repo."""
    repo = Path(repo_dir)
    if not repo.is_dir():
        return []
    return sorted(
        f.stem.upper() for f in repo.glob("*.parquet")
    )


def load_daily(
    repo_dir: str | Path,
    symbol: str,
    columns: list[str] | None = None,
) -> pd.DataFrame:
    """Load daily OHLCV data for one symbol from the Parquet repo.

    v4.12: memory_map reads, columns pruning, case-insensitive date
    detection, timezone stripping.
    """
    pq_path = Path(repo_dir) / f"{symbol.upper()}.parquet"
    if not pq_path.exists():
        raise FileNotFoundError(
            f"Parquet not found: {pq_path}. "
            f"Run: python -m data_repo.sync --source-dir <eod2_csv_dir> "
            f"--repo-dir {repo_dir}"
        )

    read_kwargs = {
        "engine": "pyarrow",
        "memory_map": True,
    }
    if columns is not None:
        read_kwargs["columns"] = [c for c in columns if c.lower() != "date"]
    df = pd.read_parquet(pq_path, **read_kwargs)

    # Ensure DatetimeIndex (case-insensitive date column detection)
    if not isinstance(df.index, pd.DatetimeIndex):
        _date_col = None
        for candidate in ("Date", "date", "DATE", "Timestamp", "timestamp"):
            if candidate in df.columns:
                _date_col = candidate
                break
        if _date_col is not None:
            df[_date_col] = pd.to_datetime(df[_date_col], errors="coerce")
            df = df.dropna(subset=[_date_col])
            df = df.set_index(_date_col)
    df = df.sort_index()

    # Strip timezone if present
    if isinstance(df.index, pd.DatetimeIndex) and df.index.tz is not None:
        df.index = df.index.tz_localize(None)

    # Ensure all OHLCV columns exist as float64
    for col in OHLCV_COLS:
        if col not in df.columns:
            df[col] = 0.0
        else:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    return df


def save_daily(
    repo_dir: str | Path,
    symbol: str,
    df: pd.DataFrame,
    source: str = "unknown",
) -> None:
    """Save daily OHLCV data for one symbol to the Parquet repo.

    v4.12: Normalises index name to 'date', strips timezone,
    handles case-insensitive date column detection.
    """
    repo = Path(repo_dir)
    repo.mkdir(parents=True, exist_ok=True)

    df = df.copy()

    # Normalise: ensure DatetimeIndex (tz-naive, name='date')
    if not isinstance(df.index, pd.DatetimeIndex):
        _date_col = None
        for candidate in ("Date", "date", "DATE", "Timestamp", "timestamp"):
            if candidate in df.columns:
                _date_col = candidate
                break
        if _date_col is not None:
            df[_date_col] = pd.to_datetime(df[_date_col], errors="coerce")
            df = df.dropna(subset=[_date_col])
            df = df.set_index(_date_col)
    df = df.sort_index()
    # Normalise index name to 'date' for consistent round-trips
    if isinstance(df.index, pd.DatetimeIndex):
        df.index.name = "date"

    # Strip timezone
    if isinstance(df.index, pd.DatetimeIndex) and df.index.tz is not None:
        df.index = df.index.tz_localize(None)

    # Subset to OHLCV only
    available_cols = [c for c in OHLCV_COLS if c in df.columns]
    df = df[available_cols].copy()
    for col in OHLCV_COLS:
        if col not in df.columns:
            df[col] = 0.0
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Remove duplicate dates (keep last)
    df = df[~df.index.duplicated(keep="last")]

    # Drop rows with no close price
    df = df.dropna(subset=["close"])

    # Write
    pq_path = repo / f"{symbol.upper()}.parquet"
    df.to_parquet(pq_path, engine="pyarrow", index=True)

    # Update manifest
    update_manifest_entry(repo_dir, symbol, source=source)


def merge_bars(
    existing_df: pd.DataFrame,
    new_df: pd.DataFrame,
) -> pd.DataFrame:
    """Merge new bars into existing data.
    Deduplicates by date (keeps the new value for overlapping dates)."""
    if existing_df.empty:
        return new_df
    if new_df.empty:
        return existing_df

    combined = pd.concat([existing_df, new_df])
    combined = combined[~combined.index.duplicated(keep="last")]
    return combined.sort_index()

"""Apollo Central Data Repository (v4.12)

Parquet-based canonical OHLCV storage with multi-source sync.
All engines read from APOLLO_DATA_REPOSITORY (see apollo_core/config.py).

Usage::

    from apollo_core.config import get_data_root
    from data_repo import list_symbols, load_daily

    REPO = get_data_root()
    syms = list_symbols(REPO)
    df = load_daily(REPO, "CYIENTDLM")
"""

from data_repo.repo import (
    list_symbols,
    load_daily,
    save_daily,
    get_manifest,
    scan_parquet_repo,
)

__all__ = [
    "list_symbols",
    "load_daily",
    "save_daily",
    "get_manifest",
    "scan_parquet_repo",
]

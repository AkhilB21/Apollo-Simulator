"""Apollo Live Engine — Alert Manager (v1.4).

Multi-channel alert delivery for the live engine. Plugs into
``MultiStockMonitor``'s ``alert_callback`` to push ENTRY/EXIT/COOLDOWN
alerts to:

1. **File log** — append-only ``reports/alerts.log`` (always on, zero config).
   This is the baseline channel; if everything else fails, the alerts are
   still on disk for the daily report to pick up.

2. **Telegram bot** — instant push to a Telegram chat. Optional, configured
   via environment variables:
       TELEGRAM_BOT_TOKEN  — bot token from @BotFather
       TELEGRAM_CHAT_ID    — numeric chat ID (use @userinfobot to find yours)
   If either env var is missing, Telegram is silently skipped (file log
   still works).

Design
------
The ``AlertManager`` is a single object that fans an alert out to all
configured channels. Each channel is a small ``_Backend`` subclass with a
``send(alert: dict, symbol: str) -> None`` method. Adding a new channel
(e.g., Email, Discord webhook) is just a new subclass + registration in
``AlertManager.__init__``.

The AlertManager is **fail-soft**: if any backend raises, the exception is
logged but does not propagate. A broken Telegram token should never crash
the monitor loop.

Threading
---------
The monitor calls ``send_alert`` synchronously from its alert callback. For
file log this is fine (microseconds). For Telegram (network I/O), we use a
background queue + worker thread so the monitor's main loop never blocks
on network latency. The queue is drained on ``shutdown()``.

Usage
-----
::

    from live_engine.alert_manager import AlertManager

    am = AlertManager(log_dir="reports")
    am.start()

    # Pass this to MultiStockMonitor:
    monitor = MultiStockMonitor(
        symbols=[...],
        alert_callback=lambda alert, sym: am.send_alert(alert, sym),
        ...
    )
    summary = monitor.run()

    # On shutdown (or signal handler):
    am.shutdown()  # drains queue, joins worker thread
"""

from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Optional, Callable


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

# Default log directory relative to project root. Created on first alert.
DEFAULT_LOG_DIR = "reports"

# Alert types that are "loud" enough to push to Telegram. HOLD/WAIT/STARTUP
# are kept file-only to avoid spamming the chat with hundreds of HOLD alerts
# per day. Override via the `push_types` constructor arg.
DEFAULT_PUSH_TYPES = {"ENTRY", "EXIT", "COOLDOWN", "EXIT_CONFIRMED"}

# Telegram API endpoint (no SDK dep, just urllib).
TELEGRAM_API_BASE = "https://api.telegram.org"


# ---------------------------------------------------------------------------
# Backends
# ---------------------------------------------------------------------------


class _Backend:
    """Base class for alert delivery backends. Subclass and override ``send``."""

    name: str = "base"

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def send(self, alert: dict, symbol: str) -> None:
        raise NotImplementedError

    def flush(self) -> None:
        """Synchronously flush any buffered output. Default: no-op."""
        pass


class FileLogBackend(_Backend):
    """Append-only alert log on disk.

    Format: one JSON line per alert (JSONL). Easy to grep, easy to parse
    later for the daily report. The file path is ``{log_dir}/alerts.log``.
    """

    name = "file"

    def __init__(self, log_dir: str = DEFAULT_LOG_DIR, verbose: bool = False):
        super().__init__(verbose=verbose)
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.log_dir / "alerts.log"

    def send(self, alert: dict, symbol: str) -> None:
        ts = alert.get("timestamp")
        ts_str = ts.isoformat() if hasattr(ts, "isoformat") else str(ts)

        # JSONL line — one alert per line, easy to tail / parse
        line = json.dumps({
            "timestamp": ts_str,
            "symbol": symbol,
            "alert_type": alert.get("alert_type", "UNKNOWN"),
            "message": alert.get("message", ""),
            "payload": alert.get("payload") or {},
        }, default=str, ensure_ascii=False)

        # Append-only open. We don't keep the file handle open between
        # writes because the monitor might run for hours/days and we want
        # log rotation to be possible (just move the file).
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")

        if self.verbose:
            print(f"[alert_manager:file] {line}", file=sys.stderr)


class TelegramBackend(_Backend):
    """Telegram bot push backend. Async via internal queue + worker.

    Reads configuration from environment variables at construction time:

        TELEGRAM_BOT_TOKEN  — bot token from @BotFather (e.g., "123456:ABC-DEF...")
        TELEGRAM_CHAT_ID    — numeric chat ID (e.g., "987654321")

    If either is missing, the backend is a no-op (send() drops silently).
    This lets the same code run on dev (no Telegram) and prod (with env
    vars set) without config changes.
    """

    name = "telegram"

    def __init__(
        self,
        bot_token: Optional[str] = None,
        chat_id: Optional[str] = None,
        push_types: Optional[set] = None,
        verbose: bool = False,
    ):
        super().__init__(verbose=verbose)
        self.bot_token = bot_token or os.environ.get("TELEGRAM_BOT_TOKEN")
        self.chat_id = chat_id or os.environ.get("TELEGRAM_CHAT_ID")
        self.push_types = push_types or DEFAULT_PUSH_TYPES
        self.enabled = bool(self.bot_token and self.chat_id)

        if not self.enabled and self.verbose:
            print(
                "[alert_manager:telegram] Disabled — set TELEGRAM_BOT_TOKEN "
                "and TELEGRAM_CHAT_ID env vars to enable.",
                file=sys.stderr,
            )

    def send(self, alert: dict, symbol: str) -> None:
        if not self.enabled:
            return

        atype = alert.get("alert_type", "UNKNOWN")
        if atype not in self.push_types:
            return  # File-only alert (HOLD/WAIT/STARTUP)

        msg = self._format_message(alert, symbol)
        self._send_message(msg)

    def _format_message(self, alert: dict, symbol: str) -> str:
        """Build a Telegram-friendly markdown message."""
        ts = alert.get("timestamp")
        ts_str = ts.strftime("%Y-%m-%d %H:%M") if hasattr(ts, "strftime") else str(ts)

        atype = alert.get("alert_type", "UNKNOWN")
        message = alert.get("message", "")
        payload = alert.get("payload") or {}

        # Emoji prefix by alert type (Telegram supports unicode emojis)
        emoji = {
            "ENTRY": "🟢",
            "EXIT": "🔴",
            "COOLDOWN": "🟡",
            "EXIT_CONFIRMED": "✅",
        }.get(atype, "⚪")

        lines = [
            f"{emoji} *{atype}* — `{symbol}`",
            f"_{ts_str}_",
            "",
            message,
        ]

        # Add key payload fields (price, score, P&L) if present
        if payload:
            extras = []
            for k in ("price", "close", "score", "entry_price", "pnl_pct"):
                if k in payload and payload[k] is not None:
                    extras.append(f"  {k}: `{payload[k]}`")
            if extras:
                lines.append("")
                lines.extend(extras)

        return "\n".join(lines)

    def _send_message(self, text: str) -> bool:
        """POST to Telegram sendMessage endpoint. Returns True on success."""
        if not self.bot_token or not self.chat_id:
            return False

        url = f"{TELEGRAM_API_BASE}/bot{self.bot_token}/sendMessage"
        data = urllib.parse.urlencode({
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": "Markdown",
        }).encode("utf-8")

        try:
            req = urllib.request.Request(url, data=data, method="POST")
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status != 200:
                    if self.verbose:
                        print(
                            f"[alert_manager:telegram] HTTP {resp.status}: "
                            f"{resp.read().decode('utf-8', errors='replace')[:200]}",
                            file=sys.stderr,
                        )
                    return False
                return True
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError) as e:
            if self.verbose:
                print(f"[alert_manager:telegram] send failed: {e}", file=sys.stderr)
            return False
        except Exception as e:
            # Never let an unexpected exception propagate up to the monitor loop.
            if self.verbose:
                print(f"[alert_manager:telegram] unexpected error: {e}", file=sys.stderr)
            return False


# ---------------------------------------------------------------------------
# AlertManager — fan-out orchestrator
# ---------------------------------------------------------------------------


class AlertManager:
    """Fan-out alert delivery to multiple backends.

    Parameters
    ----------
    log_dir : str
        Directory for the file log (``alerts.log``). Default: ``reports``.
    enable_telegram : bool
        If True (default), wire up the TelegramBackend if env vars are set.
        Set to False to force-disable Telegram even if env vars are present.
    push_types : set[str] | None
        Alert types to push to Telegram. Default: ENTRY/EXIT/COOLDOWN/EXIT_CONFIRMED.
        HOLD/WAIT/STARTUP are always file-only.
    enable_async : bool
        If True (default), Telegram sends are queued + dispatched by a worker
        thread so the monitor loop never blocks on network I/O.
        Set to False for tests (synchronous, deterministic).
    verbose : bool
        If True, print debug info to stderr.
    """

    def __init__(
        self,
        log_dir: str = DEFAULT_LOG_DIR,
        enable_telegram: bool = True,
        push_types: Optional[set] = None,
        enable_async: bool = True,
        verbose: bool = False,
    ):
        self.verbose = verbose
        self.push_types = push_types or DEFAULT_PUSH_TYPES
        self.enable_async = enable_async and enable_telegram

        # Always-on file log
        self._file_backend = FileLogBackend(log_dir=log_dir, verbose=verbose)

        # Optional Telegram
        self._telegram_backend: Optional[TelegramBackend] = None
        if enable_telegram:
            self._telegram_backend = TelegramBackend(
                push_types=self.push_types,
                verbose=verbose,
            )

        # Async queue + worker (only if Telegram is enabled and async is on)
        self._queue: Optional[queue.Queue] = None
        self._worker: Optional[threading.Thread] = None
        self._stop_worker = threading.Event()
        if self.enable_async and self._telegram_backend and self._telegram_backend.enabled:
            self._queue = queue.Queue(maxsize=1000)
            self._worker = threading.Thread(
                target=self._worker_loop,
                name="alert-manager-telegram",
                daemon=True,
            )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> "AlertManager":
        """Start the background worker thread (if async). Returns self."""
        if self._worker is not None and not self._worker.is_alive():
            self._worker.start()
            if self.verbose:
                print("[alert_manager] worker thread started", file=sys.stderr)
        return self

    def shutdown(self, timeout: float = 5.0) -> None:
        """Signal the worker to drain + exit. Blocks until joined or timeout."""
        if self._worker is None or not self._worker.is_alive():
            return
        self._stop_requested = True
        # Sentinel to wake the worker if it's blocked on queue.get()
        if self._queue is not None:
            self._queue.put(None)
        self._worker.join(timeout=timeout)
        if self.verbose:
            alive = self._worker.is_alive()
            print(
                f"[alert_manager] worker shutdown — alive={alive}",
                file=sys.stderr,
            )

    # ------------------------------------------------------------------
    # Public API — called by the monitor's alert_callback
    # ------------------------------------------------------------------

    def send_alert(self, alert: dict, symbol: str) -> None:
        """Fan out an alert to all configured backends.

        File log is always called synchronously (fast, local).
        Telegram is queued for async dispatch (if enabled) or called
        synchronously (if async is off, e.g., tests).
        """
        # 1. File log — always synchronous, never raises
        try:
            self._file_backend.send(alert, symbol)
        except Exception as e:
            # File log should never fail, but if it does, don't kill the monitor.
            if self.verbose:
                print(f"[alert_manager] file log failed: {e}", file=sys.stderr)

        # 2. Telegram — queue or sync
        if self._telegram_backend is None or not self._telegram_backend.enabled:
            return

        if self.enable_async and self._queue is not None:
            try:
                self._queue.put_nowait((alert, symbol))
            except queue.Full:
                # Drop oldest item to make room — better to lose one old alert
                # than to block the monitor loop.
                try:
                    self._queue.get_nowait()
                    self._queue.put_nowait((alert, symbol))
                except queue.Empty:
                    pass
                if self.verbose:
                    print("[alert_manager] queue full — dropped oldest", file=sys.stderr)
        else:
            # Synchronous path (tests)
            self._telegram_backend.send(alert, symbol)

    # ------------------------------------------------------------------
    # Internal — worker thread for async Telegram dispatch
    # ------------------------------------------------------------------

    def _worker_loop(self) -> None:
        """Background thread: dequeue alerts and send to Telegram."""
        assert self._queue is not None
        assert self._telegram_backend is not None

        while not self._stop_requested:
            try:
                item = self._queue.get(timeout=1.0)
            except queue.Empty:
                continue

            if item is None:
                # Sentinel — drain remaining items then exit
                break

            alert, symbol = item
            try:
                self._telegram_backend.send(alert, symbol)
            except Exception as e:
                if self.verbose:
                    print(
                        f"[alert_manager] worker send failed: {e}",
                        file=sys.stderr,
                    )

        # Drain remaining items on shutdown
        while True:
            try:
                item = self._queue.get_nowait()
            except queue.Empty:
                break
            if item is None:
                continue
            alert, symbol = item
            try:
                self._telegram_backend.send(alert, symbol)
            except Exception:
                pass  # Best-effort on shutdown

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def telegram_enabled(self) -> bool:
        """True if Telegram backend is configured (env vars set)."""
        return bool(self._telegram_backend and self._telegram_backend.enabled)

    @property
    def file_log_path(self) -> Path:
        """Path to the alerts.log file."""
        return self._file_backend.log_path

    def status(self) -> dict:
        """Return a status dict for logging / dashboards."""
        return {
            "file_log": str(self._file_backend.log_path),
            "telegram_enabled": self.telegram_enabled,
            "push_types": sorted(self.push_types),
            "async_enabled": self.enable_async and self._worker is not None,
            "worker_alive": self._worker.is_alive() if self._worker else False,
        }


# ---------------------------------------------------------------------------
# Convenience factory for the monitor's alert_callback signature
# ---------------------------------------------------------------------------


def make_callback(
    alert_manager: AlertManager,
    also_print: bool = True,
    loud_types: Optional[set] = None,
) -> Callable[[dict, str], None]:
    """Build an alert_callback matching MultiStockMonitor's ``(alert, symbol)`` signature.

    Parameters
    ----------
    alert_manager : AlertManager
        The manager to dispatch alerts to.
    also_print : bool
        If True, also print loud alerts to stdout (for headless console visibility).
    loud_types : set[str] | None
        Alert types to print to stdout. Default: ENTRY/EXIT/COOLDOWN/EXIT_CONFIRMED.
        Ignored if also_print=False.
    """
    if loud_types is None:
        loud_types = DEFAULT_PUSH_TYPES

    def callback(alert: dict, symbol: str) -> None:
        alert_manager.send_alert(alert, symbol)

        if also_print:
            atype = alert.get("alert_type", "")
            if atype in loud_types:
                ts = alert.get("timestamp")
                ts_str = ts.strftime("%Y-%m-%d %H:%M:%S") if hasattr(ts, "strftime") else str(ts)
                print(f"[{ts_str}] [{symbol:12s}] [{atype:8s}] {alert.get('message', '')}")

    return callback


# Re-export for urllib.parse (used in TelegramBackend._send_message)
import urllib.parse  # noqa: E402  (intentional late import — keep at bottom)

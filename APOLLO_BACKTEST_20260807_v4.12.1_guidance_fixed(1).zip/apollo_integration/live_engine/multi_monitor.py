"""Apollo Live Engine — Multi-Stock Monitor.

Runs N stocks in parallel (round-robin) with configurable pacing. This is
the "live scanner" mode: instead of exhausting one stock's bars in seconds,
it processes one bar from each stock per "tick", then sleeps
``pace_seconds`` before the next tick. Alerts stream in gradually across all
monitored stocks.

Design
------
The MultiStockMonitor wraps N ``SignalMonitor`` instances (one per stock).
Each tick:

1. For each stock with bars remaining:
   - Pull the next ``ReplayBar`` from that stock's ``BarReplay`` iterator.
   - Call ``monitor.process_bar(bar)`` — emits ENTRY/EXIT/HOLD/etc. alert
     to the StateStore + the alert_callback.
2. Sleep ``pace_seconds``.
3. Repeat until ALL stocks have exhausted their bars OR ``stop()`` is called.

State persistence
-----------------
Each stock's ``Position`` + ``last_processed_date`` is persisted to the
StateStore (keyed by symbol) after every bar — same as single-stock mode.
So you can stop the monitor anytime, restart, and it resumes each stock
from where it left off.

Backward compatibility
----------------------
When ``len(symbols) == 1``, MultiStockMonitor delegates to a single
SignalMonitor.run() call (no pacing, no round-robin overhead). So existing
single-stock CLI usage is unchanged.

Usage
-----
::

    from live_engine.multi_monitor import MultiStockMonitor
    from live_engine.watchlist import load_available_symbols

    symbols = load_available_symbols(data_dir="data")
    monitor = MultiStockMonitor(
        symbols=symbols,
        data_dir="data",
        start_date="2024-01-01",
        end_date="2026-07-27",
        db_path="live_state.db",
        pace_seconds=2.0,
        exit_mode="NONE",
        auto_confirm_exit=False,
    )
    summary = monitor.run()
"""

from __future__ import annotations

import os
import sys
import time
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional, Callable, Iterator

import pandas as pd

# Ensure project root is on sys.path so apollo_core + live_engine import cleanly
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from apollo_core.constants import ENTRY_THRESHOLD, EXIT_THRESHOLD
from apollo_core.types import Position
from live_engine.data_replay import BarReplay, ReplayBar
from live_engine.state_store import StateStore
from live_engine.signal_monitor import (
    SignalMonitor,
    ALERT_STARTUP,
)


# Default pace if none specified. 2 seconds per bar = ~8 minutes for a year
# of data per stock. Tunable via the dashboard's pace slider.
DEFAULT_PACE_SECONDS = 2.0


class MultiStockMonitor:
    """Round-robin multi-stock live monitor with configurable pacing.

    Parameters
    ----------
    symbols : list[str]
        NSE stock symbols to monitor (e.g., ``["APOLLO", "CYIENTDLM"]``).
        Must have ``{symbol}.csv`` in ``data_dir``.
    data_dir : str
        Directory containing the eod2 CSV files.
    start_date, end_date : str
        Replay date range (YYYY-MM-DD).
    db_path : str
        SQLite state DB path. Shared across all stocks — each is keyed by symbol.
    pace_seconds : float
        Seconds to sleep between ticks. ``0`` = no pacing (instant, like v1.2).
        Default: 2.0.
    exit_mode : str
        NONE | FIXED_SL | TRAILING_SL | DUAL_SL | DI_CROSSOVER. Applies to ALL stocks.
    sl_percent, trailing_sl_percent : float
        Stop-loss parameters (only used if exit_mode != NONE).
    entry_threshold, exit_threshold : float
        Score thresholds. Default: 70 / 50 (from apollo_core.constants).
    auto_confirm_exit : bool
        If True, EXIT alerts auto-close the position (Step 2 / v1.0 behavior).
        If False (default, v1.3), EXIT alerts become PENDING and require
        dashboard confirmation. Applies to ALL stocks.
    alert_callback : Callable[[dict, str], None] | None
        Optional callback invoked as ``(alert_dict, symbol)`` after each alert
        is emitted. The symbol is passed separately because the alert dict
        itself doesn't carry it (the StateStore keys alerts by symbol).
        If None, alerts are only persisted to the DB (no stdout).
    resume : bool
        If True (default), each stock resumes from its saved last_processed_date.
        If False, each stock's state is cleared and starts fresh.
    verbose : bool
        If True, print one line per bar per stock to stdout.
    """

    def __init__(
        self,
        symbols: list[str],
        data_dir: str,
        start_date: str,
        end_date: str,
        db_path: str,
        pace_seconds: float = DEFAULT_PACE_SECONDS,
        exit_mode: str = "NONE",
        sl_percent: float = 5.0,
        trailing_sl_percent: float = 3.0,
        entry_threshold: float = ENTRY_THRESHOLD,
        exit_threshold: float = EXIT_THRESHOLD,
        auto_confirm_exit: bool = False,
        alert_callback: Optional[Callable[[dict, str], None]] = None,
        resume: bool = True,
        verbose: bool = True,
    ):
        if not symbols:
            raise ValueError("symbols must be a non-empty list")

        self.symbols = list(symbols)
        self.data_dir = data_dir
        self.start_date = start_date
        self.end_date = end_date
        self.db_path = db_path
        self.pace_seconds = max(0.0, float(pace_seconds))
        self.exit_mode = exit_mode
        self.sl_percent = sl_percent
        self.trailing_sl_percent = trailing_sl_percent
        self.entry_threshold = entry_threshold
        self.exit_threshold = exit_threshold
        self.auto_confirm_exit = auto_confirm_exit
        self.alert_callback = alert_callback
        self.resume = resume
        self.verbose = verbose

        # Build per-stock SignalMonitor instances. We open ONE StateStore
        # and share it across all monitors (SQLite handles concurrent writes
        # via its own locking, and our writes are sequential within a tick).
        self._state_store = StateStore(db_path)
        self._monitors: dict[str, SignalMonitor] = {}
        self._iterators: dict[str, Iterator[ReplayBar]] = {}
        self._exhausted: set[str] = set()

        # Stop flag — set by stop() to break the run loop from another thread
        # (e.g., the dashboard's "Stop Monitor" button).
        self._stop_requested = threading.Event()

    # ------------------------------------------------------------------
    # Construction (lazy — call from run())
    # ------------------------------------------------------------------

    def _build_monitors(self) -> None:
        """Build per-stock BarReplay + SignalMonitor + iterator. Called once."""
        for sym in self.symbols:
            csv_path = Path(self.data_dir) / f"{sym}.csv"
            if not csv_path.exists():
                if self.verbose:
                    print(f"[multi_monitor] SKIP {sym}: CSV not found at {csv_path}")
                continue

            replay = BarReplay(
                data_dir=self.data_dir,
                symbol=sym,
                start_date=self.start_date,
                end_date=self.end_date,
                entry_threshold=self.entry_threshold,
                exit_threshold=self.exit_threshold,
            )

            # Wrap the alert callback so we can inject the symbol
            user_cb = self.alert_callback

            def cb_factory(symbol: str):
                def cb(alert: dict) -> None:
                    if user_cb is not None:
                        user_cb(alert, symbol)
                return cb

            monitor = SignalMonitor(
                replay=replay,
                state_store=self._state_store,
                alert_callback=cb_factory(sym),
                exit_mode=self.exit_mode,
                sl_percent=self.sl_percent,
                trailing_sl_percent=self.trailing_sl_percent,
                entry_threshold=self.entry_threshold,
                exit_threshold=self.exit_threshold,
                auto_confirm_exit=self.auto_confirm_exit,
                # symbol comes from replay.symbol (set to sym above)
            )
            self._monitors[sym] = monitor

        if not self._monitors:
            raise RuntimeError(
                f"No monitors could be built. Check that CSVs exist in {self.data_dir} "
                f"for symbols: {self.symbols}"
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def stop(self) -> None:
        """Request the monitor to stop after the current tick completes.

        Thread-safe. The run loop checks ``_stop_requested`` after each tick.
        """
        self._stop_requested.set()

    def run(self) -> dict:
        """Run the multi-stock monitor until all bars exhausted or stop() called.

        Returns
        -------
        dict
            Summary with per-stock stats plus aggregate counts.
        """
        self._build_monitors()

        # Open the state store (for state load/save + alert persistence)
        # The SignalMonitor expects an OPEN store; we open it here.
        # Actually, looking at the SignalMonitor code, it expects the store
        # to already be open. StateStore.__enter__ opens the connection.
        # We'll manage open/close here.
        if not self._state_store._conn:
            self._state_store.__enter__()

        try:
            return self._run_loop()
        finally:
            self._state_store.__exit__(None, None, None)

    def _run_loop(self) -> dict:
        """Main round-robin loop. Assumes state store is open."""
        # Per-stock: emit STARTUP, build iterator, load saved state
        for sym, monitor in self._monitors.items():
            # Load saved state (or reset if not resuming)
            if self.resume:
                monitor._load_state()
            else:
                self._state_store.clear_position(sym)
                # v1.4 bugfix: was `type(monitor._position)()` which returned
                # None because _position is None at this point (SignalMonitor.__init__
                # sets it to None until _load_state() runs). Explicit Position()
                # matches what SignalMonitor.run() does for the single-stock path.
                monitor._position = Position()
                monitor._last_processed_date = None

            # Emit STARTUP alert
            startup_msg = (
                f"Multi-monitor started for {sym} at "
                f"{datetime.utcnow().isoformat(timespec='seconds')}Z. "
                f"Resume={self.resume}, in_trade={monitor._position.in_trade}, "
                f"last_processed={monitor._last_processed_date}"
            )
            monitor._emit_alert(
                pd.Timestamp.utcnow(),
                ALERT_STARTUP,
                startup_msg,
                {"resume": self.resume, "in_trade": monitor._position.in_trade,
                 "pace_seconds": self.pace_seconds},
            )
            if self.verbose:
                print(f"[STARTUP] {startup_msg}")

            # Build iterator
            self._iterators[sym] = monitor.replay.replay()

        # Round-robin loop
        tick = 0
        per_stock_stats: dict[str, dict] = {sym: {
            "n_bars_processed": 0, "n_bars_skipped": 0,
            "n_entries": 0, "n_exits": 0, "n_holds": 0,
            "n_waits": 0, "n_cooldowns": 0,
            "final_in_trade": False, "last_processed_date": None,
        } for sym in self._monitors}

        while not self._stop_requested.is_set():
            tick += 1
            any_progress = False

            for sym, monitor in self._monitors.items():
                if sym in self._exhausted:
                    continue

                # Try to pull the next bar for this stock
                try:
                    replay_bar = next(self._iterators[sym])
                except StopIteration:
                    self._exhausted.add(sym)
                    if self.verbose:
                        print(f"[tick {tick}] {sym}: bars exhausted")
                    continue

                # Skip already-processed bars when resuming
                if (self.resume and monitor._last_processed_date is not None
                        and replay_bar.date <= monitor._last_processed_date):
                    per_stock_stats[sym]["n_bars_skipped"] += 1
                    continue

                # Process the bar — this emits the alert (if any) + persists state
                alert = monitor.process_bar(replay_bar)
                per_stock_stats[sym]["n_bars_processed"] += 1

                if alert is not None:
                    atype = alert.get("alert_type", "")
                    if atype == "ENTRY":
                        per_stock_stats[sym]["n_entries"] += 1
                    elif atype == "EXIT":
                        per_stock_stats[sym]["n_exits"] += 1
                    elif atype == "HOLD":
                        per_stock_stats[sym]["n_holds"] += 1
                    elif atype == "WAIT":
                        per_stock_stats[sym]["n_waits"] += 1
                    elif atype == "COOLDOWN":
                        per_stock_stats[sym]["n_cooldowns"] += 1

                    if self.verbose:
                        ts = alert.get("timestamp")
                        ts_str = ts.strftime("%Y-%m-%d %H:%M:%S") if hasattr(ts, "strftime") else str(ts)
                        print(f"[tick {tick}] [{sym}] [{atype:8s}] {alert['message']}")

                any_progress = True

            # If no stock made progress, we're done
            if not any_progress:
                break

            # If all stocks exhausted, we're done
            if len(self._exhausted) >= len(self._monitors):
                break

            # Pace: sleep before next tick (skip on last tick)
            if self.pace_seconds > 0 and not self._stop_requested.is_set():
                # Sleep in small increments so stop() can interrupt quickly
                slept = 0.0
                while slept < self.pace_seconds and not self._stop_requested.is_set():
                    chunk = min(0.1, self.pace_seconds - slept)
                    time.sleep(chunk)
                    slept += chunk

        # Final per-stock stats
        for sym, monitor in self._monitors.items():
            per_stock_stats[sym]["final_in_trade"] = monitor._position.in_trade
            per_stock_stats[sym]["last_processed_date"] = monitor._last_processed_date

        # Aggregate
        agg = {
            "n_symbols": len(self._monitors),
            "n_ticks": tick,
            "pace_seconds": self.pace_seconds,
            "stopped_by_user": self._stop_requested.is_set(),
            "total_bars": sum(s["n_bars_processed"] for s in per_stock_stats.values()),
            "total_entries": sum(s["n_entries"] for s in per_stock_stats.values()),
            "total_exits": sum(s["n_exits"] for s in per_stock_stats.values()),
            "total_holds": sum(s["n_holds"] for s in per_stock_stats.values()),
            "total_waits": sum(s["n_waits"] for s in per_stock_stats.values()),
            "total_cooldowns": sum(s["n_cooldowns"] for s in per_stock_stats.values()),
            "per_stock": per_stock_stats,
        }
        if self.verbose:
            print()
            print("=" * 60)
            print(f"  MULTI-MONITOR RUN COMPLETE — {len(self._monitors)} symbols")
            print("=" * 60)
            print(f"  ticks:.............. {tick}")
            print(f"  pace (sec/bar):..... {self.pace_seconds}")
            print(f"  stopped by user:.... {agg['stopped_by_user']}")
            print(f"  total bars:......... {agg['total_bars']}")
            print(f"  total entries:...... {agg['total_entries']}")
            print(f"  total exits:........ {agg['total_exits']}")
            print()
            for sym, s in per_stock_stats.items():
                print(f"  {sym:12s}  bars={s['n_bars_processed']:4d}  "
                      f"entries={s['n_entries']}  exits={s['n_exits']}  "
                      f"in_trade={s['final_in_trade']}")
            print("=" * 60)
        return agg

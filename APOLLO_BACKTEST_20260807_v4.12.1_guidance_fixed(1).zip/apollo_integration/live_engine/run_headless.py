"""Apollo Live Engine — Headless Runner (v1.4).

Runs ``MultiStockMonitor`` without Streamlit. Suitable for VPS / cloud
deployment where a UI is unnecessary overhead. Logs to stdout + the
AlertManager's file log; optionally pushes to Telegram.

Designed to run under:

* ``nohup`` / ``screen`` (simplest):
      nohup python -m live_engine.run_headless --watchlist my_watchlist.json > /var/log/apollo.log 2>&1 &

* ``systemd`` (recommended for production VPS — auto-restart on crash):
      See ``deploy/apollo-live.service`` (shipped separately, or write your
      own pointing at this script).

* ``Docker`` (portable):
      CMD ["python", "-m", "live_engine.run_headless", "--watchlist", "my_watchlist.json"]

Signals
-------
Handles SIGINT (Ctrl-C) and SIGTERM (systemd stop) gracefully — calls
``monitor.stop()`` and ``alert_manager.shutdown()``, then exits 0.

Usage
-----
::

    # Multi-stock, paced at 2 sec/bar (default), alerts to file + Telegram
    python -m live_engine.run_headless \\
        --watchlist my_watchlist.json \\
        --pace-seconds 2.0 \\
        --data-dir data \\
        --db live_state.db

    # Single-stock (legacy v1.2 mode)
    python -m live_engine.run_headless \\
        --symbol CYIENTDLM \\
        --data-dir data \\
        --db live_state.db

    # Fresh start (no resume)
    python -m live_engine.run_headless --watchlist my_watchlist.json --no-resume

    # Quiet (only ENTRY/EXIT/COOLDOWN to stdout)
    python -m live_engine.run_headless --watchlist my_watchlist.json --quiet

    # Disable Telegram (file log only)
    python -m live_engine.run_headless --watchlist my_watchlist.json --no-telegram
"""

from __future__ import annotations

import argparse
import os
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Ensure project root is on sys.path so `apollo_core` + `live_engine` import cleanly
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from apollo_core.constants import ENTRY_THRESHOLD, EXIT_THRESHOLD
from live_engine.alert_manager import AlertManager, make_callback
from live_engine.multi_monitor import MultiStockMonitor
from live_engine.signal_monitor import SignalMonitor
from live_engine.data_replay import BarReplay
from live_engine.state_store import StateStore
from live_engine.watchlist import (
    DEFAULT_WATCHLIST_PATH,
    list_available_symbols as load_available_symbols,
)


DEFAULT_DATA_DIR = "data"
_CENTRAL_REPO = r"C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\APOLLO_DATA_REPOSITORY"
DEFAULT_DB_PATH = str(Path(_CENTRAL_REPO) / "live_state" / "live_state.db")
DEFAULT_START_DATE = "2024-01-01"
DEFAULT_PACE_SECONDS = 2.0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="apollo-live-headless",
        description="Apollo Live Engine — Headless Runner (no Streamlit). "
                    "Suitable for VPS / cloud deployment.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # Mode selection
    p.add_argument("--symbol", default=None,
                   help="Single-stock mode. Required if --watchlist is not given.")
    p.add_argument("--watchlist", default=None,
                   help="Multi-stock mode. Path to watchlist JSON. "
                        "When given, monitors all watchlist stocks with CSVs in --data-dir.")
    p.add_argument("--pace-seconds", type=float, default=DEFAULT_PACE_SECONDS,
                   help=f"Seconds per bar in multi-stock mode. 0=instant. "
                        f"Default: {DEFAULT_PACE_SECONDS}.")
    # Data
    p.add_argument("--data-dir", default=DEFAULT_DATA_DIR,
                   help=f"Directory with CSVs (default: {DEFAULT_DATA_DIR})")
    p.add_argument("--start", default=DEFAULT_START_DATE,
                   help=f"Replay start date YYYY-MM-DD (default: {DEFAULT_START_DATE})")
    p.add_argument("--end", default=None,
                   help="Replay end date YYYY-MM-DD (default: today)")
    # State
    p.add_argument("--db", default=DEFAULT_DB_PATH,
                   help=f"SQLite state DB path (default: {DEFAULT_DB_PATH})")
    p.add_argument("--no-resume", action="store_true",
                   help="Don't resume from saved state; start fresh.")
    # Exit config
    p.add_argument("--exit-mode", default="NONE",
                   choices=["NONE", "FIXED_SL", "TRAILING_SL", "DUAL_SL", "DI_CROSSOVER"],
                   help="Exit mode (default: NONE)")
    p.add_argument("--sl-percent", type=float, default=5.0,
                   help="Hard SL %% (default: 5.0)")
    p.add_argument("--trailing-sl", type=float, default=3.0,
                   help="Trailing SL %% (default: 3.0)")
    p.add_argument("--entry-thresh", type=float, default=70.0,
                   help="Entry score threshold (default: 70)")
    p.add_argument("--exit-thresh", type=float, default=50.0,
                   help="Exit score threshold (default: 50)")
    # Operational
    p.add_argument("--auto-confirm", action="store_true",
                   help="Auto-confirm EXIT alerts (default: PENDING, "
                        "require dashboard confirmation).")
    p.add_argument("--quiet", action="store_true",
                   help="Only print ENTRY/EXIT/COOLDOWN alerts to stdout.")
    p.add_argument("--no-telegram", action="store_true",
                   help="Disable Telegram push (file log still active).")
    p.add_argument("--reports-dir", default="reports",
                   help="Directory for alerts.log (default: reports)")
    p.add_argument("--once", action="store_true",
                   help="Run once (process all bars then exit). Same as --pace-seconds 0 "
                        "but explicit. Useful for batch scoring.")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    # ----- Validate args -----
    if args.symbol is None and args.watchlist is None:
        print("ERROR: must give either --symbol or --watchlist", file=sys.stderr)
        return 2

    end_date = args.end or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    pace_seconds = 0.0 if args.once else args.pace_seconds

    # ----- Build AlertManager (file log + optional Telegram) -----
    alert_manager = AlertManager(
        log_dir=args.reports_dir,
        enable_telegram=not args.no_telegram,
        enable_async=True,
        verbose=not args.quiet,
    )
    alert_manager.start()

    # ----- Print startup banner -----
    print("=" * 72, flush=True)
    print(f"  APOLLO LIVE ENGINE v1.4 — HEADLESS", flush=True)
    print(f"  Started: {datetime.now(timezone.utc).isoformat(timespec='seconds')}Z", flush=True)
    print("=" * 72, flush=True)
    print(f"  Mode:        {'multi-stock' if args.watchlist else 'single-stock'}", flush=True)
    if args.watchlist:
        print(f"  Watchlist:   {args.watchlist}", flush=True)
    else:
        print(f"  Symbol:      {args.symbol}", flush=True)
    print(f"  Data dir:    {args.data_dir}", flush=True)
    print(f"  Date range:  {args.start} → {end_date}", flush=True)
    print(f"  Exit mode:   {args.exit_mode}", flush=True)
    print(f"  Pace:        {pace_seconds}s per bar", flush=True)
    print(f"  State DB:    {args.db}", flush=True)
    print(f"  Resume:      {not args.no_resume}", flush=True)
    print(f"  Auto-confirm:{args.auto_confirm}", flush=True)
    print(f"  Reports dir: {args.reports_dir}", flush=True)
    print(f"  Telegram:    {'enabled' if alert_manager.telegram_enabled else 'disabled'}", flush=True)
    print(f"  File log:    {alert_manager.file_log_path}", flush=True)
    print("=" * 72, flush=True)
    print(flush=True)

    # ----- Build the alert callback (delegates to AlertManager + stdout) -----
    callback = make_callback(
        alert_manager=alert_manager,
        also_print=not args.quiet,
    )

    # ----- Build the monitor (multi or single) -----
    monitor: Optional[MultiStockMonitor] = None
    single_monitor: Optional[SignalMonitor] = None
    single_store: Optional[StateStore] = None

    # Signal handler — calls monitor.stop() on SIGINT/SIGTERM
    def _signal_handler(signum, frame):
        name = signal.Signals(signum).name
        print(f"\n[headless] received {name}, stopping gracefully...", flush=True)
        if monitor is not None:
            monitor.stop()
        elif single_monitor is not None:
            # SignalMonitor doesn't have a clean stop() — it runs to completion.
            # For single-stock mode, the loop is short enough that we just let
            # it finish. (Multi-mode is the long-running one that needs stop().)
            print("[headless] single-stock mode: waiting for current bar to finish...",
                  flush=True)
        # The main loop will exit and shutdown AlertManager.
    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)

    try:
        if args.watchlist is not None:
            # ----- Multi-stock mode -----
            symbols = load_available_symbols(
                watchlist_path=args.watchlist,
                data_dir=args.data_dir,
            )
            if not symbols:
                print(f"ERROR: No watchlist stocks have CSVs in {args.data_dir}",
                      file=sys.stderr)
                print(f"Watchlist: {args.watchlist}", file=sys.stderr)
                print(f"Drop CSVs in data dir, or use --symbol for single-stock mode.",
                      file=sys.stderr)
                return 2

            print(f"[headless] Monitoring {len(symbols)} symbol(s): "
                  f"{', '.join(symbols[:5])}{'...' if len(symbols) > 5 else ''}",
                  flush=True)
            print(flush=True)

            monitor = MultiStockMonitor(
                symbols=symbols,
                data_dir=args.data_dir,
                start_date=args.start,
                end_date=end_date,
                db_path=args.db,
                pace_seconds=pace_seconds,
                exit_mode=args.exit_mode,
                sl_percent=args.sl_percent,
                trailing_sl_percent=args.trailing_sl,
                entry_threshold=args.entry_thresh,
                exit_threshold=args.exit_thresh,
                auto_confirm_exit=args.auto_confirm,
                alert_callback=callback,
                resume=not args.no_resume,
                verbose=not args.quiet,
            )
            summary = monitor.run()

            print(flush=True)
            print("=" * 72, flush=True)
            print(f"  RUN COMPLETE — {datetime.now(timezone.utc).isoformat(timespec='seconds')}Z",
                  flush=True)
            print("=" * 72, flush=True)
            print(f"  symbols:        {summary['n_symbols']}", flush=True)
            print(f"  ticks:          {summary['n_ticks']}", flush=True)
            print(f"  total bars:     {summary['total_bars']}", flush=True)
            print(f"  total entries:  {summary['total_entries']}", flush=True)
            print(f"  total exits:    {summary['total_exits']}", flush=True)
            print(f"  total holds:    {summary['total_holds']}", flush=True)
            print(f"  total waits:    {summary['total_waits']}", flush=True)
            print(f"  total cooldowns:{summary['total_cooldowns']}", flush=True)
            print(f"  stopped by user:{summary['stopped_by_user']}", flush=True)
            print("=" * 72, flush=True)

        else:
            # ----- Single-stock mode (legacy v1.0/v1.2 path) -----
            assert args.symbol is not None
            csv_path = Path(args.data_dir) / f"{args.symbol}.csv"
            if not csv_path.exists():
                print(f"ERROR: CSV not found at {csv_path}", file=sys.stderr)
                return 2

            print(f"[headless] Single-stock mode: {args.symbol}", flush=True)
            print(flush=True)

            replay = BarReplay(
                data_dir=args.data_dir,
                symbol=args.symbol,
                start_date=args.start,
                end_date=end_date,
                entry_threshold=args.entry_thresh,
                exit_threshold=args.exit_thresh,
            )

            with StateStore(args.db) as store:
                single_store = store
                # Wrap the (alert, symbol) callback to single-arg form
                def single_callback(alert: dict) -> None:
                    callback(alert, args.symbol)

                single_monitor = SignalMonitor(
                    replay=replay,
                    state_store=store,
                    alert_callback=single_callback,
                    exit_mode=args.exit_mode,
                    sl_percent=args.sl_percent,
                    trailing_sl_percent=args.trailing_sl,
                    entry_threshold=args.entry_thresh,
                    exit_threshold=args.exit_thresh,
                    auto_confirm_exit=args.auto_confirm,
                )
                summary = single_monitor.run(
                    resume=not args.no_resume,
                    verbose=not args.quiet,
                )

            print(flush=True)
            print("=" * 72, flush=True)
            print(f"  RUN COMPLETE — {datetime.now(timezone.utc).isoformat(timespec='seconds')}Z",
                  flush=True)
            print("=" * 72, flush=True)
            print(f"  symbol:         {summary['symbol']}", flush=True)
            print(f"  bars processed: {summary['n_bars_processed']}", flush=True)
            print(f"  alerts:         {summary['n_alerts']}", flush=True)
            print(f"  entries:        {summary['n_entries']}", flush=True)
            print(f"  exits:          {summary['n_exits']}", flush=True)
            print(f"  holds:          {summary['n_holds']}", flush=True)
            print(f"  waits:          {summary['n_waits']}", flush=True)
            print(f"  cooldowns:      {summary['n_cooldowns']}", flush=True)
            print(f"  final in_trade: {summary['final_in_trade']}", flush=True)
            print("=" * 72, flush=True)

    except Exception as e:
        print(f"[headless] FATAL: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return 1
    finally:
        # Drain Telegram queue + join worker thread
        print(flush=True)
        print("[headless] shutting down AlertManager...", flush=True)
        alert_manager.shutdown()
        print("[headless] done.", flush=True)

    return 0


if __name__ == "__main__":
    sys.exit(main())

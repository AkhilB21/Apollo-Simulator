"""Apollo Live Engine — State Store Module.

SQLite-backed persistence for the live signal monitor.

Tables
------
    monitor_state   — one row per symbol. Stores the Position dataclass
                      fields (in_trade, entry_*, peak_*, etc.) plus
                      ``last_processed_date`` and ``cooldown_until_date``.
                      Allows the monitor to stop/restart without losing
                      position state.

    alerts          — append-only alert log. One row per advisory alert
                      emitted (ENTRY, EXIT, HOLD, WARNING, etc.).

Design notes
------------
* In live mode, ``cooldown_until_date`` is a ``pd.Timestamp`` (not a bar
  index), because the bar index changes each day as history grows.
* All datetimes are stored as ISO 8601 strings for portability.
* The Position dataclass fields are stored as flat columns (not JSON
  blobs) for easy SQL querying. This means schema changes require a
  migration, but the Position dataclass is stable (hasn't changed since
  v4.4 introduced it).
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import pandas as pd

from apollo_core.types import Position


# ---------------------------------------------------------------------------
# Schema — created on first connect
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS monitor_state (
    symbol                   TEXT PRIMARY KEY,
    last_processed_date      TEXT,
    in_trade                 INTEGER NOT NULL DEFAULT 0,
    entry_price              REAL,
    entry_date               TEXT,
    peak_rsi                 REAL,
    peak_rsi_price           REAL,
    peak_rsi_date            TEXT,
    peak_close               REAL,
    trail_activation_price   REAL,
    prev_plus_di             REAL,
    prev_minus_di            REAL,
    cooldown_until           INTEGER,
    cooldown_until_date      TEXT,
    pending_exit             INTEGER NOT NULL DEFAULT 0,
    pending_exit_payload     TEXT,
    updated_at               TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS alerts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol      TEXT NOT NULL,
    timestamp   TEXT NOT NULL,
    alert_type  TEXT NOT NULL,
    message     TEXT NOT NULL,
    payload_json TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_alerts_symbol_ts
    ON alerts (symbol, timestamp);

CREATE INDEX IF NOT EXISTS idx_alerts_type
    ON alerts (alert_type);
"""

# Schema migration: add pending_exit columns to existing databases
# created before v1.1. SQLite supports ALTER TABLE ADD COLUMN, which is
# safe for adding nullable / default-bearing columns to existing tables.
_MIGRATION_SQL = [
    "ALTER TABLE monitor_state ADD COLUMN pending_exit INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE monitor_state ADD COLUMN pending_exit_payload TEXT",
]


# ---------------------------------------------------------------------------
# StateStore
# ---------------------------------------------------------------------------

class StateStore:
    """SQLite-backed state persistence for the live signal monitor.

    Parameters
    ----------
    db_path : str | Path
        Path to the SQLite database file. Created if it doesn't exist.
        Use ``:memory:`` for an in-memory database (useful for tests).
    """

    def __init__(self, db_path: str | Path):
        self.db_path = str(db_path)
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def _init_db(self) -> None:
        """Open connection and create schema if needed."""
        self._conn = sqlite3.connect(self.db_path)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA_SQL)
        # Run migrations (idempotent — fails silently if column already exists)
        for sql in _MIGRATION_SQL:
            try:
                self._conn.execute(sql)
            except sqlite3.OperationalError:
                pass  # column already exists — expected on v1.1+ databases
        self._conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # ------------------------------------------------------------------
    # Position state (monitor_state table)
    # ------------------------------------------------------------------

    def save_position(self, symbol: str, position: Position,
                      last_processed_date: Optional[pd.Timestamp] = None) -> None:
        """Persist the current Position state for a symbol.

        Parameters
        ----------
        symbol : str
            NSE stock symbol.
        position : Position
            Current position state (will be serialized field-by-field).
        last_processed_date : pd.Timestamp | None
            Date of the last bar processed by the monitor. Used to
            resume from the correct point after a restart.
        """
        if self._conn is None:
            raise RuntimeError("StateStore is closed")

        # Serialize datetimes to ISO strings
        entry_date_str = _ts_to_iso(position.entry_date)
        peak_rsi_date_str = _ts_to_iso(position.peak_rsi_date)
        cooldown_date_str = _ts_to_iso(position.cooldown_until_date)
        last_proc_str = _ts_to_iso(last_processed_date)
        now_str = datetime.utcnow().isoformat(timespec="seconds")

        # Serialize pending_exit_payload (a dict) to JSON string
        pending_payload_str = (
            json.dumps(position.pending_exit_payload, default=str)
            if position.pending_exit_payload else None
        )

        self._conn.execute(
            """
            INSERT INTO monitor_state (
                symbol, last_processed_date, in_trade,
                entry_price, entry_date,
                peak_rsi, peak_rsi_price, peak_rsi_date, peak_close,
                trail_activation_price, prev_plus_di, prev_minus_di,
                cooldown_until, cooldown_until_date,
                pending_exit, pending_exit_payload, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(symbol) DO UPDATE SET
                last_processed_date = excluded.last_processed_date,
                in_trade = excluded.in_trade,
                entry_price = excluded.entry_price,
                entry_date = excluded.entry_date,
                peak_rsi = excluded.peak_rsi,
                peak_rsi_price = excluded.peak_rsi_price,
                peak_rsi_date = excluded.peak_rsi_date,
                peak_close = excluded.peak_close,
                trail_activation_price = excluded.trail_activation_price,
                prev_plus_di = excluded.prev_plus_di,
                prev_minus_di = excluded.prev_minus_di,
                cooldown_until = excluded.cooldown_until,
                cooldown_until_date = excluded.cooldown_until_date,
                pending_exit = excluded.pending_exit,
                pending_exit_payload = excluded.pending_exit_payload,
                updated_at = excluded.updated_at
            """,
            (
                symbol, last_proc_str, int(position.in_trade),
                position.entry_price, entry_date_str,
                position.peak_rsi, position.peak_rsi_price, peak_rsi_date_str,
                position.peak_close,
                position.trail_activation_price,
                position.prev_plus_di, position.prev_minus_di,
                position.cooldown_until, cooldown_date_str,
                int(position.pending_exit), pending_payload_str,
                now_str,
            ),
        )
        self._conn.commit()

    def load_position(self, symbol: str) -> tuple[Position, Optional[pd.Timestamp]]:
        """Load the saved Position state for a symbol.

        Returns
        -------
        (position, last_processed_date)
            If no saved state exists, returns a fresh ``Position()`` and
            ``None`` for ``last_processed_date``.
        """
        if self._conn is None:
            raise RuntimeError("StateStore is closed")

        row = self._conn.execute(
            "SELECT * FROM monitor_state WHERE symbol = ?", (symbol,)
        ).fetchone()

        if row is None:
            return Position(), None

        # Parse pending_exit_payload (JSON string → dict)
        pending_payload_str = row["pending_exit_payload"] if "pending_exit_payload" in row.keys() else None
        pending_payload = None
        if pending_payload_str:
            try:
                pending_payload = json.loads(pending_payload_str)
            except (json.JSONDecodeError, TypeError):
                pending_payload = None

        # pending_exit column may not exist on legacy v1.0 databases
        # before migration runs — guard with .keys() check
        pending_exit_val = row["pending_exit"] if "pending_exit" in row.keys() else 0

        position = Position(
            in_trade=bool(row["in_trade"]),
            entry_price=row["entry_price"],
            entry_date=_iso_to_ts(row["entry_date"]),
            peak_rsi=row["peak_rsi"],
            peak_rsi_price=row["peak_rsi_price"],
            peak_rsi_date=_iso_to_ts(row["peak_rsi_date"]),
            peak_close=row["peak_close"],
            trail_activation_price=row["trail_activation_price"],
            prev_plus_di=row["prev_plus_di"],
            prev_minus_di=row["prev_minus_di"],
            cooldown_until=row["cooldown_until"],
            cooldown_until_date=_iso_to_ts(row["cooldown_until_date"]),
            pending_exit=bool(pending_exit_val),
            pending_exit_payload=pending_payload,
        )
        last_processed = _iso_to_ts(row["last_processed_date"])
        return position, last_processed

    def clear_position(self, symbol: str) -> None:
        """Delete the saved state for a symbol (used in tests / reset)."""
        if self._conn is None:
            raise RuntimeError("StateStore is closed")
        self._conn.execute(
            "DELETE FROM monitor_state WHERE symbol = ?", (symbol,)
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Alert log (alerts table)
    # ------------------------------------------------------------------

    def save_alert(
        self,
        symbol: str,
        timestamp: pd.Timestamp,
        alert_type: str,
        message: str,
        payload: Optional[dict] = None,
    ) -> int:
        """Append an alert to the log. Returns the new alert's row id."""
        if self._conn is None:
            raise RuntimeError("StateStore is closed")

        ts_str = _ts_to_iso(timestamp) or timestamp.isoformat()
        payload_str = json.dumps(payload, default=str) if payload else None

        cur = self._conn.execute(
            """
            INSERT INTO alerts (symbol, timestamp, alert_type, message, payload_json)
            VALUES (?, ?, ?, ?, ?)
            """,
            (symbol, ts_str, alert_type, message, payload_str),
        )
        self._conn.commit()
        return int(cur.lastrowid)

    def list_alerts(
        self,
        symbol: Optional[str] = None,
        since: Optional[pd.Timestamp] = None,
        alert_type: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict]:
        """Query alerts from the log.

        Parameters
        ----------
        symbol : str | None
            Filter by symbol. If None, all symbols.
        since : pd.Timestamp | None
            Only alerts at or after this timestamp.
        alert_type : str | None
            Filter by alert type (e.g., 'ENTRY', 'EXIT').
        limit : int | None
            Maximum number of alerts to return (most recent first).
        """
        if self._conn is None:
            raise RuntimeError("StateStore is closed")

        query = "SELECT * FROM alerts WHERE 1=1"
        params: list[Any] = []
        if symbol is not None:
            query += " AND symbol = ?"
            params.append(symbol)
        if since is not None:
            query += " AND timestamp >= ?"
            params.append(_ts_to_iso(since) or since.isoformat())
        if alert_type is not None:
            query += " AND alert_type = ?"
            params.append(alert_type)
        query += " ORDER BY timestamp ASC"
        if limit is not None:
            query += " LIMIT ?"
            params.append(int(limit))

        rows = self._conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def count_alerts(self, symbol: Optional[str] = None) -> int:
        """Count total alerts (optionally filtered by symbol)."""
        if self._conn is None:
            raise RuntimeError("StateStore is closed")
        if symbol is None:
            row = self._conn.execute("SELECT COUNT(*) AS n FROM alerts").fetchone()
        else:
            row = self._conn.execute(
                "SELECT COUNT(*) AS n FROM alerts WHERE symbol = ?", (symbol,)
            ).fetchone()
        return int(row["n"])

    def list_monitored_symbols(self) -> list[str]:
        """Return all symbols that have state rows in ``monitor_state``.

        Used by the v1.3 multi-stock dashboard to populate the grid view —
        only stocks that have actually been monitored (state rows exist) are
        shown, not just any symbol with alerts.
        """
        if self._conn is None:
            raise RuntimeError("StateStore is closed")
        rows = self._conn.execute(
            "SELECT DISTINCT symbol FROM monitor_state ORDER BY symbol ASC"
        ).fetchall()
        return [r["symbol"] for r in rows]

    def list_alerts_all_symbols(
        self,
        limit: int = 50,
        alert_types: Optional[list[str]] = None,
    ) -> list[dict]:
        """Return the most recent alerts across ALL symbols, newest first.

        Used by the v1.3 multi-stock dashboard's combined alerts feed.

        Parameters
        ----------
        limit : int
            Maximum number of alerts to return. Default: 50.
        alert_types : list[str] | None
            If provided, only return alerts whose ``alert_type`` is in this list.
            Useful for filtering to just ENTRY/EXIT/COOLDOWN (skipping HOLD/WAIT).
        """
        if self._conn is None:
            raise RuntimeError("StateStore is closed")

        query = "SELECT * FROM alerts"
        params: list[Any] = []
        if alert_types:
            placeholders = ",".join("?" * len(alert_types))
            query += f" WHERE alert_type IN ({placeholders})"
            params.extend(alert_types)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(int(limit))

        rows = self._conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Helpers — datetime <-> ISO string conversion
# ---------------------------------------------------------------------------

def _ts_to_iso(ts: Any) -> Optional[str]:
    """Convert a pd.Timestamp / datetime / date to ISO 8601 string. None → None."""
    if ts is None:
        return None
    if isinstance(ts, pd.Timestamp):
        # For date-only timestamps (no time component), use date format
        if ts.time() == pd.Timestamp("00:00:00").time():
            return ts.strftime("%Y-%m-%d")
        return ts.isoformat()
    if isinstance(ts, (datetime,)):
        return ts.isoformat()
    # Already a string?
    if isinstance(ts, str):
        return ts
    return str(ts)


def _iso_to_ts(s: Optional[str]) -> Optional[pd.Timestamp]:
    """Parse an ISO 8601 string back to pd.Timestamp. None/empty → None."""
    if not s:
        return None
    try:
        return pd.Timestamp(s)
    except (ValueError, TypeError):
        return None

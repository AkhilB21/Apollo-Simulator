"""Apollo Core — Entry Gates Module (v4.7)

Hard filters evaluated at ENTRY time, independent of the additive score.
If ANY gate fails, the entry is blocked regardless of score (same spirit
as the Renko Hard Gate — but unlike Renko, these gates are actually wired).

Gates:
    G1: PE Sanity          — block if trailing PE <= 0 or PE > PE_MAX.
                            Requires a per-symbol fundamental profile
                            (etmoney); skipped when profile is absent.
    G2: Liquidity Floor    — block if 20-day avg traded value
                            (close * volume) < MIN_AVG_TRADED_VALUE.
                            Computed from OHLCV.
    G3: 52W-Low Proximity  — block if close > MAX_52W_LOW_DIST above the
                            trailing 52-week low (stock must still be near
                            its low — trough-recovery premise).
    G4: 52W-High Distance  — block if the trailing 52-week high is not at
                            least MIN_52W_HIGH_DIST_MULT x close (stock must
                            still be meaningfully below its 52W high —
                            beaten-down premise).

The gate series (G2/G3/G4) are pure functions of the daily OHLCV frame
and are pre-computed once per run, then indexed by bar. G1 is a static
per-symbol check from the fundamental profile.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from apollo_core.constants import (
    PE_MAX,
    MIN_AVG_TRADED_VALUE,
    MAX_52W_LOW_DIST,
    MIN_52W_HIGH_DIST_MULT,
)

GATE_WEEK_LOOKBACK = 252  # trailing 52-week window for low/high


def compute_gate_frame(df_d: pd.DataFrame) -> pd.DataFrame:
    """Pre-compute the per-bar OHLCV-derived gate inputs.

    Returns a DataFrame indexed like ``df_d`` with columns:
        avg_traded_value_20, low_52w, high_52w
    """
    close = df_d["close"]
    volume = df_d["volume"] if "volume" in df_d.columns else pd.Series(np.nan, index=df_d.index)
    traded_value = close * volume

    frame = pd.DataFrame(index=df_d.index)
    frame["avg_traded_value_20"] = traded_value.rolling(20, min_periods=10).mean()
    frame["low_52w"] = df_d["low"].rolling(GATE_WEEK_LOOKBACK, min_periods=60).min()
    frame["high_52w"] = df_d["high"].rolling(GATE_WEEK_LOOKBACK, min_periods=60).max()
    return frame


def evaluate_gate_row(
    row: pd.Series,
    pe: float | None = None,
) -> dict:
    """Evaluate all gate metrics for a single bar (informational only).

    Parameters
    ----------
    row : pd.Series
        A row from :func:`compute_gate_frame`.
    pe : float or None
        Trailing PE from the fundamental profile. ``None`` skips G1.

    Returns
    -------
    dict with keys:
        g1_pe, g1_status, g2_avg_traded_value, g2_status,
        g3_dist_from_52w_low, g3_status, g4_dist_to_52w_high, g4_status,
        all_pass (bool — True if every evaluated gate passes).
    Gates NEVER block entry — this is for dashboard display only.
    """
    result: dict = {}

    # G1: PE Sanity
    g1_pe = float(pe) if (pe is not None and not np.isnan(pe)) else None
    g1_status = "OK"
    if g1_pe is not None:
        if g1_pe <= 0:
            g1_status = "FAIL: PE<=0"
        elif g1_pe > PE_MAX:
            g1_status = f"FAIL: PE>{PE_MAX:.0f}"
    result["g1_pe"] = round(g1_pe, 1) if g1_pe is not None else None
    result["g1_status"] = g1_status

    # G2: Liquidity Floor
    av = row.get("avg_traded_value_20", np.nan)
    g2_status = "OK"
    if not np.isnan(av):
        result["g2_avg_traded_value"] = round(float(av), 0)
        if av < MIN_AVG_TRADED_VALUE:
            g2_status = "LOW"
    else:
        result["g2_avg_traded_value"] = None
    result["g2_status"] = g2_status

    # G3: 52W-Low Proximity
    close = row.get("close", np.nan)
    low_52w = row.get("low_52w", np.nan)
    g3_status = "OK"
    g3_dist = None
    if not np.isnan(close) and not np.isnan(low_52w) and low_52w > 0:
        g3_dist = round((close - low_52w) / low_52w * 100, 1)
        if g3_dist > MAX_52W_LOW_DIST * 100:
            g3_status = "FAR"
    result["g3_dist_from_52w_low_pct"] = g3_dist
    result["g3_status"] = g3_status

    # G4: 52W-High Distance
    high_52w = row.get("high_52w", np.nan)
    g4_status = "OK"
    g4_dist = None
    if not np.isnan(close) and not np.isnan(high_52w) and close > 0:
        g4_dist = round(high_52w / close, 2)
        if g4_dist < MIN_52W_HIGH_DIST_MULT:
            g4_status = "NEAR"
    result["g4_dist_to_52w_high_x"] = g4_dist
    result["g4_status"] = g4_status

    # Overall pass/fail (informational — NOT used to block entry)
    result["all_pass"] = all([
        g1_status == "OK",
        g2_status == "OK",
        g3_status == "OK",
        g4_status == "OK",
    ])

    return result

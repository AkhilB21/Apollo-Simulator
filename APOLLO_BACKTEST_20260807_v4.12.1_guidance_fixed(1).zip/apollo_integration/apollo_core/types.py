"""Apollo Core — Type Definitions.
Dataclasses shared across backtest_engine and (future) live_engine.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Any


@dataclass
class TradeEvent:
    """A single completed round-trip trade (entry -> exit)."""
    symbol: str
    entry_date: str
    entry_price: float
    exit_date: str
    exit_price: float
    direction: str                    # "LONG" (or future "SHORT")
    exit_reason: str                  # e.g. "SL Hit", "Target Hit", "RSI Divergence"
    quantity: float = 1.0
    pnl: float = 0.0                  # absolute P&L
    pnl_pct: float = 0.0              # percentage P&L
    holding_days: int = 0
    raw_score: float = 0.0            # entry score
    bucket: str = ""                  # bucket label at entry
    bucket_multiplier: float = 1.0    # multiplier at entry (recorded, not applied in V3.3+)
    ignored_exits: list = field(default_factory=list)  # exits user ignored in live mode


@dataclass
class DailyResult:
    """Per-day signal evaluation result for one stock."""
    date: str
    symbol: str
    raw_score: float
    total_score: float                # = raw_score (bucket decoupled in V3.3+)
    bucket: str = ""
    bucket_multiplier: float = 1.0
    entry_signal: bool = False        # score >= ENTRY_THRESHOLD
    trough_pos: str = ""              # e.g. "0 / 5"
    signals_hit: list = field(default_factory=list)  # which of the 21 signals fired
    ipo_signals_hit: list = field(default_factory=list)


@dataclass
class SignalResult:
    """Result of evaluating all 21 (+ 12 IPO) signals for one bar."""
    date: str
    symbol: str
    raw_total: float                  # sum of all signal weights
    signal_details: dict = field(default_factory=dict)   # {signal_name: weight or 0}
    ipo_raw_total: float = 0.0
    ipo_signal_details: dict = field(default_factory=dict)
    is_ipo_period: bool = False
    weekly_rsi: float = 0.0
    adx: float = 0.0
    atr: float = 0.0
    rsi: float = 0.0


# =========================================================================
# Phase 2 Step 1 — Detect/Execute Split (v3.5)
# These three dataclasses decouple exit-condition *evaluation* from
# exit *execution*. The same detect_exit_triggers() powers both backtest
# (auto-execute via execute_exit) and live mode (advisory alert only).
# =========================================================================

@dataclass
class Position:
    """Mutable position state for a single stock's trade lifecycle.

    A 'fresh' position (not in trade) has ``in_trade=False`` and all
    other fields ``None``. When a trade is opened, ``in_trade=True``
    and the ``entry_*`` / ``peak_*`` fields are populated.

    This dataclass is mutated in-place by ``extract_trades()`` (the loop
    owner) in backtest mode. The pure ``detect_exit_triggers()`` function
    reads it but never mutates it.

    In live mode (Phase 2 Step 2+), the ``SignalMonitor`` mutates the
    same fields, but uses ``cooldown_until_date`` (a ``pd.Timestamp``)
    instead of ``cooldown_until`` (an int bar index), because the bar
    index changes each day as history grows.

    Phase 2 Step 3 (v1.1) adds two fields for human-in-the-loop exit
    confirmation: ``pending_exit`` (True after an EXIT alert is emitted
    but before the user confirms it) and ``pending_exit_payload`` (the
    saved ExitDecision payload, so the dashboard can show the user what
    triggered the exit). These are inert in backtest mode (always False /
    None) and in Step 2's auto-confirm live mode.
    """
    in_trade: bool = False
    entry_price: Optional[float] = None
    entry_date: Any = None              # pd.Timestamp or datetime
    peak_rsi: Optional[float] = None
    peak_rsi_price: Optional[float] = None
    peak_rsi_date: Any = None
    peak_close: Optional[float] = None
    trail_activation_price: Optional[float] = None   # DUAL_SL only
    prev_plus_di: Optional[float] = None
    prev_minus_di: Optional[float] = None
    cooldown_until: Optional[int] = None             # bar index (backtest mode)
    cooldown_until_date: Any = None                  # pd.Timestamp (live mode only)
    # --- Phase 2 Step 3 (v1.1): human-in-the-loop exit confirmation ---
    pending_exit: bool = False                       # True after EXIT alert, before user confirm
    pending_exit_payload: Optional[dict] = None      # saved ExitDecision payload for dashboard


@dataclass
class ExitConfig:
    """Immutable configuration for exit detection.

    Captures all parameters that affect how exits are evaluated.
    Built once per backtest run; passed (read-only) to
    ``detect_exit_triggers()``.
    """
    exit_mode: str = "FIXED_SL"
    sl_percent: float = 5.0
    trailing_sl_percent: float = 3.0
    trailing_activate_pct: float = 5.0
    divergence_rsi_drop: float = 3.0
    divergence_cooldown: int = 5
    exit_threshold: float = 50.0
    entry_threshold: float = 70.0

    @property
    def hard_sl_mult(self) -> float:
        return 1.0 - self.sl_percent / 100.0 if self.sl_percent > 0 else 0.0

    @property
    def trail_sl_mult(self) -> float:
        return (1.0 - self.trailing_sl_percent / 100.0
                if self.trailing_sl_percent > 0 else 0.0)


@dataclass
class ExitDecision:
    """Output of ``detect_exit_triggers()``.

    Pure data — no side effects. The caller decides whether to:

    * **Backtest**: call ``execute_exit()`` to apply the decision
      (append EXIT event, reset position, set cooldown).
    * **Live**: emit an advisory alert without auto-executing.

    When ``should_exit=False``, all other fields are at their defaults
    (``None`` / empty list / ``False``).
    """
    should_exit: bool = False
    fill_price: Optional[float] = None
    primary_reason: Optional[str] = None
    primary_class: Optional[str] = None
    all_triggered_reasons: list = field(default_factory=list)

    # Individual trigger flags (for analytics / alert enrichment)
    hard_sl_hit: bool = False
    trail_sl_hit: bool = False
    div_hit: bool = False
    di_hit: bool = False
    score_hit: bool = False

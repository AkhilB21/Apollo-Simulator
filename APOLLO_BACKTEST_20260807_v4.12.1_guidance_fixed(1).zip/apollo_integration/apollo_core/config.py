"""Apollo Central Configuration (v4.12)

Single source of truth for:
  1. Central Data Repository path (shared across all build versions)
  2. Symbol classification (Stock / SME / Index)
  3. Bucket classification cache directory

All build versions read from the same APOLLO_DATA_ROOT directory.

Usage::

    from apollo_core.config import APOLLO_DATA_ROOT, is_sme_symbol, is_index_symbol
    is_sme_symbol("LLOYDSME")   # True
    is_index_symbol("NIFTY 50")  # True
    symbol_type("RELIANCE")      # "stock"
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Literal


# =====================================================================
# CENTRAL DATA REPOSITORY
# =====================================================================
# All build versions point here. Edit APOLLO_DATA_ROOT to match your
# system, or set the APOLLO_DATA_ROOT environment variable.
#
# Central Data Repository: APOLLO_DATA_REPOSITORY
#   C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\APOLLO_DATA_REPOSITORY\
#     +-- *.parquet          (all OHLCV data - daily, flat)
#     +-- manifest.json      (auto-managed by data_repo)
#     +-- bucket_cache\
#     +-- metadata\

APOLLO_DATA_ROOT = os.environ.get(
    "APOLLO_DATA_ROOT",
    r"C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\APOLLO_DATA_REPOSITORY",
)


def get_data_root() -> Path:
    """Return the central data repository root path."""
    return Path(APOLLO_DATA_ROOT)


def get_bucket_cache_dir() -> Path:
    """Return path to bucket classification cache directory.

    Creates the directory if it doesn't exist.
    """
    d = get_data_root() / "bucket_cache"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_metadata_dir() -> Path:
    """Return path to metadata directory."""
    d = get_data_root() / "metadata"
    d.mkdir(parents=True, exist_ok=True)
    return d


# =====================================================================
# SYMBOL CLASSIFICATION
# =====================================================================

def is_sme_symbol(symbol: str) -> bool:
    """Check if a symbol belongs to NSE Emerge (SME exchange)."""
    s = symbol.upper()
    return s.endswith("SME")


KNOWN_INDEX_SYMBOLS: set[str] = {
    # --- Major Indices ---
    "NIFTY 50",
    "NIFTY 50 TR",
    "NIFTY NEXT 50",
    "NIFTY 100",
    "NIFTY 200",
    "NIFTY 500",
    "NIFTY MIDCAP 150",
    "BANK NIFTY",
    "NIFTY BANK",
    # --- Sectoral Indices ---
    "NIFTY IT",
    "NIFTY PHARMA",
    "NIFTY AUTO",
    "NIFTY FMCG",
    "NIFTY MEDIA",
    "NIFTY METAL",
    "NIFTY ENERGY",
    "NIFTY REALTY",
    "NIFTY INFRA",
    "NIFTY COMMODITIES",
    "NIFTY CONSUMPTION",
    "NIFTY HEALTHCARE",
    "NIFTY FIN SERVICE",
    "NIFTY FINANCIAL SERVICES",
    "NIFTY PSE",
    "NIFTY MNC",
    "NIFTY SERVICES SECTOR",
    "NIFTY DIVIDEND OPPORTUNITIES 50",
    # --- Broad Market ---
    "NIFTY LARGE CAP 100",
    "NIFTY MIDCAP 100",
    "NIFTY MIDCAP 50",
    "NIFTY SMALLCAP 100",
    "NIFTY SMALLCAP 250",
    "NIFTY SMALLCAP 50",
    "NIFTY LARGEMIDCAP 250",
    "NIFTY MICROCAP 250",
    # --- Strategy / Factor ---
    "NIFTY ALPHA 50",
    "NIFTY LOW VOLATILITY 50",
    "NIFTY100 ESG",
    "NIFTY200 MOMENTUM 30",
    "NIFTY GROWSECT 15",
    "NIFTY VALUE 50",
    "NIFTY QUALITY 30",
    # --- Thematic ---
    "NIFTY HOUSING",
    "NIFTY INFRASTRUCTURE",
    "NIFTY PVT BANK",
    "NIFTY PSU BANK",
    "NIFTY INDIA MANUFACTURING",
    "NIFTY MEGA CAP 50",
    # --- Volatility ---
    "INDIA VIX",
}


def is_index_symbol(symbol: str) -> bool:
    """Check if a symbol is a known NSE index."""
    return symbol.upper() in KNOWN_INDEX_SYMBOLS


SymbolType = Literal["stock", "sme", "index"]


def symbol_type(symbol: str) -> SymbolType:
    """Classify a symbol into 'stock', 'sme', or 'index'."""
    if is_sme_symbol(symbol):
        return "sme"
    if is_index_symbol(symbol):
        return "index"
    return "stock"


def filter_symbols_by_type(
    items: list[dict],
    keep_types: list[str] | None = None,
) -> list[dict]:
    """Filter a list of stock info dicts by symbol type."""
    if keep_types is None:
        keep_types = ["stock"]
    keep_set = {t.lower() for t in keep_types}
    return [i for i in items if symbol_type(i["symbol"]) in keep_set]


def filter_symbol_names_by_type(
    symbols: list[str],
    keep_types: list[str] | None = None,
) -> list[str]:
    """Filter a list of symbol strings by type."""
    if keep_types is None:
        keep_types = ["stock"]
    keep_set = {t.lower() for t in keep_types}
    return [s for s in symbols if symbol_type(s) in keep_set]


# =====================================================================
# BUCKET CACHE
# =====================================================================

def save_bucket_cache(
    classifications: list[dict],
    data_dir: str = "",
) -> Path:
    """Save bucket classification results to the central cache."""
    cache_dir = get_bucket_cache_dir()
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    cache_file = cache_dir / f"bucket_classification_{ts}.json"

    cache_data = {
        "timestamp": datetime.now().isoformat(),
        "apollo_version": "4.12",
        "n_classified": len(classifications),
        "data_dir": data_dir,
        "classifications": classifications,
    }

    with open(cache_file, "w", encoding="utf-8") as f:
        json.dump(cache_data, f, indent=2, default=str)

    return cache_file


def load_latest_bucket_cache() -> dict | None:
    """Load the most recent bucket classification cache file."""
    cache_dir = get_bucket_cache_dir()
    cache_files = sorted(
        cache_dir.glob("bucket_classification_*.json"),
        reverse=True,
    )
    if not cache_files:
        return None
    try:
        with open(cache_files[0], "r", encoding="utf-8") as f:
            data = json.load(f)
        data["_source_file"] = str(cache_files[0])
        return data
    except Exception:
        return None


def list_bucket_caches(limit: int = 10) -> list[dict]:
    """List recent bucket cache files with metadata."""
    cache_dir = get_bucket_cache_dir()
    cache_files = sorted(
        cache_dir.glob("bucket_classification_*.json"),
        reverse=True,
    )[:limit]
    results = []
    for cf in cache_files:
        try:
            with open(cf, "r", encoding="utf-8") as f:
                data = json.load(f)
            results.append({
                "file": cf.name,
                "timestamp": data.get("timestamp", ""),
                "n_classified": data.get("n_classified", 0),
                "version": data.get("apollo_version", ""),
            })
        except Exception:
            results.append({"file": cf.name, "timestamp": "", "n_classified": 0, "version": ""})
    return results

"""Apollo Core — Fundamentals Loader (v4.7)

Loads per-symbol fundamental data (PE, market cap, industry) from the
user's ``etmoney_stocks_list.json`` export. Used by the G1 valuation gate.

The JSON is a static snapshot (as published by the user). For backtests it
provides the current PE only — historical PE reconstruction is out of scope.
When a symbol is absent from the profile, the G1 gate is skipped (only the
OHLCV-derived gates G2/G3/G4 apply).
"""

from __future__ import annotations

import json
from pathlib import Path

_DEFAULT_PROFILE = Path(__file__).resolve().parent.parent / "etmoney_stocks_list.json"


def load_fundamental_profile(
    path: str | Path | None = None,
) -> dict[str, dict]:
    """Load the etmoney JSON into {SYMBOL: {pe, mkt_cap, industry}}.

    Parameters
    ----------
    path : str or Path or None
        Path to the JSON. Defaults to ``apollo_engine/etmoney_stocks_list.json``.

    Returns
    -------
    dict  mapping uppercase symbol → fundamental profile. Empty if the file
    is missing or unparseable (gates degrade gracefully).
    """
    profile_path = Path(path) if path else _DEFAULT_PROFILE
    if not profile_path.exists():
        return {}

    try:
        with open(profile_path, encoding="utf-8") as fh:
            data = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {}

    entries = data if isinstance(data, list) else data.get("data", data)
    profile: dict[str, dict] = {}
    for row in entries:
        if not isinstance(row, dict):
            continue
        scrip = str(row.get("scripCode", "")).strip().upper()
        if not scrip:
            continue
        pe = row.get("ratioPE")
        profile[scrip] = {
            "pe": float(pe) if isinstance(pe, (int, float)) else None,
            "mkt_cap": row.get("mktCap"),
            "industry": row.get("industryName", ""),
            "mkt_cap_desc": row.get("mktCapDesc", ""),
        }
    return profile

"""Apollo Backtest Studio — XLSX Report Generator.

Creates a multi-sheet Excel workbook from backtest results:
  Sheet 1 "Summary"   — config, portfolio aggregates, stock ranking table
  Sheet 2 "Trade Log" — all trade events across all stocks, colour-coded
  Sheet 3..N          — one sheet per stock with KPIs, trade log, exit breakdown
"""

from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import (
    Alignment,
    Border,
    Font,
    PatternFill,
    Side,
)
from openpyxl.utils import get_column_letter


# ---------------------------------------------------------------------------
# Style constants
# ---------------------------------------------------------------------------
DARK_BLUE = "1F4E79"

title_font = Font(bold=True, size=16, color=DARK_BLUE)
subtitle_font = Font(bold=True, size=12, color=DARK_BLUE)
header_font = Font(bold=True, size=11, color="FFFFFF")
header_fill = PatternFill("solid", fgColor=DARK_BLUE)
green_fill = PatternFill("solid", fgColor="C6EFCE")
red_fill = PatternFill("solid", fgColor="FFC7CE")
orange_fill = PatternFill("solid", fgColor="FCE4D6")
yellow_fill = PatternFill("solid", fgColor="FFFFCC")
pink_fill = PatternFill("solid", fgColor="FFD6D6")
thin_border = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)
default_alignment = Alignment(wrap_text=False, vertical="center")

TRADE_LOG_COLS = [
    "Symbol", "Date", "Type", "Close", "Score",
    "Pool A", "Pool B", "Pool C", "Bonus",
    "Entry Price", "P&L%", "Exit Reason", "Bars from Trough",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_row(ws, row_idx, values, font=None, fill=None, border=True, fmt=None):
    """Write a list of values to a worksheet row starting at column 1."""
    for col_idx, val in enumerate(values, start=1):
        cell = ws.cell(row=row_idx, column=col_idx, value=val)
        cell.border = thin_border if border else Border()
        cell.alignment = default_alignment
        if font:
            cell.font = font
        if fill:
            cell.fill = fill
        if fmt and isinstance(col_idx, int) and fmt.get(col_idx):
            cell.number_format = fmt[col_idx]


def _auto_width(ws, min_width=10, max_width=40):
    """Set column widths based on content (header + first 50 rows)."""
    for col_cells in ws.columns:
        col_letter = get_column_letter(col_cells[0].column)
        max_len = 0
        for cell in col_cells:
            if cell.value is not None:
                max_len = max(max_len, len(str(cell.value)))
        width = min(max(max_len + 2, min_width), max_width)
        ws.column_dimensions[col_letter].width = width


def _trade_row_fill(event: dict) -> PatternFill | None:
    """Return the appropriate fill colour for a trade event row."""
    t = event.get("type", "")
    reason = event.get("exit_reason", "")
    pnl = event.get("pnl", None)

    if t == "ENTRY":
        return green_fill
    if t == "EXIT":
        if "SL" in reason or "TRAILING" in reason:
            return pink_fill
        if "DIVERGENCE" in reason:
            return orange_fill
        if pnl is not None:
            return green_fill if pnl > 0 else red_fill
        return yellow_fill
    # HOLD-*
    return yellow_fill


def _sector_lookup(symbol: str, sector_map: dict[str, str]) -> str:
    """Look up sector from a pre-built map; return empty string if unknown."""
    return sector_map.get(symbol, "")


def _build_sector_map(results: list[dict]) -> dict[str, str]:
    """Try to extract sector info from results if available."""
    m: dict[str, str] = {}
    for r in results:
        sym = r.get("symbol", "")
        sec = r.get("sector", "") or ""
        m[sym] = sec
    return m


def _sheet_name_safe(name: str, max_len: int = 31) -> str:
    """Truncate and sanitize a string for use as an Excel sheet name."""
    # Excel forbids these characters in sheet names
    forbidden = r'[]:*?/\\'
    safe = "".join(c for c in name if c not in forbidden)
    return safe[:max_len] if len(safe) > max_len else safe


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def generate_report(
    results: list[dict],
    start_date: str,
    end_date: str,
    exit_mode: str,
    sl_percent: float,
    entry_threshold: int,
    exit_threshold: int,
    output_path: str,
    data_source: str = "eod2",
) -> str:
    """Generate the XLSX report and write to *output_path*.

    Parameters
    ----------
    results : list[dict]
        Each dict is the output of ``run_stock_backtest``.
    output_path : str
        Filesystem path for the resulting .xlsx file.

    Returns
    -------
    str — the absolute path of the generated file.
    """
    wb = Workbook()

    # ------------------------------------------------------------------
    # Collect aggregate numbers
    # ------------------------------------------------------------------
    sector_map = _build_sector_map(results)

    total_trades = 0
    winning_trades = 0
    losing_trades = 0
    total_cum_pnl = 0.0
    total_avg_pnl = []
    max_drawdowns = []
    all_events: list[dict] = []

    for r in results:
        n = r.get("n_trades", 0)
        total_trades += n
        comp = r.get("completed", [])
        winning_trades += sum(1 for e in comp if e.get("pnl", 0) > 0)
        losing_trades += sum(1 for e in comp if e.get("pnl", 0) <= 0)
        total_cum_pnl += r.get("cum_pnl", 0.0)
        if n > 0:
            total_avg_pnl.append(r.get("avg_pnl_per_trade", 0.0))
        md = r.get("max_drawdown", 0.0)
        if md != 0.0:
            max_drawdowns.append(md)
        for evt in r.get("trades", []):
            evt["symbol"] = r.get("symbol", "")
            all_events.append(evt)

    avg_win_rate = (
        round(winning_trades / total_trades * 100, 1) if total_trades > 0 else 0.0
    )
    avg_pnl_trade = (
        round(sum(total_avg_pnl) / len(total_avg_pnl), 2)
        if total_avg_pnl
        else 0.0
    )
    avg_max_dd = (
        round(sum(max_drawdowns) / len(max_drawdowns), 2)
        if max_drawdowns
        else 0.0
    )

    # Sort events by symbol then date
    all_events.sort(key=lambda e: (e.get("symbol", ""), str(e.get("date", ""))))

    # Sort results by cum_pnl descending for ranking
    ranked = sorted(results, key=lambda r: r.get("cum_pnl", 0.0), reverse=True)

    # ==================================================================
    # SHEET 1: Summary
    # ==================================================================
    ws_sum = wb.active
    ws_sum.title = "Summary"
    row = 1

    # Title
    ws_sum.cell(row=row, column=1, value="Apollo Engine Backtest Report")
    ws_sum.cell(row=row, column=1).font = title_font
    row += 2

    # Config block
    config_items = [
        ("Start Date", start_date),
        ("End Date", end_date),
        ("Exit Mode", exit_mode),
        ("Stop Loss %", sl_percent),
        ("Entry Threshold", entry_threshold),
        ("Exit Threshold", exit_threshold),
        ("Data Source", data_source),
        ("Number of Stocks", len(results)),
        ("Report Generated", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    ]
    ws_sum.cell(row=row, column=1, value="Configuration")
    ws_sum.cell(row=row, column=1).font = subtitle_font
    row += 1
    for label, val in config_items:
        ws_sum.cell(row=row, column=1, value=label).font = Font(bold=True)
        ws_sum.cell(row=row, column=1).border = thin_border
        c = ws_sum.cell(row=row, column=2, value=val)
        c.border = thin_border
        row += 1
    row += 1

    # Portfolio Aggregates
    ws_sum.cell(row=row, column=1, value="Portfolio Aggregates")
    ws_sum.cell(row=row, column=1).font = subtitle_font
    row += 1
    agg_items = [
        ("Total Trades", total_trades),
        ("Winning Trades", winning_trades),
        ("Losing Trades", losing_trades),
        ("Win Rate", f"{avg_win_rate}%"),
        ("Avg P&L / Trade", f"{avg_pnl_trade}%"),
        ("Total Cumulative P&L", f"{total_cum_pnl:.2f}%"),
        ("Average Max Drawdown", f"{avg_max_dd}%"),
    ]
    for label, val in agg_items:
        ws_sum.cell(row=row, column=1, value=label).font = Font(bold=True)
        ws_sum.cell(row=row, column=1).border = thin_border
        ws_sum.cell(row=row, column=1).fill = PatternFill("solid", fgColor="D6E4F0")
        c = ws_sum.cell(row=row, column=2, value=val)
        c.border = thin_border
        c.fill = PatternFill("solid", fgColor="D6E4F0")
        row += 1
    row += 1

    # Stock Ranking Table
    ws_sum.cell(row=row, column=1, value="Stock Ranking")
    ws_sum.cell(row=row, column=1).font = subtitle_font
    row += 1

    rank_headers = [
        "Rank", "Symbol", "CMP (₹)", "Sector", "Trades", "Entries", "Exits (completed)",
        "Win Rate%", "Period Low (₹)", "Recovery from Low%", "Cum P&L%", "Avg Score", "Peak Score",
        "Max DD%", "SL Exits", "Div Exits", "Score Exits",
    ]
    for ci, h in enumerate(rank_headers, start=1):
        c = ws_sum.cell(row=row, column=ci, value=h)
        c.font = header_font
        c.fill = header_fill
        c.border = thin_border
        c.alignment = Alignment(horizontal="center", vertical="center")
    row += 1

    for rank, r in enumerate(ranked, start=1):
        comp = r.get("completed", [])
        entries = r.get("entries", [])
        sl_ex = r.get("sl_exits", [])
        div_ex = r.get("div_exits", [])
        score_ex = r.get("score_exits", [])

        # Compute avg and peak score from trades
        scores = [e.get("score", 0) for e in r.get("trades", []) if e.get("score") is not None]
        avg_score = round(sum(scores) / len(scores), 2) if scores else 0.0
        peak_score = round(max(scores), 2) if scores else 0.0

        values = [
            rank,
            r.get("symbol", ""),
            r.get("cmp", 0.0),
            sector_map.get(r.get("symbol", ""), ""),
            r.get("n_trades", 0),
            len(entries),
            len(comp),
            r.get("win_rate", 0.0),
            r.get("period_low", 0.0),
            r.get("recovery_pct", 0.0),
            round(r.get("cum_pnl", 0.0), 2),
            avg_score,
            peak_score,
            round(r.get("max_drawdown", 0.0), 2),
            len(sl_ex),
            len(div_ex),
            len(score_ex),
        ]
        pnl_val = r.get("cum_pnl", 0.0)
        row_fill = green_fill if pnl_val > 0 else (red_fill if pnl_val < 0 else None)

        for ci, val in enumerate(values, start=1):
            c = ws_sum.cell(row=row, column=ci, value=val)
            c.border = thin_border
            c.alignment = default_alignment
            if row_fill:
                c.fill = row_fill
        row += 1

    _auto_width(ws_sum)

    # ==================================================================
    # SHEET 2: Trade Log
    # ==================================================================
    ws_tl = wb.active  # we'll move this — actually let's create properly
    ws_tl = wb.create_sheet("Trade Log", 1)

    # Headers
    for ci, h in enumerate(TRADE_LOG_COLS, start=1):
        c = ws_tl.cell(row=1, column=ci, value=h)
        c.font = header_font
        c.fill = header_fill
        c.border = thin_border
        c.alignment = Alignment(horizontal="center", vertical="center")

    for ri, evt in enumerate(all_events, start=2):
        pnl = evt.get("pnl")
        row_vals = [
            evt.get("symbol", ""),
            str(evt.get("date", "")),
            evt.get("type", ""),
            round(evt.get("close", 0), 2),
            evt.get("score", ""),
            evt.get("pool_a", ""),
            evt.get("pool_b", ""),
            evt.get("pool_c", ""),
            evt.get("bonus", ""),
            round(evt.get("entry_price", 0), 2) if evt.get("entry_price") else "",
            round(pnl, 2) if pnl is not None else "",
            evt.get("exit_reason", ""),
            evt.get("bars_from_trough", ""),
        ]
        fill = _trade_row_fill(evt)
        for ci, val in enumerate(row_vals, start=1):
            c = ws_tl.cell(row=ri, column=ci, value=val)
            c.border = thin_border
            c.alignment = default_alignment
            if fill:
                c.fill = fill

    _auto_width(ws_tl)

    # ==================================================================
    # SHEETS 3..N: One per stock
    # ==================================================================
    for r in results:
        sym = r.get("symbol", "UNKNOWN")
        sheet_name = _sheet_name_safe(sym)
        ws = wb.create_sheet(sheet_name)

        comp = r.get("completed", [])
        entries = r.get("entries", [])
        trades = r.get("trades", [])
        sl_ex = r.get("sl_exits", [])
        div_ex = r.get("div_exits", [])
        score_ex = r.get("score_exits", [])
        period_ex = r.get("period_end_exits", [])

        # Compute scores
        scores = [e.get("score", 0) for e in trades if e.get("score") is not None]
        avg_score = round(sum(scores) / len(scores), 2) if scores else 0.0
        peak_score = round(max(scores), 2) if scores else 0.0

        row = 1

        # Stock header
        ws.cell(row=row, column=1, value=sym)
        ws.cell(row=row, column=1).font = title_font
        row += 1
        ws.cell(row=row, column=1, value=f"Sector: {sector_map.get(sym, 'N/A')}")
        row += 1
        ws.cell(row=row, column=1, value=f"Date Range: {start_date} to {end_date}")
        row += 1
        n_days = r.get("n_days", 0)
        ws.cell(row=row, column=1, value=f"Trading Days: {n_days}")
        row += 2

        # KPIs
        kpis = [
            ("Entries", len(entries)),
            ("Completed Exits", len(comp)),
            ("Win Rate", f"{r.get('win_rate', 0.0)}%"),
            ("Cumulative P&L", f"{round(r.get('cum_pnl', 0.0), 2)}%"),
            ("Avg P&L / Trade", f"{round(r.get('avg_pnl_per_trade', 0.0), 2)}%"),
            ("Max Drawdown", f"{round(r.get('max_drawdown', 0.0), 2)}%"),
            ("Average Score", avg_score),
            ("Peak Score", peak_score),
        ]
        ws.cell(row=row, column=1, value="Key Performance Indicators")
        ws.cell(row=row, column=1).font = subtitle_font
        row += 1
        for label, val in kpis:
            ws.cell(row=row, column=1, value=label).font = Font(bold=True)
            ws.cell(row=row, column=1).border = thin_border
            ws.cell(row=row, column=1).fill = PatternFill("solid", fgColor="D6E4F0")
            c = ws.cell(row=row, column=2, value=val)
            c.border = thin_border
            c.fill = PatternFill("solid", fgColor="D6E4F0")
            row += 1
        row += 1

        # Full trade log
        ws.cell(row=row, column=1, value="Trade Log")
        ws.cell(row=row, column=1).font = subtitle_font
        row += 1

        for ci, h in enumerate(TRADE_LOG_COLS, start=1):
            c = ws.cell(row=row, column=ci, value=h)
            c.font = header_font
            c.fill = header_fill
            c.border = thin_border
            c.alignment = Alignment(horizontal="center", vertical="center")
        row += 1

        for evt in trades:
            pnl = evt.get("pnl")
            row_vals = [
                sym,
                str(evt.get("date", "")),
                evt.get("type", ""),
                round(evt.get("close", 0), 2),
                evt.get("score", ""),
                evt.get("pool_a", ""),
                evt.get("pool_b", ""),
                evt.get("pool_c", ""),
                evt.get("bonus", ""),
                round(evt.get("entry_price", 0), 2) if evt.get("entry_price") else "",
                round(pnl, 2) if pnl is not None else "",
                evt.get("exit_reason", ""),
                evt.get("bars_from_trough", ""),
            ]
            fill = _trade_row_fill(evt)
            for ci, val in enumerate(row_vals, start=1):
                c = ws.cell(row=row, column=ci, value=val)
                c.border = thin_border
                c.alignment = default_alignment
                if fill:
                    c.fill = fill
            row += 1
        row += 1

        # Exit Type Breakdown
        ws.cell(row=row, column=1, value="Exit Type Breakdown")
        ws.cell(row=row, column=1).font = subtitle_font
        row += 1

        exit_headers = ["Exit Type", "Count", "Avg P&L%"]
        for ci, h in enumerate(exit_headers, start=1):
            c = ws.cell(row=row, column=ci, value=h)
            c.font = header_font
            c.fill = header_fill
            c.border = thin_border
        row += 1

        exit_groups = [
            ("SL Exits", sl_ex),
            ("Divergence Exits", div_ex),
            ("Score Exits", score_ex),
            ("Period-End Exits", period_ex),
        ]
        for label, group in exit_groups:
            count = len(group)
            avg_p = (
                round(sum(e["pnl"] for e in group) / count, 2) if count > 0 else 0.0
            )
            for ci, val in enumerate([label, count, avg_p], start=1):
                c = ws.cell(row=row, column=ci, value=val)
                c.border = thin_border
            row += 1

        _auto_width(ws)

    # ------------------------------------------------------------------
    # Write to disk
    # ------------------------------------------------------------------
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(out))
    return str(out.resolve())
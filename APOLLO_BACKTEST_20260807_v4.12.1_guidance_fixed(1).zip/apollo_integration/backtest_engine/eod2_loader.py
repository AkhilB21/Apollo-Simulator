"""Apollo Data Loader -- Parquet-first with CSV fallback (v4.8).

Loads daily OHLCV data from the Central Parquet Repository (``apollo_data/``)
or falls back to eod2 CSV files if Parquet is not available.

Auto-detection: if ``data_dir`` contains ``*.parquet`` files, reads from Parquet.
Otherwise reads from ``*.csv`` files (legacy eod2 format).

Provides:
  - scan_data_directory:  inventory all data files (Parquet or CSV)
  - load_eod2_stock:       load a single stock, compute indicators, return
                        (daily_df, fourh_df, weekly_df)
  - scan_eod2_directory:  legacy alias, still works
"""

import os
from pathlib import Path

import numpy as np
import pandas as pd

from apollo_core.indicators import compute_all_indicators

# v4.8: Central Parquet Data Repository
try:
    from data_repo import load_daily as _load_parquet_daily
    _PARQUET_AVAILABLE = True
except ImportError:
    _PARQUET_AVAILABLE = False


# ---------------------------------------------------------------------------
# Indicator alias mapping (Apollo column name -> engine-friendly short name)
# ---------------------------------------------------------------------------
_APOLLO_ALIAS_MAP = {
    "RSI rsi (21,C)":            "rsi21",
    "RSI rsi (36)":              "rsi36",
    "RSI rsi (56)":              "rsi56",
    "Result Typical Price (28,n)": "tp28",
    "Result Weighted Close (50,y)": "wc50",
    "Result Weighted Close (21)":   "wc21",
    "+DI ADX (14,14,y,n)":      "plus_di",
    "-DI ADX (14,14,y,n)":      "minus_di",
    "ADX ADX (14,14,y,n)":      "adx",
    "ATR (14)":               "atr",
    "MACD macd (12,26,9)":      "macd",
    "Signal macd (12,26,9)":    "macd_sig",
    "macd (12,26,9)_hist":      "macd_hist",
    "Stoch %K (14,3)":          "stoch_k",
    "Stoch %D (14,3)":          "stoch_d",
    "VPT (1)":                  "vpt",
    "SMA (50)":                 "sma50",
    "SMA (20)":                 "sma20",
}

_REQUIRED_ALIASES = [
    "rsi21", "rsi36", "rsi56", "tp28", "wc21", "wc50",
    "plus_di", "minus_di", "adx", "macd", "macd_sig", "macd_hist",
    "stoch_k", "stoch_d", "vpt", "sma50", "sma20",
]

OHLCV_COLS = ["open", "high", "low", "close", "volume"]


def _add_indicator_aliases(df: pd.DataFrame) -> pd.DataFrame:
    """Map compute_all_indicators output columns to short lowercase aliases."""
    for apollo_col, alias in _APOLLO_ALIAS_MAP.items():
        if apollo_col in df.columns:
            df[alias] = df[apollo_col]
    return df


# ---------------------------------------------------------------------------
# Data source detection
# ---------------------------------------------------------------------------

def _is_parquet_repo(data_dir: str) -> bool:
    """Check if data_dir contains Parquet files (Central Repository)."""
    p = Path(data_dir)
    if not p.is_dir():
        return False
    return any(p.glob("*.parquet"))


def _scan_parquet_directory(data_dir: str) -> list[dict]:
    """Scan a Parquet repository directory."""
    data_path = Path(data_dir)
    results = []
    for pq_file in sorted(data_path.glob("*.parquet")):
        try:
            df = pd.read_parquet(pq_file)
            if df.empty:
                continue
            symbol = pq_file.stem.upper()
            date_col = df.index if isinstance(df.index, pd.DatetimeIndex) else df.get("date")
            if date_col is None:
                continue
            results.append({
                "filename": pq_file.name,
                "symbol": symbol,
                "rows": len(df),
                "date_start": str(pd.Timestamp(date_col.min()).date()),
                "date_end": str(pd.Timestamp(date_col.max()).date()),
            })
        except Exception:
            continue
    return results


def _scan_csv_directory(data_dir: str) -> list[dict]:
    """Scan a directory for CSV files in eod2 format (legacy)."""
    data_path = Path(data_dir)
    results = []
    for csv_file in sorted(data_path.glob("*.csv")):
        try:
            df = pd.read_csv(csv_file, nrows=5)
            # Find date column
            date_col = None
            for candidate in ("Date", "date", "DATE", "Timestamp", "timestamp"):
                if candidate in df.columns:
                    date_col = candidate
                    break
            if date_col is None:
                continue
            full = pd.read_csv(csv_file)
            full[date_col] = pd.to_datetime(full[date_col], errors="coerce")
            full = full.dropna(subset=[date_col])
            if full.empty:
                continue
            symbol = csv_file.stem
            results.append({
                "filename": csv_file.name,
                "symbol": symbol,
                "rows": len(full),
                "date_start": str(full[date_col].min().date()),
                "date_end": str(full[date_col].max().date()),
            })
        except Exception:
            continue
    return results


def scan_data_directory(data_dir: str) -> list[dict]:
    """Scan a data directory for Parquet or CSV files.

    Auto-detects format: if *.parquet files exist, scans those.
    Otherwise falls back to *.csv (legacy eod2 format).

    Returns a list of dicts with keys:
        filename, symbol, rows, date_start, date_end
    """
    if _is_parquet_repo(data_dir) and _PARQUET_AVAILABLE:
        return _scan_parquet_directory(data_dir)
    return _scan_csv_directory(data_dir)


def scan_eod2_directory(data_dir: str) -> list[dict]:
    """Legacy alias -- auto-detects Parquet or CSV."""
    return scan_data_directory(data_dir)


def _synthesize_4h_from_daily(df_daily: pd.DataFrame) -> pd.DataFrame:
    """Synthesize 4H bars from daily OHLCV data (vectorized).

    Produces 2 deterministic 4H bars per NSE session:
      - Bar 1 (09:15): open = daily open, close ~ midpoint
      - Bar 2 (13:15): open ~ midpoint, close = daily close

    Volume split: ~55% morning / ~45% afternoon.
    High/Low distribution uses a deterministic hash of the date.
    """
    # Drop rows with any NaN in OHLCV
    df = df_daily[["open", "high", "low", "close", "volume"]].dropna(
        subset=["close"]
    )
    if df.empty:
        return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])

    o = df["open"].values
    h = df["high"].values
    l = df["low"].values
    c = df["close"].values
    v = df["volume"].values
    n = len(df)

    mid = (o + c) / 2.0

    # Deterministic morning/afternoon fraction based on date hash
    dates = df.index
    date_hashes = np.array(
        [int(pd.Timestamp(d).strftime("%Y%m%d")) for d in dates], dtype=np.int64
    )
    morning_frac = 0.55 + 0.10 * ((date_hashes % 7) / 7.0 - 0.5)
    afternoon_frac = 1.0 - morning_frac

    max_oc = np.maximum(o, c)
    min_oc = np.minimum(o, c)
    range_above = h - max_oc
    range_below = min_oc - l

    # Morning session
    m_open = o
    m_close = mid
    m_high = np.maximum(o, mid) + range_above * morning_frac
    m_low = np.minimum(o, mid) - range_below * morning_frac
    m_vol = v * morning_frac

    # Afternoon session
    a_open = mid
    a_close = c
    a_high = np.maximum(mid, c) + range_above * afternoon_frac
    a_low = np.minimum(mid, c) - range_below * afternoon_frac
    a_vol = v * afternoon_frac

    # Build timestamps
    base_ts = np.array(
        [pd.Timestamp(d).normalize() for d in dates]
    )
    morning_ts = base_ts + pd.Timedelta(hours=9, minutes=15)
    afternoon_ts = base_ts + pd.Timedelta(hours=13, minutes=15)

    # Interleave morning + afternoon rows
    ts_all = np.empty(2 * n, dtype=object)
    ts_all[0::2] = morning_ts
    ts_all[1::2] = afternoon_ts

    open_all = np.empty(2 * n)
    open_all[0::2] = m_open
    open_all[1::2] = a_open

    high_all = np.empty(2 * n)
    high_all[0::2] = m_high
    high_all[1::2] = a_high

    low_all = np.empty(2 * n)
    low_all[0::2] = m_low
    low_all[1::2] = a_low

    close_all = np.empty(2 * n)
    close_all[0::2] = m_close
    close_all[1::2] = a_close

    vol_all = np.empty(2 * n)
    vol_all[0::2] = m_vol
    vol_all[1::2] = a_vol

    result = pd.DataFrame(
        {
            "open": open_all,
            "high": high_all,
            "low": low_all,
            "close": close_all,
            "volume": vol_all,
        },
        index=ts_all,
    )
    return result


def load_eod2_stock(
    data_dir: str,
    symbol: str,
    warmup_days: int = 365,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Load a single stock's data and prepare multi-timeframe DataFrames.

    v4.8: Auto-detects data source. If ``data_dir`` contains ``*.parquet`` files,
    loads from the Central Parquet Repository. Otherwise falls back to
    eod2 CSV files (legacy) with flexible date parsing.

    Steps:
      1. Load OHLCV data (from Parquet or CSV).
      2. Ensure all OHLCV columns exist as float64.
      3. Compute all Apollo indicators via compute_all_indicators.
      4. Add indicator aliases (rsi21, rsi36, etc.).
      5. Synthesize 4H bars from daily data.
      6. Compute indicators on 4H bars and add aliases.
      7. Resample to weekly (W-FRI anchor).
      8. Compute indicators on weekly bars and add aliases.

    Returns
    -------
    (daily_df, fourh_df, weekly_df) -- each with DatetimeIndex and lowercase
    columns: open, high, low, close, volume, rsi21, rsi36, rsi56, tp28,
    wc50, wc21, plus_di, minus_di, adx, macd, macd_sig, macd_hist.
    """
    # --- 1. Load data ---
    if _is_parquet_repo(data_dir) and _PARQUET_AVAILABLE:
        # Parquet path (Central Data Repository)
        try:
            df = _load_parquet_daily(data_dir, symbol)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Parquet not found for {symbol} in {data_dir}. "
                f"Run: python -m data_repo.sync --source-dir <eod2_path> "
                f"--repo-dir {data_dir}"
            )
    else:
        # CSV fallback (legacy eod2) -- v4.8: flexible date parsing
        csv_path = Path(data_dir) / f"{symbol}.csv"
        if not csv_path.exists():
            raise FileNotFoundError(f"Data file not found: {csv_path}")

        df = pd.read_csv(csv_path)
        df.columns = [c.strip() for c in df.columns]

        # Find the date column (flexible -- supports multiple names)
        date_col = None
        for candidate in ("Date", "date", "DATE", "Timestamp", "timestamp"):
            if candidate in df.columns:
                date_col = candidate
                break
        if date_col is None:
            raise ValueError(f"No date column found in {csv_path}")

        # Flexible date parsing (v4.8): try multiple formats
        df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
        df = df.dropna(subset=[date_col])
        if df.empty:
            raise ValueError(f"No valid dates parsed from {csv_path}")

        df = df.set_index(date_col).sort_index()
        df.columns = [c.strip().lower() for c in df.columns]

        # Subset to OHLCV only (drop Series, TOTAL_TRADES, QTY_PER_TRADE, DLV_QTY)
        available = [c for c in OHLCV_COLS if c in df.columns]
        if "close" not in available:
            raise ValueError(f"Missing 'close' column in {csv_path}")
        df = df[available].copy()

    # --- 2. Ensure all OHLCV columns exist as float64 ---
    for col in OHLCV_COLS:
        if col not in df.columns:
            df[col] = 0.0
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["close"])
    df = df.sort_index()

    # --- 3. Compute indicators on daily & add aliases ---
    df = compute_all_indicators(df)
    df = _add_indicator_aliases(df)
    daily_df = df

    # --- 4. Synthesize 4H, compute indicators, add aliases ---
    df_4h = _synthesize_4h_from_daily(daily_df)
    df_4h = compute_all_indicators(df_4h)
    df_4h = _add_indicator_aliases(df_4h)
    fourh_df = df_4h

    # --- 5. Resample weekly, compute indicators, add aliases ---
    df_w = daily_df.resample("W-FRI").agg({
        "open": "first",
        "high": "max",
        "low": "min",
        "close": "last",
        "volume": "sum",
    }).dropna(subset=["close"])
    df_w = compute_all_indicators(df_w)
    df_w = _add_indicator_aliases(df_w)
    weekly_df = df_w

    # --- 6. Merge weekly RSI21 into daily frame (forward-fill) ---
    #    The recorder needs rsi21_weekly on the daily DataFrame.
    if "rsi21" in weekly_df.columns:
        w_rsi = weekly_df["rsi21"].reindex(daily_df.index).ffill()
        daily_df["rsi21_weekly"] = w_rsi

    return daily_df, fourh_df, weekly_df

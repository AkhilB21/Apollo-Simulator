"""Guidance Engine — Data Validation (v1.0)

Pre-flight schema checker for trades.parquet.
Run this before the pipeline to catch missing columns, type mismatches,
and inconsistent config hashes early.

Usage::
    from guidance_engine.validate_data import validate_trades_parquet

    issues = validate_trades_parquet("output/trades.parquet")
    if issues["errors"]:
        print(f"BLOCKING: {len(issues['errors'])} errors")
        for e in issues["errors"]:
            print(f"  - {e}")
    if issues["warnings"]:
        print(f"WARNINGS: {len(issues['warnings'])} warnings")
        for w in issues["warnings"]:
            print(f"  - {w}")
"""

from __future__ import annotations

import logging
import os

import pandas as pd

from guidance_engine.recorder import TRADES_REQUIRED_COLUMNS, TRADES_OPTIONAL_COLUMNS

logger = logging.getLogger(__name__)


def validate_trades_parquet(
    parquet_path: str,
) -> dict:
    """Validate a trades.parquet file against the expected schema.

    Returns
    -------
    dict with keys:
        valid: bool          — True if no errors
        n_rows: int           — number of rows in the file
        errors: list[str]     — blocking issues
        warnings: list[str]   — non-blocking issues
        columns_present: list[str]
        columns_missing: list[str]
    """
    result = {
        "valid": True,
        "n_rows": 0,
        "errors": [],
        "warnings": [],
        "columns_present": [],
        "columns_missing": [],
    }

    if not os.path.isfile(parquet_path):
        result["errors"].append(f"File not found: {parquet_path}")
        result["valid"] = False
        return result

    try:
        df = pd.read_parquet(parquet_path)
    except Exception as e:
        result["errors"].append(f"Failed to read parquet: {e}")
        result["valid"] = False
        return result

    result["n_rows"] = len(df)
    result["columns_present"] = sorted(df.columns.tolist())

    # Check required columns
    for col in TRADES_REQUIRED_COLUMNS:
        if col not in df.columns:
            result["columns_missing"].append(col)
            result["errors"].append(f"Missing required column: {col}")
            result["valid"] = False

    # Check for common dead-column indicators
    if "atr_pct_entry" in df.columns:
        if df["atr_pct_entry"].notna().any() and (df["atr_pct_entry"] == 0.0).all():
            result["warnings"].append(
                "atr_pct_entry is all 0.0 — ATR alias may be missing in eod2_loader.py"
            )

    if "rsi21_weekly_entry" in df.columns:
        if df["rsi21_weekly_entry"].notna().any() and (df["rsi21_weekly_entry"] == 0.0).all():
            result["warnings"].append(
                "rsi21_weekly_entry is all 0.0 — weekly RSI merge may be missing"
            )

    # Check for duplicate (symbol, entry_date, config_hash) rows
    key_cols = ["symbol", "entry_date", "config_hash"]
    if all(c in df.columns for c in key_cols):
        n_dupes = df.duplicated(subset=key_cols).sum()
        if n_dupes > 0:
            result["warnings"].append(
                f"Found {n_dupes} duplicate (symbol, entry_date, config_hash) rows — "
                "dedup should handle this on next write"
            )

    # Check config_hash consistency
    if "config_hash" in df.columns:
        n_hashes = df["config_hash"].nunique()
        if n_hashes > 3:
            result["warnings"].append(
                f"{n_hashes} distinct config_hash values — consider archiving old runs"
            )

    # Check for all-NEUTRAL regime (common if ensure_data() not called)
    if "regime_label" in df.columns:
        if (df["regime_label"] == "NEUTRAL").all():
            result["warnings"].append(
                "All regime_label values are NEUTRAL — ensure_data() may not have been called"
            )

    if result["errors"]:
        logger.error(f"validate_trades_parquet: {len(result['errors'])} errors")
    if result["warnings"]:
        logger.warning(f"validate_trades_parquet: {len(result['warnings'])} warnings")

    return result

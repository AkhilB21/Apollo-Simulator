"""Guidance Engine — Stock Profile Analyzer (v1.2)

Reads trades.parquet, computes per-stock behavioral profiles,
and writes:
  - profiles/{SYMBOL}.parquet (machine-readable)
  - profiles/{SYMBOL}.md (human-readable)

v1.2 changes:
  - Staleness checks both config_hash AND data_cutoff
  - Computes buy-and-hold benchmark and alpha
  - Computes post-exit opportunity cost metrics
  - Uses column-subset read for efficiency
  - Time-decay weighting for recent trades

Usage::
    from guidance_engine.analyzer import build_all_profiles, build_single_profile

    build_all_profiles(trades_parquet_path, profiles_dir, config_hash, data_cutoff)
"""

from __future__ import annotations

import json
import logging
import math
import os
from datetime import date
from typing import Optional

import numpy as np
import pandas as pd

from guidance_engine.schemas import (
    StockProfile,
    FLAG_CATALOG,
    MIN_TRADES_FOR_PROFILE,
    MIN_REGIME_N,
    RSI_OVERBOUGHT,
    POST_DIV_REENTRY_BARS,
    ENGINE_VERSION,
)
from guidance_engine.mae_mfe import compute_mae_mfe_report

logger = logging.getLogger(__name__)


# Columns to read from trades.parquet (avoids loading full wide frame)
_TRADES_COLUMNS = [
    "symbol", "bucket", "entry_date", "exit_date",
    "entry_price", "exit_price", "pnl_pct",
    "entry_score", "entry_total", "pool_a", "pool_b", "pool_c", "pool_r",
    "bonus_total",
    "rsi21_entry", "rsi21_weekly_entry", "adx_entry", "atr_pct_entry",
    "bars_from_trough", "dist_from_52w_high_pct", "dist_from_52w_low_pct",
    "volume_zscore_entry", "signals_fired", "n_signals_fired",
    "bars_since_prior_exit", "prior_exit_reason", "entry_above_prior_exit_price",
    "nifty_above_50dma", "nifty_above_200dma", "india_vix_regime", "regime_label",
    "exit_reason", "exit_reason_full", "sl_pct", "exit_mode",
    "mae_daily", "mfe_daily", "mae_intraday_est", "exit_slippage_est",
    "bars_held", "consecutive_loss_count",
    "config_hash", "data_cutoff", "engine_version", "run_id",
    "post_exit_bars_to_next", "post_exit_pnl_next",
    "bh_return_pct", "alpha_vs_bh_pct",
]


def build_all_profiles(
    trades_parquet_path: str,
    profiles_dir: str,
    current_config_hash: str,
    current_data_cutoff: str,
    current_engine_version: str = "4.12",
) -> dict[str, StockProfile]:
    """Build profiles for all symbols in trades.parquet.

    Parameters
    ----------
    trades_parquet_path : str
        Path to the append-only trades.parquet.
    profiles_dir : str
        Directory for profile output files.
    current_config_hash : str
        The config hash of the current run (for staleness check).
    current_data_cutoff : str
        The data cutoff date of the current run.
    current_engine_version : str
        Engine version of the current run.

    Returns
    -------
    dict[str, StockProfile] — symbol -> profile
    """
    if not os.path.isfile(trades_parquet_path):
        logger.warning(f"trades.parquet not found: {trades_parquet_path}")
        return {}

    try:
        df = pd.read_parquet(trades_parquet_path, columns=_TRADES_COLUMNS)
    except Exception:
        # Fallback: read all columns if subset fails (backward compat)
        df = pd.read_parquet(trades_parquet_path)

    if df.empty:
        return {}

    # Filter to the latest config hash run for analysis
    latest = df[df["config_hash"] == current_config_hash]
    if latest.empty:
        latest = df

    os.makedirs(profiles_dir, exist_ok=True)
    profiles = {}

    for symbol, group in latest.groupby("symbol"):
        profile = build_single_profile(
            symbol, group,
            current_config_hash=current_config_hash,
            current_data_cutoff=current_data_cutoff,
            current_engine_version=current_engine_version,
        )
        profiles[symbol] = profile

        _write_profile_parquet(profile, profiles_dir)
        _write_profile_markdown(profile, profiles_dir)

    return profiles


def build_single_profile(
    symbol: str,
    trades_df: pd.DataFrame,
    current_config_hash: str = "",
    current_data_cutoff: str = "",
    current_engine_version: str = "4.12",
) -> StockProfile:
    """Build a behavioral profile for one symbol."""
    # --- Staleness check: both config_hash AND data_cutoff ---
    is_stale = False
    if current_config_hash and current_data_cutoff:
        if "config_hash" in trades_df.columns:
            is_stale = trades_df["config_hash"].iloc[0] != current_config_hash
        if not is_stale and "data_cutoff" in trades_df.columns:
            profile_cutoff = str(trades_df["data_cutoff"].iloc[0])
            if profile_cutoff and current_data_cutoff:
                is_stale = profile_cutoff != current_data_cutoff

    profile = StockProfile(
        symbol=symbol,
        bucket=str(trades_df["bucket"].mode().iloc[0]) if "bucket" in trades_df.columns and not trades_df["bucket"].mode().empty else "",
        n_trades=len(trades_df),
        engine_version=current_engine_version,
        config_hash=current_config_hash,
        data_cutoff=current_data_cutoff,
        is_stale=is_stale,
    )

    if trades_df.empty:
        profile.flags.append("LOW_SAMPLE_SIZE")
        return profile

    n = profile.n_trades

    # --- Time-decay weights (recent trades weighted more) ---
    weights = _time_decay_weights(n)

    # --- Execution Quality ---
    wins = trades_df[trades_df["pnl_pct"] > 0]
    profile.win_rate = round(len(wins) / n * 100, 1) if n > 0 else 0.0
    profile.avg_pnl_pct = round(float((trades_df["pnl_pct"] * weights).sum() / weights.sum()), 2)
    profile.avg_bars_held = round(float(trades_df["bars_held"].mean()), 1)

    # Exit reason distribution
    if "exit_reason" in trades_df.columns:
        exit_counts = trades_df["exit_reason"].value_counts()
        profile.exit_reason_dist = {
            reason: round(count / n * 100, 1)
            for reason, count in exit_counts.items()
        }

    # MAE/MFE
    profile.avg_mae_daily = round(float(trades_df["mae_daily"].mean()), 2)
    profile.avg_mfe_daily = round(float(trades_df["mfe_daily"].mean()), 2)
    profile.mae_mfe_ratio = (
        round(profile.avg_mae_daily / profile.avg_mfe_daily, 2)
        if profile.avg_mfe_daily > 0 else 0.0
    )

    # --- Entry Quality ---
    if len(wins) > 0:
        profile.mean_rsi21_wins = round(float(wins["rsi21_entry"].mean()), 2)
    if len(trades_df[trades_df["pnl_pct"] <= 0]) > 0:
        profile.mean_rsi21_losses = round(
            float(trades_df[trades_df["pnl_pct"] <= 0]["rsi21_entry"].mean()), 2
        )

    profile.overbought_entry_rate = round(
        float((trades_df["rsi21_entry"] > RSI_OVERBOUGHT).sum() / n * 100), 1
    ) if n > 0 else 0.0

    if "prior_exit_reason" in trades_df.columns:
        post_div = trades_df[
            (trades_df["prior_exit_reason"].str.contains("DIVERGENCE", na=False))
            & (trades_df["bars_since_prior_exit"] >= 0)
            & (trades_df["bars_since_prior_exit"] <= POST_DIV_REENTRY_BARS)
        ]
        profile.post_divergence_reentry_rate = round(len(post_div) / n * 100, 1) if n > 0 else 0.0

    if len(wins) > 0:
        profile.mean_score_wins = round(float(wins["entry_total"].mean()), 2)
    losses = trades_df[trades_df["pnl_pct"] <= 0]
    if len(losses) > 0:
        profile.mean_score_losses = round(float(losses["entry_total"].mean()), 2)

    # --- Stock Behavior ---
    profile.mean_atr_pct = round(float(trades_df["atr_pct_entry"].mean()), 2)

    if "exit_slippage_est" in trades_df.columns:
        sl_exits = trades_df[trades_df["exit_reason"] == "HARD_SL"]
        if not sl_exits.empty:
            gapped = sl_exits[sl_exits["exit_slippage_est"] > 0.5]
            profile.gap_down_sl_rate = round(len(gapped) / len(sl_exits) * 100, 1)
            profile.avg_exit_slippage = round(float(sl_exits["exit_slippage_est"].mean()), 2)

    if "consecutive_loss_count" in trades_df.columns:
        profile.consecutive_loss_streak_max = int(trades_df["consecutive_loss_count"].max())

    # --- Buy-and-Hold Benchmark ---
    if "bh_return_pct" in trades_df.columns:
        profile.avg_bh_return_pct = round(float(trades_df["bh_return_pct"].mean()), 2)
    if "alpha_vs_bh_pct" in trades_df.columns:
        profile.avg_alpha_vs_bh_pct = round(float(trades_df["alpha_vs_bh_pct"].mean()), 2)
        alpha_wins = (trades_df["alpha_vs_bh_pct"] > 0).sum()
        profile.alpha_win_rate = round(float(alpha_wins / n * 100), 1) if n > 0 else 0.0

    # --- Post-Exit Opportunity ---
    if "post_exit_bars_to_next" in trades_df.columns:
        # Exclude last trade (-1 sentinel)
        valid = trades_df[trades_df["post_exit_bars_to_next"] >= 0]
        if not valid.empty:
            profile.avg_post_exit_bars_to_next = round(float(valid["post_exit_bars_to_next"].mean()), 1)
            profile.avg_post_exit_pnl_next = round(float(valid["post_exit_pnl_next"].mean()), 2)

    # --- Regime-Conditioned Win Rates ---
    if "regime_label" in trades_df.columns:
        for regime, group in trades_df.groupby("regime_label"):
            if len(group) >= MIN_REGIME_N:
                regime_wins = group[group["pnl_pct"] > 0]
                profile.regime_win_rates[regime] = round(
                    len(regime_wins) / len(group) * 100, 1
                )
                profile.regime_n_trades[regime] = len(group)

    # --- Signal Win Rates ---
    if "signals_fired" in trades_df.columns:
        all_signals = set()
        for sigs_str in trades_df["signals_fired"]:
            if sigs_str and isinstance(sigs_str, str):
                all_signals.update(sigs_str.split("|"))

        for sig in sorted(all_signals):
            trades_with_sig = trades_df[
                trades_df["signals_fired"].str.contains(sig, na=False)
            ]
            if len(trades_with_sig) >= 3:
                sig_wins = trades_with_sig[trades_with_sig["pnl_pct"] > 0]
                profile.signal_win_rates[sig] = round(
                    len(sig_wins) / len(trades_with_sig) * 100, 1
                )
                profile.signal_n_fired[sig] = len(trades_with_sig)

    # --- Flag Detection ---
    _detect_flags(profile, trades_df, n)

    return profile


def _time_decay_weights(n: int, half_life: float = 20.0) -> np.ndarray:
    """Compute exponential time-decay weights.

    Most recent trade gets weight 1.0, oldest gets ~0.
    half_life: number of trades for weight to drop to 50%.
    """
    if n <= 1:
        return np.ones(n)
    indices = np.arange(n)
    # Reverse so index 0 = oldest, n-1 = newest
    weights = np.exp(-math.log(2) * (n - 1 - indices) / half_life)
    return weights


def _detect_flags(profile: StockProfile, df: pd.DataFrame, n: int) -> None:
    """Apply flag rules to a profile.  Mutates profile.flags in place."""
    if n < MIN_TRADES_FOR_PROFILE:
        profile.flags.append("LOW_SAMPLE_SIZE")
        return

    # 1. RSI Entry Risk
    if (profile.mean_rsi21_losses > 0
            and profile.mean_rsi21_wins > 0
            and profile.mean_rsi21_losses - profile.mean_rsi21_wins > 10):
        profile.flags.append("RSI_ENTRY_RISK")

    # 2. Post-Divergence Re-entry
    if profile.post_divergence_reentry_rate > 15:
        profile.flags.append("POST_DIVERGENCE_REENTRY")

    # 3. High Hard SL Rate
    if profile.exit_reason_dist.get("HARD_SL", 0) > 40:
        profile.flags.append("HIGH_HARD_SL_RATE")

    # 4. MAE near SL
    if "sl_pct" in df.columns and df["sl_pct"].iloc[0] > 0:
        sl_pct = df["sl_pct"].iloc[0]
        if profile.avg_mae_daily > 0.8 * sl_pct:
            profile.flags.append("MAE_NEAR_SL")

    # 5. MFE Leakage
    hard_sl_mae = profile.avg_mae_daily
    div_mfe = 0.0
    div_trades = df[df["exit_reason"] == "DIVERGENCE"]
    if not div_trades.empty:
        div_mfe = float(div_trades["mfe_daily"].mean())
    if div_mfe > 0 and hard_sl_mae > 0 and div_mfe > 3 * hard_sl_mae:
        profile.flags.append("MFE_LEAKAGE")

    # 6. Gap-Down Slippage
    if profile.gap_down_sl_rate > 25:
        profile.flags.append("GAP_DOWN_SLIPPAGE")

    # 7. Regime Dependent
    if len(profile.regime_win_rates) >= 2:
        win_rates = list(profile.regime_win_rates.values())
        if max(win_rates) - min(win_rates) > 25:
            profile.flags.append("REGIME_DEPENDENT")

    # 8. Consecutive Losses
    if profile.consecutive_loss_streak_max >= 3:
        profile.flags.append("CONSECUTIVE_LOSSES")

    # 9. Negative Alpha (new in v1.2)
    if profile.avg_alpha_vs_bh_pct < -2.0 and n >= MIN_TRADES_FOR_PROFILE:
        profile.flags.append("NEGATIVE_ALPHA")


# =====================================================================
# Output Writers
# =====================================================================

def _write_profile_parquet(profile: StockProfile, profiles_dir: str) -> None:
    """Write profile as parquet with snappy compression."""
    path = os.path.join(profiles_dir, f"{profile.symbol}.parquet")
    df = pd.DataFrame([profile.to_dict()])
    df.to_parquet(path, index=False, compression="snappy")


def _write_profile_markdown(profile: StockProfile, profiles_dir: str) -> None:
    """Write human-readable profile as markdown."""
    path = os.path.join(profiles_dir, f"{profile.symbol}.md")

    exit_lines = []
    for reason, pct in sorted(profile.exit_reason_dist.items(), key=lambda x: -x[1]):
        exit_lines.append(f"  {reason}: {pct}%")
    exit_block = "\n".join(exit_lines) if exit_lines else "  No trades"

    regime_lines = []
    for regime, wr in sorted(profile.regime_win_rates.items(), key=lambda x: -x[1]):
        n_t = profile.regime_n_trades.get(regime, 0)
        regime_lines.append(f"  {regime}: {wr}% (n={n_t})")
    regime_block = "\n".join(regime_lines) if regime_lines else "  Not enough data per regime"

    sig_lines = []
    sorted_sigs = sorted(profile.signal_win_rates.items(), key=lambda x: x[1])
    worst = sorted_sigs[:5]
    best = sorted_sigs[-5:] if len(sorted_sigs) > 5 else sorted_sigs
    if worst:
        sig_lines.append("  Worst performing:")
        for sig, wr in worst:
            n_t = profile.signal_n_fired.get(sig, 0)
            sig_lines.append(f"    {sig}: {wr}% win rate (n={n_t})")
    if best and best != worst:
        sig_lines.append("  Best performing:")
        for sig, wr in reversed(best):
            n_t = profile.signal_n_fired.get(sig, 0)
            sig_lines.append(f"    {sig}: {wr}% win rate (n={n_t})")
    sig_block = "\n".join(sig_lines) if sig_lines else "  Not enough signal data"

    flag_lines = []
    for flag_name in profile.flags:
        catalog = FLAG_CATALOG.get(flag_name, {})
        severity = catalog.get("severity", "LOW")
        desc = catalog.get("description", "")
        suggestion = catalog.get("suggestion", "")
        flag_lines.append(f"  [{severity}] {flag_name}")
        flag_lines.append(f"    {desc}")
        if suggestion:
            flag_lines.append(f"    Suggestion: {suggestion}")
        flag_lines.append("")
    flags_block = "\n".join(flag_lines) if flag_lines else "  No flags raised."

    stale_note = ""
    if profile.is_stale:
        stale_note = "\n> **WARNING: This profile may be stale.** Config hash or data cutoff has changed. Re-run backtest to refresh.\n"

    rsi_delta = round(profile.mean_rsi21_losses - profile.mean_rsi21_wins, 1) if profile.mean_rsi21_wins > 0 else "N/A"
    score_delta = round(profile.mean_score_losses - profile.mean_score_wins, 1) if profile.mean_score_wins > 0 else "N/A"
    mae_note = "> 1.0 = entries early" if profile.mae_mfe_ratio > 1.0 else ""

    # Build BH section
    bh_section = ""
    if profile.avg_bh_return_pct != 0.0 or profile.avg_alpha_vs_bh_pct != 0.0:
        bh_section = (
            "\n## Buy-and-Hold Comparison\n\n"
            "| Metric | Value |\n"
            "|--------|-------|\n"
            f"| Avg BH return | {profile.avg_bh_return_pct}% |\n"
            f"| Avg alpha vs BH | {profile.avg_alpha_vs_bh_pct}% |\n"
            f"| Alpha win rate | {profile.alpha_win_rate}% |\n\n"
        )

    # Build post-exit section
    opp_section = ""
    if profile.avg_post_exit_bars_to_next > 0:
        opp_section = (
            "\n## Post-Exit Opportunity\n\n"
            f"- **Avg bars idle between trades:** {profile.avg_post_exit_bars_to_next}\n"
            f"- **Avg PnL of next trade after exit:** {profile.avg_post_exit_pnl_next}%\n\n"
        )

    md = f"""# {profile.symbol} — Behavioral Profile

**Last updated:** {profile.data_cutoff}  
**Engine version:** {profile.engine_version}  
**Trades:** {profile.n_trades} | **Win rate:** {profile.win_rate}% | **Avg PnL:** {profile.avg_pnl_pct}% | **Avg hold:** {profile.avg_bars_held} bars
{stale_note}
---

## Execution Quality

| Metric | Value |
|--------|-------|
| Win rate | {profile.win_rate}% |
| Avg PnL per trade | {profile.avg_pnl_pct}% |
| Avg bars held | {profile.avg_bars_held} |
| Avg MAE (daily bars) | {profile.avg_mae_daily}% |
| Avg MFE (daily bars) | {profile.avg_mfe_daily}% |
| MAE/MFE ratio | {profile.mae_mfe_ratio} |  {mae_note} |

### Exit Reason Distribution
{exit_block}

## Entry Quality

| Metric | Wins | Losses | Delta |
|--------|------|--------|-------|
| Mean RSI21 at entry | {profile.mean_rsi21_wins} | {profile.mean_rsi21_losses} | {rsi_delta} |
| Mean score at entry | {profile.mean_score_wins} | {profile.mean_score_losses} | {score_delta} |

- **Overbought entry rate (RSI > {RSI_OVERBOUGHT}):** {profile.overbought_entry_rate}%
- **Post-divergence re-entry rate:** {profile.post_divergence_reentry_rate}%

## Stock Behavior

- **Mean ATR%:** {profile.mean_atr_pct}% (volatility fingerprint)
- **Gap-down SL rate:** {profile.gap_down_sl_rate}% (HARD_SL exits with slippage > 0.5%)
- **Avg exit slippage:** {profile.avg_exit_slippage}% (on HARD_SL exits)
- **Max consecutive losses:** {profile.consecutive_loss_streak_max}

## Regime-Conditioned Performance
{regime_block}

## Signal Win Rates
{sig_block}

{bh_section}
{opp_section}
## Flags
{flags_block}
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(md)


def load_profile(profiles_dir: str, symbol: str) -> Optional[StockProfile]:
    """Load a profile from parquet file."""
    path = os.path.join(profiles_dir, f"{symbol}.parquet")
    if not os.path.isfile(path):
        return None
    df = pd.read_parquet(path)
    if df.empty:
        return None
    row = df.iloc[0]

    profile = StockProfile(
        symbol=row.get("symbol", symbol),
        bucket=row.get("bucket", ""),
        n_trades=int(row.get("n_trades", 0)),
        engine_version=row.get("engine_version", ""),
        config_hash=row.get("config_hash", ""),
        data_cutoff=row.get("data_cutoff", ""),
        is_stale=bool(row.get("is_stale", False)),
        win_rate=float(row.get("win_rate", 0)),
        avg_pnl_pct=float(row.get("avg_pnl_pct", 0)),
        avg_bars_held=float(row.get("avg_bars_held", 0)),
        avg_mae_daily=float(row.get("avg_mae_daily", 0)),
        avg_mfe_daily=float(row.get("avg_mfe_daily", 0)),
        mae_mfe_ratio=float(row.get("mae_mfe_ratio", 0)),
        mean_rsi21_wins=float(row.get("mean_rsi21_wins", 0)),
        mean_rsi21_losses=float(row.get("mean_rsi21_losses", 0)),
        overbought_entry_rate=float(row.get("overbought_entry_rate", 0)),
        post_divergence_reentry_rate=float(row.get("post_divergence_reentry_rate", 0)),
        mean_score_wins=float(row.get("mean_score_wins", 0)),
        mean_score_losses=float(row.get("mean_score_losses", 0)),
        mean_atr_pct=float(row.get("mean_atr_pct", 0)),
        gap_down_sl_rate=float(row.get("gap_down_sl_rate", 0)),
        avg_exit_slippage=float(row.get("avg_exit_slippage", 0)),
        consecutive_loss_streak_max=int(row.get("consecutive_loss_streak_max", 0)),
        avg_bh_return_pct=float(row.get("avg_bh_return_pct", 0)),
        avg_alpha_vs_bh_pct=float(row.get("avg_alpha_vs_bh_pct", 0)),
        alpha_win_rate=float(row.get("alpha_win_rate", 0)),
        avg_post_exit_bars_to_next=float(row.get("avg_post_exit_bars_to_next", 0)),
        avg_post_exit_pnl_next=float(row.get("avg_post_exit_pnl_next", 0)),
    )

    for field_name in ("exit_reason_dist", "regime_win_rates", "regime_n_trades",
                       "signal_win_rates", "signal_n_fired"):
        val = row.get(field_name)
        if val and isinstance(val, str):
            try:
                setattr(profile, field_name, json.loads(val))
            except json.JSONDecodeError:
                pass

    flags_val = row.get("flags", "")
    if isinstance(flags_val, str):
        profile.flags = [f for f in flags_val.split("|") if f]

    return profile

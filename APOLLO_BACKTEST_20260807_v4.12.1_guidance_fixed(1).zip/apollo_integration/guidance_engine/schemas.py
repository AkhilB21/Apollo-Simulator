"""Guidance Engine — Schemas (v1.0)

Dataclass definitions for the post-trade analysis layer.
Every record is stamped with engine version, config hash, and data cutoff
so profiles can be invalidated when config changes.

Classes:
    TradeRecord     — One row per completed round-trip trade.
    StockProfile    — Aggregated behavioral fingerprint for one stock.
    RegimeSnapshot  — Market regime state at a point in time.
    FlagDefinition  — A single behavioral flag with severity.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, asdict
from datetime import date
from typing import Optional, Any


# =====================================================================
# Version / Config Stamping
# =====================================================================

ENGINE_VERSION = "4.12"

# =====================================================================
# Guidance Constants (single source of truth)
# =====================================================================

# Minimum trades before any profile flag can be considered reliable
MIN_TRADES_FOR_PROFILE = 8

# VIX regime thresholds (India VIX typical range 10-25)
VIX_LOW = 12.0
VIX_HIGH = 20.0

# Minimum regime history (trading days) for reliable classification
MIN_REGIME_HISTORY = 200

# Minimum trades in a regime cell before surfacing conditioned stats
MIN_REGIME_N = 8

# RSI threshold for overbought entry detection
RSI_OVERBOUGHT = 70.0

# Bars within which re-entry after divergence exit is "quick"
POST_DIV_REENTRY_BARS = 10

# Threshold: flag fires on this % of stocks in a bucket → systemic
SYSTEMIC_THRESHOLD_PCT = 55.0

# Minimum stocks in a bucket before surfacing systemic flags
MIN_BUCKET_SIZE = 10


def config_hash_from_constants(constants_module_path: str | None = None,
                             runtime_params: dict | None = None) -> str:
    """Generate an MD5 hash to catch silent config drift.

    Parameters
    ----------
    constants_module_path : str or None
        Absolute path to ``apollo_core/constants.py``.
    runtime_params : dict or None
        Runtime parameters that affect trade outcomes but aren't in
        constants.py (e.g., sl_pct, exit_mode, entry_threshold).
        These are appended to the hash input.

    Returns
    -------
    str — 12-char hex MD5 digest.  Returns ``"NO_PATH"`` if file not found.
    """
    hash_input = b""

    if constants_module_path is None:
        try:
            import apollo_core.constants as _c
            constants_module_path = _c.__file__
        except Exception:
            pass

    if constants_module_path:
        try:
            import os
            if os.path.isfile(constants_module_path):
                with open(constants_module_path, "rb") as f:
                    hash_input += f.read()
        except Exception:
            pass

    # Include runtime params in hash
    if runtime_params:
        import json
        hash_input += json.dumps(runtime_params, sort_keys=True).encode()

    if not hash_input:
        return "NO_PATH"

    return hashlib.md5(hash_input).hexdigest()[:12]


# =====================================================================
# Regime Snapshot
# =====================================================================

@dataclass
class RegimeSnapshot:
    """Market regime state at a single date.

    Fetched once for the entire NIFTY/VIX history and joined by date.
    """
    date: date
    nifty_close: float = 0.0
    nifty_50dma: float = 0.0
    nifty_200dma: float = 0.0
    nifty_above_50dma: bool = False
    nifty_above_200dma: bool = False
    india_vix: float = 0.0
    vix_regime: str = "MEDIUM"  # LOW / MEDIUM / HIGH

    # Derived regime label
    @property
    def regime_label(self) -> str:
        if self.nifty_above_200dma and self.vix_regime == "LOW":
            return "BULL_LOWVIX"
        elif self.nifty_above_200dma:
            return "BULL"
        elif self.nifty_above_50dma:
            return "NEUTRAL"
        else:
            return "BEAR"


def classify_vix(vix: float, low_thresh: float = 12.0, high_thresh: float = 20.0) -> str:
    """Classify VIX into LOW / MEDIUM / HIGH regime."""
    if vix <= low_thresh:
        return "LOW"
    elif vix >= high_thresh:
        return "HIGH"
    return "MEDIUM"


# =====================================================================
# Trade Record — Foundation (Layer 0)
# =====================================================================

@dataclass
class TradeRecord:
    """One row per completed round-trip trade.

    This is the source-of-truth for all downstream analysis.
    Written as append-only rows to ``trades.parquet``.
    """
    # --- Identity + Versioning ---
    symbol: str
    entry_date: str                       # YYYY-MM-DD (tz-naive)
    exit_date: str                        # YYYY-MM-DD (tz-naive)
    engine_version: str = ENGINE_VERSION
    sl_pct: float = 0.0
    exit_mode: str = "NONE"
    data_cutoff: str = ""                 # last bar date in backtest
    config_hash: str = ""
    run_id: str = ""                     # UUID-based run provenance

    # --- Entry State (snapshot from daily_results) ---
    entry_price: float = 0.0
    entry_score: float = 0.0
    entry_total: float = 0.0
    pool_a: float = 0.0
    pool_b: float = 0.0
    pool_c: float = 0.0
    pool_r: float = 0.0
    bonus_total: float = 0.0
    rsi21_entry: float = 0.0
    rsi21_weekly_entry: float = 0.0
    adx_entry: float = 0.0
    atr_pct_entry: float = 0.0             # ATR as % of entry price
    bars_from_trough: Optional[int] = None
    bucket: str = ""
    dist_from_52w_high_pct: float = 0.0    # (52w_high - entry_price) / 52w_high
    dist_from_52w_low_pct: float = 0.0     # (entry_price - 52w_low) / 52w_low
    volume_zscore_entry: float = 0.0

    # --- Signals fired at entry ---
    signals_fired: list = field(default_factory=list)  # ["A1", "A3", "B2", ...]
    n_signals_fired: int = 0

    # --- Re-entry Context ---
    bars_since_prior_exit: int = -1        # -1 = first trade (no prior exit)
    prior_exit_reason: str = ""            # empty if first trade
    entry_above_prior_exit_price: bool = False

    # --- Market Regime at Entry ---
    nifty_above_50dma: bool = False
    nifty_above_200dma: bool = False
    india_vix_regime: str = "MEDIUM"
    regime_label: str = "NEUTRAL"

    # --- Outcome ---
    exit_price: float = 0.0
    exit_reason: str = ""                  # primary class: HARD_SL, DIVERGENCE, etc.
    exit_reason_full: str = ""             # full reason string from engine
    pnl_pct: float = 0.0
    bars_held: int = 0
    mae_daily: float = 0.0                  # max adverse excursion (lower bound, daily bars)
    mae_intraday_est: float = 0.0           # entry * (1 - sl_pct) as gap-fill proxy
    mfe_daily: float = 0.0                  # max favorable excursion (daily bars)
    exit_slippage_est: float = 0.0          # actual fill vs theoretical SL on HARD_SL exits

    # --- Consecutive Loss Context ---
    consecutive_loss_count: int = 0         # how many losses in a row before this trade

    # --- Post-Exit Opportunity Cost ---
    post_exit_bars_to_next: int = -1        # trading days from this exit to next entry (-1 = last trade)
    post_exit_pnl_next: float = 0.0         # PnL% of the next trade (opportunity cost metric)

    # --- Buy-and-Hold Benchmark ---
    bh_return_pct: float = 0.0             # buy-and-hold return over same holding period
    alpha_vs_bh_pct: float = 0.0           # trade PnL minus BH return

    def to_dict(self) -> dict:
        """Convert to flat dict for DataFrame construction.

        Lists (signals_fired) are converted to pipe-delimited strings
        so the record is parquet-serializable.
        """
        d = asdict(self)
        # Serialize list fields
        if isinstance(d.get("signals_fired"), list):
            d["signals_fired"] = "|".join(d["signals_fired"]) if d["signals_fired"] else ""
        return d


# =====================================================================
# Stock Profile — Computed from Trade Records (Layer 1)
# =====================================================================

@dataclass
class StockProfile:
    """Behavioral fingerprint for one stock, computed from its TradeRecords.

    Stored as ``profiles/{SYMBOL}.parquet`` plus a human-readable ``.md``.
    Includes staleness checks against the current run's config.
    """
    symbol: str
    bucket: str = ""
    n_trades: int = 0
    engine_version: str = ENGINE_VERSION
    config_hash: str = ""
    data_cutoff: str = ""
    is_stale: bool = False                 # True if config/cutoff mismatch

    # --- Execution Quality ---
    win_rate: float = 0.0                  # % of trades with pnl > 0
    avg_pnl_pct: float = 0.0
    avg_bars_held: float = 0.0
    exit_reason_dist: dict = field(default_factory=dict)  # {"HARD_SL": 30.0, "DIVERGENCE": 45.0, ...}
    avg_mae_daily: float = 0.0
    avg_mfe_daily: float = 0.0
    mae_mfe_ratio: float = 0.0             # > 1.0 = entries consistently early

    # --- Entry Quality ---
    mean_rsi21_wins: float = 0.0
    mean_rsi21_losses: float = 0.0
    overbought_entry_rate: float = 0.0      # % of entries with RSI21 > 70
    post_divergence_reentry_rate: float = 0.0  # % entries within 10 bars of DIVERGENCE exit
    mean_score_wins: float = 0.0
    mean_score_losses: float = 0.0

    # --- Stock Behavior ---
    mean_atr_pct: float = 0.0              # avg ATR% across entries (volatility fingerprint)
    gap_down_sl_rate: float = 0.0          # % of HARD_SL exits with slippage > 1%
    avg_exit_slippage: float = 0.0         # mean slippage on HARD_SL exits
    consecutive_loss_streak_max: int = 0   # longest consecutive loss streak

    # --- Regime-Conditioned (only computed if min-n met) ---
    regime_win_rates: dict = field(default_factory=dict)  # {"BULL": 65.0, "BEAR": 28.0}
    regime_n_trades: dict = field(default_factory=dict)   # {"BULL": 12, "BEAR": 6}

    # --- Buy-and-Hold Comparison ---
    avg_bh_return_pct: float = 0.0           # avg BH return over trade holding periods
    avg_alpha_vs_bh_pct: float = 0.0         # avg (trade PnL - BH return)
    alpha_win_rate: float = 0.0              # % of trades where alpha > 0

    # --- Post-Exit Opportunity ---
    avg_post_exit_bars_to_next: float = 0.0  # avg bars idle between exit and re-entry
    avg_post_exit_pnl_next: float = 0.0      # avg PnL of the trade following this exit

    # --- Flags ---
    flags: list = field(default_factory=list)  # ["RSI_ENTRY_RISK", "POST_DIVERGENCE_REENTRY"]

    # --- Signal Win Rates (per signal, for trades where it fired) ---
    signal_win_rates: dict = field(default_factory=dict)  # {"A1": 55.0, "B2": 40.0}
    signal_n_fired: dict = field(default_factory=dict)    # {"A1": 20, "B2": 15}

    def to_dict(self) -> dict:
        """Convert to flat dict for DataFrame/parquet.

        Nested dicts are JSON-serialized to strings.
        """
        import json
        d = asdict(self)
        for key in ("exit_reason_dist", "regime_win_rates", "regime_n_trades",
                     "signal_win_rates", "signal_n_fired"):
            if isinstance(d.get(key), dict):
                d[key] = json.dumps(d[key])
        if isinstance(d.get("flags"), list):
            d["flags"] = "|".join(d["flags"]) if d["flags"] else ""
        return d


# =====================================================================
# Flag Definitions
# =====================================================================

# Severity levels for display in the UI
FLAG_SEVERITY = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}

# All known flags with descriptions
FLAG_CATALOG: dict[str, dict[str, str]] = {
    "RSI_ENTRY_RISK": {
        "description": "RSI21 > 70 at >50% of losing entries. Overbought re-entries are common.",
        "severity": "HIGH",
        "suggestion": "Consider RSI < 65 entry cap for this stock.",
    },
    "POST_DIVERGENCE_REENTRY": {
        "description": "High rate of re-entry within 10 bars after a divergence exit.",
        "severity": "HIGH",
        "suggestion": "Increase divergence cooldown or block re-entry above prior exit price.",
    },
    "HIGH_HARD_SL_RATE": {
        "description": "Hard SL exit rate > 40%. Entry timing may be consistently early.",
        "severity": "MEDIUM",
        "suggestion": "Review MAE — if avg MAE is close to SL%, widen SL or delay entries.",
    },
    "MAE_NEAR_SL": {
        "description": "Average MAE is >80% of SL distance. Entries are cutting it close.",
        "severity": "HIGH",
        "suggestion": "Tight entry timing or widen stop-loss by 1-2%.",
    },
    "MFE_LEAKAGE": {
        "description": "Average MFE on DIVERGENCE exits is >3x average MFE on SL exits. Exiting too early.",
        "severity": "MEDIUM",
        "suggestion": "Divergence exit may be too sensitive. Consider increasing RSI drop threshold.",
    },
    "GAP_DOWN_SLIPPAGE": {
        "description": "HIGH_SL exits frequently gap below theoretical SL price.",
        "severity": "MEDIUM",
        "suggestion": "Actual fill is worse than expected. Factor in 0.5-1% extra slippage.",
    },
    "REGIME_DEPENDENT": {
        "description": "Win rate varies >25pts across market regimes. Signal is regime-sensitive.",
        "severity": "MEDIUM",
        "suggestion": "Consider suppressing entries in low-win-rate regimes.",
    },
    "CONSECUTIVE_LOSSES": {
        "description": "Stock has a history of 3+ consecutive losing trades.",
        "severity": "LOW",
        "suggestion": "Consider pausing after 2 consecutive SL exits for this stock.",
    },
    "LOW_SAMPLE_SIZE": {
        "description": "Fewer than 8 completed trades. Profile statistics are unreliable.",
        "severity": "LOW",
        "suggestion": "Treat all findings as preliminary until more data accumulates.",
    },
    "NEGATIVE_ALPHA": {
        "description": "Average alpha vs buy-and-hold is negative. The strategy underperforms simply holding the stock.",
        "severity": "HIGH",
        "suggestion": "Review entry/exit timing — the stock trends well enough that reduced trading may be optimal.",
    },
}

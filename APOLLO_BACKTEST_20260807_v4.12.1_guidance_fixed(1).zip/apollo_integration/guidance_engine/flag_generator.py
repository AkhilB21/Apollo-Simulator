"""Guidance Engine — Flag Generator (v1.0)

Reads per-stock profiles and annotates screener output with soft flags.
Flags are informational only — they never block trades.

Integration Point:
    After the screener generates candidates, cross-reference each symbol's
    profile and append a FLAGS column to the output CSV/DataFrame.

Usage::
    from guidance_engine.flag_generator import annotate_screener

    annotated_df = annotate_screener(screener_df, profiles_dir)
    # screener_df gains a 'FLAGS' column: "RSI_ENTRY_RISK|POST_DIVERGENCE_REENTRY"
"""

from __future__ import annotations

import logging
import os

import pandas as pd

from guidance_engine.analyzer import load_profile
from guidance_engine.schemas import FLAG_CATALOG, FLAG_SEVERITY

logger = logging.getLogger(__name__)


def annotate_screener(
    screener_df: pd.DataFrame,
    profiles_dir: str,
    symbol_col: str = "symbol",
) -> pd.DataFrame:
    """Annotate a screener DataFrame with behavioral flags.

    Parameters
    ----------
    screener_df : pd.DataFrame
        The screener output.  Must have a column matching ``symbol_col``.
    profiles_dir : str
        Directory containing ``{SYMBOL}.parquet`` profile files.
    symbol_col : str
        Name of the symbol column in screener_df.

    Returns
    -------
    pd.DataFrame — copy of screener_df with added 'FLAGS' and 'FLAG_SEVERITY' columns.
    """
    df = screener_df.copy()
    flags_col = []
    severity_col = []

    for _, row in df.iterrows():
        symbol = str(row[symbol_col]).upper().strip()
        profile = load_profile(profiles_dir, symbol)

        if profile is None or profile.is_stale:
            flags_col.append("")
            severity_col.append("")
            continue

        if not profile.flags:
            flags_col.append("")
            severity_col.append("")
            continue

        # Build flag string
        flag_strs = []
        max_severity = 0
        for f in profile.flags:
            catalog = FLAG_CATALOG.get(f, {})
            sev = FLAG_SEVERITY.get(catalog.get("severity", "LOW"), 1)
            max_severity = max(max_severity, sev)
            flag_strs.append(f)

        flags_col.append("|".join(flag_strs))
        if max_severity >= 3:
            severity_col.append("HIGH")
        elif max_severity >= 2:
            severity_col.append("MEDIUM")
        else:
            severity_col.append("LOW")

    df["FLAGS"] = flags_col
    df["FLAG_SEVERITY"] = severity_col
    return df


def get_stock_flags(profiles_dir: str, symbol: str) -> list[dict]:
    """Get detailed flag information for a single stock.

    Returns a list of dicts with keys: name, severity, description, suggestion.
    """
    profile = load_profile(profiles_dir, symbol.upper().strip())
    if profile is None:
        return []

    result = []
    for f in profile.flags:
        catalog = FLAG_CATALOG.get(f, {})
        result.append({
            "name": f,
            "severity": catalog.get("severity", "LOW"),
            "description": catalog.get("description", ""),
            "suggestion": catalog.get("suggestion", ""),
        })
    return result


def flag_summary_dataframe(profiles_dir: str) -> pd.DataFrame:
    """Build a summary DataFrame of all stocks and their flags.

    Useful for the Streamlit Stock Profile tab.
    """
    rows = []
    if not os.path.isdir(profiles_dir):
        return pd.DataFrame()

    for fname in os.listdir(profiles_dir):
        if not fname.endswith(".parquet"):
            continue
        symbol = fname.replace(".parquet", "")
        profile = load_profile(profiles_dir, symbol)
        if profile is None:
            continue
        rows.append({
            "symbol": symbol,
            "bucket": profile.bucket,
            "n_trades": profile.n_trades,
            "win_rate": profile.win_rate,
            "avg_pnl_pct": profile.avg_pnl_pct,
            "flags": "|".join(profile.flags) if profile.flags else "",
            "n_flags": len(profile.flags),
            "is_stale": profile.is_stale,
            "mae_mfe_ratio": profile.mae_mfe_ratio,
            "overbought_entry_rate": profile.overbought_entry_rate,
        })

    return pd.DataFrame(rows) if rows else pd.DataFrame()
# Apollo Engine v4.10.1 — Guidance Engine + Bugfix Release

**Backtest engine with non-invasive post-trade analysis layer.**

v4.10 adds the **Guidance Engine** (`guidance_engine/`) — a post-trade analysis layer that reads backtest output without modifying the scoring engine. It produces MAE/MFE diagnostics, per-stock behavioral profiles, regime-aware analysis (NIFTY 50 + India VIX), and systemic aggregation (bucket-level flag frequency at 55% threshold). All output stored in `APOLLO_DATA_REPOSITORY/output/`.

v4.10.1 fixes 3 bugs (XLSX NameError, silent guidance failures, History tab DB path) and adds Google Drive daily sync.

See `CHANGELOG.md` for full v4.10.1 and v4.10 details.

---

> **Note:** The sections below document the **Live Engine** (v4.7). They remain for reference. The Backtest Engine is launched via `run_apollo.bat` or `streamlit run backtest_engine/app.py`.

---

# Apollo Engine v4.7 — Equity Analytics & Entry Gates (Live Engine Reference)

**Phase 2 Step 3 — Live dashboard + human-in-the-loop exit confirmation**

This is the live trading companion to the Apollo Backtest Studio. It uses the **same scoring engine** (`apollo_core/`) and the **same exit-detection brain** (`detect_exit_triggers()`) as the backtest. v1.1 adds a **Streamlit dashboard** where you can monitor stocks in real time and **confirm or dismiss exits with a click** — the true human-in-the-loop live trading mode.

v4.7 adds **Pool E (Equity Analytics)** — 5 new additive signals mirroring the user's Google Sheet screening columns (52W-Low proximity, Stochastic oversold turn, Relative Volume surge, VPT accumulation, 50-SMA recovery zone) — plus **4 hard entry gates** (PE sanity, liquidity floor, 52W-low proximity, 52W-high distance) that block entry regardless of score.

---

## What's in this zip

```
apollo_core/           Shared scoring engine (v4.7 — Equity Analytics & Entry Gates)
  types.py             Position, ExitConfig, ExitDecision dataclasses
                       (v1.1: Position gained pending_exit + pending_exit_payload)
  trade_engine.py      run_backtest, run_ipo_backtest, detect_exit_triggers,
                       execute_exit, extract_trades
  scoring.py           21 mature signals + 12 IPO signals
  indicators.py        RSI, MACD, ADX, WC, TP computation
  bucket_classifier.py Layer-1 stock classification (reference-only, no gating)
  ipo_lookup.py        Listing-date-aware IPO detection
  constants.py         Thresholds, pool definitions

live_engine/           Live monitoring + dashboard
  __init__.py          Package marker, version "1.1"
  __main__.py          Enables `python -m live_engine`
  data_replay.py       BarReplay — bar-by-bar CSV feeder
  state_store.py       StateStore — SQLite persistence (auto-migrates v1.0 DBs)
  signal_monitor.py    SignalMonitor + confirm_exit() + dismiss_exit()
  cli.py               Command-line interface (--no-auto-confirm flag added)
  dashboard.py         NEW v1.1 — Streamlit UI with KPIs, score chart,
                       pending-exit panel, alerts table, confirm/dismiss buttons
  run_live.py          NEW v1.1 — single launcher for the dashboard

backtest_engine/       Backtest I/O layer (used by tests for consistency check)
  eod2_loader.py       CSV → DataFrame with indicators
  backtest.py          run_stock_backtest high-level wrapper

tests/                 Pre-flight + verification
  preflight_live.py    21-test suite — run before packaging
  test_human_confirm.py  Smoke test for the human-confirm exit flow
  baseline_v342_cyientdlm.json  Frozen v3.4.2 backtest baseline

data/                  Test data
  CYIENTDLM.csv        eod2-format daily OHLCV (2022-01-01 → 2026-07-24)

CHANGELOG.md           What changed in this version (ALWAYS inside the zip)
README.md              This file
requirements.txt       Python dependencies
run_apollo_live.bat    Windows launcher (double-click to run)
ipo_listing_dates.json IPO lookup data (for IPO detection)
```

---

## Quick start (3 steps)

### Step 1 — Install dependencies (one-time)

```
pip install -r requirements.txt
```

### Step 2 — Launch the dashboard

Either double-click `run_apollo_live.bat`, or run from the command line:

```
python live_engine/run_live.py
```

This opens the Streamlit dashboard at `http://localhost:8501`. You'll see:

- A **sidebar** with symbol selector, date range, exit mode config, and monitor controls.
- A **KPI row** showing current position status, latest score, entry price, last alert, and total alert count.
- A **score history chart** with green ▲ for ENTRY alerts, red ▼ for EXIT alerts, gold ◆ for EXIT_CONFIRMED.
- A **pending exit panel** (when an EXIT alert is waiting for your decision).
- A **recent alerts table**.

### Step 3 — Start the monitor

1. Pick a symbol (e.g., CYIENTDLM) and date range in the sidebar.
2. Uncheck "Auto-confirm exits" (the default) for true human-in-the-loop mode.
3. Click **"▶ Start Monitor"**.
4. Watch alerts appear in real time. When an EXIT alert fires, the **pending exit panel** appears with details (reason, fill price, P&L). Click:
   - **"✓ Confirm Exit"** to close the position (resets state, sets cooldown).
   - **"✗ Dismiss"** to keep the position open (clears pending state, monitor resumes exit detection).

---

## Headless mode (no UI)

If you don't want the dashboard, you can run the monitor from the CLI:

```
# Auto-confirm mode (Step 2 behavior — for verifying the engine)
python -m live_engine --symbol CYIENTDLM --data-dir data --start 2024-01-01

# Human-confirm mode (Step 3 — EXIT alerts become PENDING, you confirm in dashboard)
python -m live_engine --symbol CYIENTDLM --no-auto-confirm
```

Then later open the dashboard to confirm/dismiss any pending exits.

To view all emitted alerts:

```
python -m live_engine --symbol CYIENTDLM --list-alerts
```

---

## How it works

### The detect/execute split (Step 1, v3.5)

In the backtest engine, `extract_trades()` does two things:
1. **Detects** exit conditions (calls `detect_exit_triggers()`)
2. **Executes** the exit (calls `execute_exit()` — resets position, sets cooldown)

In the live engine, we **only do step 1**. When `detect_exit_triggers()` returns `should_exit=True`, we emit an advisory alert. **You** decide whether to actually sell in your broker terminal, then click "Confirm Exit" in the dashboard to update the engine's state.

### The pending_exit state (v1.1)

When an EXIT alert fires in human-confirm mode:
1. The monitor sets `position.pending_exit = True` and saves the exit details to `position.pending_exit_payload`.
2. The monitor keeps processing bars, but skips new exit detection (one pending exit at a time). Subsequent bars emit `HOLD` alerts with a `PENDING_EXIT` flag.
3. The dashboard's pending exit panel appears, showing the reason, fill price, and P&L.
4. When you click "Confirm Exit", `confirm_exit()`:
   - Resets the position (in_trade=False, entry_*=None, peak_*=None)
   - Sets `cooldown_until_date` to exit_date + 5 trading days (matches backtest exactly)
   - Clears `pending_exit` and `pending_exit_payload`
   - Emits an `EXIT_CONFIRMED` alert to the log (with your optional note)
5. Or, click "Dismiss" to clear pending state but keep the position open. The monitor resumes exit detection on the next bar. Emits an `EXIT_DISMISSED` alert.

### State persistence + crash recovery

After every bar, the monitor saves:
- **Position state** (in_trade, entry_price, peak_rsi, cooldown_until_date, pending_exit, etc.) to the `monitor_state` table
- **Alert log** (every alert emitted) to the `alerts` table

You can stop the monitor anytime (close the terminal, kill the process, reboot) and restart it without losing state. On restart, it loads the saved Position and skips bars already processed.

If you have a v1.0 state DB, the StateStore **auto-migrates** it to v1.1 on first open (adds the new `pending_exit` columns via `ALTER TABLE`). Your alert history and position state are preserved.

### Consistency with backtest

Pre-flight Test 12 verifies that the live monitor produces **byte-for-byte identical** entry/exit decisions as the backtest engine on CYIENTDLM. The human-confirm mode is a pure UI-layer addition — it doesn't change the detect logic, only what happens after detection.

---

## CLI reference

```
python -m live_engine [OPTIONS]

Required:
  --symbol SYMBOL       NSE stock symbol (e.g., CYIENTDLM)

Data:
  --data-dir DIR        Directory containing {symbol}.csv (default: data)
  --start DATE          Start date YYYY-MM-DD (default: 2024-01-01)
  --end DATE            End date YYYY-MM-DD (default: today)

State:
  --db PATH             SQLite state DB path (default: live_state.db)
  --no-resume           Don't resume from saved state; start fresh
  --no-auto-confirm     v1.1: EXIT alerts become PENDING; use dashboard
                        to confirm (default: auto-confirm ON)
  --list-alerts         List saved alerts for this symbol and exit

Exit mode:
  --exit-mode MODE      NONE | FIXED_SL | TRAILING_SL | DUAL_SL | DI_CROSSOVER
                        (default: NONE — advisory only)
  --sl-percent N        Hard SL % (default: 5.0)
  --trailing-sl N       Trailing SL % (default: 3.0)

Thresholds:
  --entry-thresh N      Entry score threshold (default: 70)
  --exit-thresh N       Exit score threshold (default: 50)

Output:
  --quiet               Only print ENTRY/EXIT/COOLDOWN alerts (skip HOLD/WAIT)
```

---

## Dashboard launcher reference

```
python live_engine/run_live.py [OPTIONS]

Options:
  --port N              Streamlit port (default: 8501)
  --no-browser          Don't auto-open the browser
  --debug               Verbose Streamlit logging
```

---

## Alert types

| Type | Meaning |
|---|---|
| `ENTRY` | Score crossed above entry threshold. New position opened (advisory). |
| `EXIT` | `detect_exit_triggers()` returned `should_exit=True`. In auto-confirm mode, position auto-closes. In human-confirm mode, becomes PENDING. |
| `HOLD` | In-trade, no exit triggered. Informational. May include `PENDING_EXIT` flag. |
| `WAIT` | Not in-trade, score below entry threshold but approaching. Informational. |
| `COOLDOWN` | Score above threshold but in post-exit cooldown. No entry. |
| `STARTUP` | Monitor started or resumed. Informational. |
| `EXIT_CONFIRMED` | **v1.1**: User clicked "Confirm Exit" in the dashboard. Position reset, cooldown set. |
| `EXIT_DISMISSED` | **v1.1**: User clicked "Dismiss" in the dashboard. Position stays open, pending cleared. |

---

## Running the pre-flight suite

Before packaging a new zip, run:

```
python tests/preflight_live.py
```

All 21 tests must pass. The most important tests:
- **Test 12**: Live decisions match backtest byte-for-byte (regression check).
- **Test 18**: Human-confirm mode actually sets `pending_exit` after EXIT alerts.
- **Test 19**: `confirm_exit()` actually resets the position.
- **Test 21**: v1.0 databases auto-migrate to v1.1 schema.

---

## What's next (Step 4)

Step 4 will add:
- `live_engine/alert_manager.py` — file log + Telegram bot delivery (push notifications for ENTRY/EXIT/EXIT_CONFIRMED)
- `live_engine/config.yaml` — central config file for symbols, thresholds, Telegram credentials

Step 5 will add:
- `LEARN.md` — end-to-end tutorial for new users
- `RUNBOOK.md` — daily operations guide (what to check, what to do when things break)

---

## Built on

- Apollo Live v1.0 (the monitor core — unchanged in behavior)
- Apollo Backtest v3.5 (detect/execute split — the foundation)
- See `CHANGELOG.md` for the full history of both engines.

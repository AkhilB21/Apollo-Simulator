@echo off
chcp 65001 >nul 2>&1
echo ============================================================
echo   Apollo Data Audit Tool v1.0
echo ============================================================
echo.
python apollo_data_audit.py --report audit_report.html
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Audit completed with errors.
) else (
    echo.
    echo Audit completed successfully. Check audit_report.html for results.
)
echo.
pause

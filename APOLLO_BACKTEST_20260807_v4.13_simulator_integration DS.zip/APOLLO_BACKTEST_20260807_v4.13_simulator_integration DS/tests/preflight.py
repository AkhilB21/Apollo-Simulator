"""Apollo Engine — Pre-Flight Test Suite (v4.8)

Run after any code change, BEFORE building a delivery zip:

    python tests/preflight.py

Covers syntax, imports, backtest correctness, gate informational mode,
Renko wiring, central data repo, and version consistency.

Exit code 0 = all pass; 1 = at least one failure.
"""

from __future__ import annotations

import sys
import os
import re
import subprocess
from pathlib import Path

# Ensure project root is on sys.path (tests/ is one level down)
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

CURRENT_VERSION = "v4.13"
STALE_VERSIONS = ["v4.10", "v4.9.3", "v4.8", "v4.7", "v4.6", "v4.5", "v4.4", "v4.3", "v4.2", "v4.1"]

PASS = 0
FAIL = 0
FAILURES: list[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {name}")
    else:
        FAIL += 1
        FAILURES.append(name)
        print(f"  [FAIL] {name}  {detail}")


def main() -> int:
    print(f"\nApollo Pre-Flight v4.8 — {_ROOT}\n")

    # ── 1. Syntax check every .py file ──────────────────────────────────
    print("[1] Syntax check every .py file")
    py_files = sorted(_ROOT.rglob("*.py"))
    py_files = [p for p in py_files if "__pycache__" not in str(p)]
    bad = 0
    # Use subprocess for cross-platform compatibility (avoids 2>/dev/null issue)
    for f in py_files:
        try:
            result = subprocess.run(
                [sys.executable, "-m", "py_compile", str(f)],
                capture_output=True, timeout=30,
            )
            if result.returncode != 0:
                bad += 1
                print(f"      syntax error: {f.relative_to(_ROOT)}")
        except Exception:
            bad += 1
            print(f"      error: {f.relative_to(_ROOT)}")
    check("all .py files compile", bad == 0, f"{bad} files failed")

    # ── 2. Import every module ──────────────────────────────────────────
    print("[2] Import every module")
    import importlib
    import_errors = []
    for mod in [
        "apollo_core", "apollo_core.constants", "apollo_core.indicators",
        "apollo_core.scoring", "apollo_core.trade_engine", "apollo_core.gates",
        "apollo_core.fundamentals", "backtest_engine.eod2_loader",
        "backtest_engine.backtest", "data_repo", "data_repo.repo",
    ]:
        try:
            importlib.import_module(mod)
        except Exception as e:  # noqa: BLE001
            import_errors.append(f"{mod}: {e}")
    check("all core modules import", not import_errors, "; ".join(import_errors)[:200])

    # ── 3. app.py title contains current version ────────────────────────
    print("[3] app.py title contains current version")
    app_py = _ROOT / "backtest_engine" / "app.py"
    if app_py.exists():
        txt = app_py.read_text(encoding="utf-8")
        title_ok = CURRENT_VERSION in txt
        check("title has current version", title_ok)
        stale_hits = [v for v in STALE_VERSIONS if v in txt]
        check("no stale versions in app.py", not stale_hits, f"found {stale_hits}")
    else:
        check("app.py exists", False)

    # ── 4. Real backtest on CYIENTDLM (end-to-end) ─────────────────────
    print("[4] Real backtest on CYIENTDLM (end-to-end)")
    try:
        import warnings
        warnings.filterwarnings("ignore")
        from backtest_engine.backtest import run_stock_backtest
        from apollo_core.fundamentals import load_fundamental_profile
        prof = load_fundamental_profile()
        result = run_stock_backtest(
            str(_ROOT / "data"), "CYIENTDLM", "2022-01-01", "2026-07-31",
            fundamental_profile=prof,
        )
        dd = result.get("daily_df")
        ok4 = dd is not None and not dd.empty
        check("backtest produced daily_df", ok4, f"rows={0 if dd is None else len(dd)}")
    except Exception as e:  # noqa: BLE001
        check("backtest produced daily_df", False, str(e)[:200])

    # ── 5. Pool E signals present in eval_signals output ────────────────
    print("[5] Pool E signals present in eval_signals output")
    try:
        import numpy as np
        import pandas as pd
        from apollo_core.scoring import eval_signals
        from apollo_core.indicators import compute_all_indicators
        from backtest_engine.eod2_loader import load_eod2_stock
        df_d, df_4h, df_w = load_eod2_stock(str(_ROOT / "data"), "CYIENTDLM")
        d_rsi21 = df_d["rsi21"]
        d_rsi36 = df_d["rsi36"]
        h_rsi21 = df_4h["rsi21"]
        h_rsi36 = df_4h["rsi36"]
        from apollo_core.scoring import compute_weekly_rsi
        w_rsi21 = compute_weekly_rsi(df_w, 21)
        w_rsi56 = compute_weekly_rsi(df_w, 56)
        sigs = eval_signals(
            df_d, df_4h, df_w, len(df_d) - 1, len(df_4h) - 1, len(df_w) - 1,
            None, None, d_rsi21, d_rsi36, h_rsi21, h_rsi36, w_rsi21, w_rsi56,
            df_d["plus_di"], df_d["minus_di"], df_d["macd"], None,
        )
        e_ids = [s for s in ("E1", "E2", "E3", "E4", "E5") if s in sigs]
        check("all 5 Pool E signals in output", len(e_ids) == 5, f"found {e_ids}")
    except Exception as e:  # noqa: BLE001
        check("all 5 Pool E signals in output", False, str(e)[:200])

    # ── 6. Gate evaluation returns dict (v4.8 informational) ─────────────
    print("[6] Gate evaluation returns dict (v4.8 informational)")
    try:
        from apollo_core.gates import compute_gate_frame, evaluate_gate_row
        from backtest_engine.eod2_loader import load_eod2_stock
        df_d, _, _ = load_eod2_stock(str(_ROOT / "data"), "CYIENTDLM")
        frame = compute_gate_frame(df_d)
        row = frame.iloc[-1].copy()
        row["close"] = df_d["close"].iloc[-1]
        result = evaluate_gate_row(row, pe=72.5)
        check("evaluate_gate_row returns dict", isinstance(result, dict))
        expected_keys = {"g1_pe", "g1_status", "g2_status", "g3_status", "g4_status", "all_pass"}
        has_keys = expected_keys.issubset(set(result.keys()))
        check("gate dict has expected keys", has_keys)
    except Exception as e:  # noqa: BLE001
        check("evaluate_gate_row returns dict", False, str(e)[:200])
        check("gate dict has expected keys", False)

    # ── 7. Backtest determinism (run twice, compare) ────────────────────
    print("[7] Backtest determinism (run twice, compare)")
    try:
        import warnings
        warnings.filterwarnings("ignore")
        from backtest_engine.backtest import run_stock_backtest
        from apollo_core.fundamentals import load_fundamental_profile
        prof = load_fundamental_profile()
        r1 = run_stock_backtest(str(_ROOT / "data"), "SYRMA", "2022-01-01", "2026-07-31", fundamental_profile=prof)
        r2 = run_stock_backtest(str(_ROOT / "data"), "SYRMA", "2022-01-01", "2026-07-31", fundamental_profile=prof)
        t1 = [(e["type"], str(e["date"]), round(e["close"], 4)) for e in r1["trades"]]
        t2 = [(e["type"], str(e["date"]), round(e["close"], 4)) for e in r2["trades"]]
        check("deterministic trades", t1 == t2)
    except Exception as e:  # noqa: BLE001
        check("deterministic trades", False, str(e)[:200])

    # ── 8. Required files present ───────────────────────────────────────
    print("[8] Required files present")
    required = [
        "apollo_core/constants.py", "apollo_core/scoring.py",
        "apollo_core/trade_engine.py", "apollo_core/indicators.py",
        "apollo_core/gates.py", "apollo_core/fundamentals.py",
        "backtest_engine/backtest.py", "backtest_engine/eod2_loader.py",
        "live_engine/signal_monitor.py", "nse_engine/data_feed.py",
        "nse_engine/run_pipeline.py", "requirements.txt",
        "etmoney_stocks_list.json", "data_repo/__init__.py",
        "data_repo/repo.py", "data_repo/sources.py", "data_repo/sync.py",
        "apollo_universe.json",
    ]
    missing = [f for f in required if not (_ROOT / f).exists()]
    check("all required files present", not missing, f"missing {missing}")

    # ── 9. No GATE-BLOCKED in trade_engine.py ────────────────────────────
    print("[9] No GATE-BLOCKED in trade_engine.py")
    te_path = _ROOT / "apollo_core" / "trade_engine.py"
    te_txt = te_path.read_text(encoding="utf-8")
    has_blocked = "GATE-BLOCKED" in te_txt
    check("no GATE-BLOCKED in trade_engine", not has_blocked)

    # ── 10. Renko signals evaluate without error ─────────────────────────
    print("[10] Renko signals evaluate without error")
    try:
        from apollo_core.renko import eval_renko_signals, compute_renko_bricks, compute_renko_rsi
        import numpy as np
        import pandas as pd
        from backtest_engine.eod2_loader import load_eod2_stock
        df_d, _, _ = load_eod2_stock(str(_ROOT / "data"), "CYIENTDLM")
        renko_df = compute_renko_bricks(df_d)
        if len(renko_df) > 5:
            renko_rsi = compute_renko_rsi(renko_df)
            sigs = eval_renko_signals(renko_df, None, len(renko_df) - 1, renko_rsi)
            r_fired = sum(1 for k, (pts, fired) in sigs.items() if fired)
            check("renko signals evaluate", r_fired >= 0)
        else:
            check("renko signals evaluate", True, "insufficient bricks (ok)")
    except Exception as e:  # noqa: BLE001
        check("renko signals evaluate", False, str(e)[:200])

    # ── 11. Central data repo module exists ──────────────────────────────
    print("[11] Central data repo module exists (v4.8)")
    check("data_repo/__init__.py exists", (_ROOT / "data_repo/__init__.py").exists())
    check("data_repo/repo.py exists", (_ROOT / "data_repo/repo.py").exists())
    check("data_repo/sources.py exists", (_ROOT / "data_repo/sources.py").exists())
    check("data_repo/sync.py exists", (_ROOT / "data_repo/sync.py").exists())

    # ── 12. apollo_universe.json exists ──────────────────────────────────
    print("[12] apollo_universe.json exists")
    import json
    au_path = _ROOT / "apollo_universe.json"
    if au_path.exists():
        au = json.loads(au_path.read_text(encoding="utf-8"))
        check("universe has symbols", len(au.get("symbols", [])) > 0)
        has_source = all("source" in s for s in au.get("symbols", []))
        check("universe has source field", has_source)
    else:
        check("apollo_universe.json exists", False)
        check("universe has symbols", False)
        check("universe has source field", False)

    # ── 13. RENKO_HARD_GATE = 0 ──────────────────────────────────────────
    print("[13] RENKO_HARD_GATE = 0")
    from apollo_core.constants import RENKO_HARD_GATE
    check("RENKO_HARD_GATE is 0", RENKO_HARD_GATE == 0, f"value={RENKO_HARD_GATE}")

    # ── 14. Version string consistency ───────────────────────────────────
    print("[14] Version string consistency")
    version_ok = True
    version_errors = []
    # Check scoring.py
    sc_path = _ROOT / "apollo_core" / "scoring.py"
    sc_txt = sc_path.read_text(encoding="utf-8")[:500]
    if CURRENT_VERSION not in sc_txt:
        version_ok = False
        version_errors.append("scoring.py")
    # Check trade_engine.py
    te_check = (_ROOT / "apollo_core" / "trade_engine.py").read_text(encoding="utf-8")[:500]
    if CURRENT_VERSION not in te_check:
        version_ok = False
        version_errors.append("trade_engine.py")
    check("version consistent across files", version_ok, f"missing in {version_errors}")

    # ── Summary ─────────────────────────────────────────────────────────
    print(f"\n{'=' * 60}")
    print(f"Pre-flight complete: {PASS} passed, {FAIL} failed")
    if FAIL:
        print("Failures:")
        for f in FAILURES:
            print(f"  - {f}")
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())

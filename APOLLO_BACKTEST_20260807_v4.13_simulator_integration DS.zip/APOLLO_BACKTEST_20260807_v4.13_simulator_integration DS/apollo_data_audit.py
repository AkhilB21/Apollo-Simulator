#!/usr/bin/env python3
"""
=================================================================
Apollo Data Audit Tool v1.0
=================================================================

Comprehensive audit for CSV source data and Parquet repository integrity.
Validates data format, OHLCV consistency, CSV-to-Parquet fidelity,
and flags statistical anomalies that could corrupt backtest results.

Usage:
    # Audit CSVs only (no Parquet comparison)
    python apollo_data_audit.py --csv-dir C:\\path\\to\\eod2_csvs

    # Audit CSVs AND compare with Parquet repo
    python apollo_data_audit.py \
        --csv-dir C:\\path\\to\\eod2_csvs \
        --parquet-dir C:\\path\\to\\APOLLO_DATA_REPOSITORY

    # Audit specific symbols only
    python apollo_data_audit.py \
        --csv-dir C:\\path\\to\\eod2_csvs \
        --parquet-dir C:\\path\\to\\APOLLO_DATA_REPOSITORY \
        --symbols SBIN,RELIANCE,TCS,INFY

    # Save report to HTML file
    python apollo_data_audit.py \
        --csv-dir C:\\path\\to\\eod2_csvs \
        --parquet-dir C:\\path\\to\\APOLLO_DATA_REPOSITORY \
        --report audit_report.html

    # Strict mode: fail on any OHLCV violation
    python apollo_data_audit.py \
        --csv-dir C:\\path\\to\\eod2_csvs \
        --strict

Requires: pandas, numpy, pyarrow (for Parquet reading)
=================================================================
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

# ============================================================================
# Constants
# ============================================================================

REQUIRED_OHLCV = {"open", "high", "low", "close", "volume"}
DATE_COL_CANDIDATES = ["Date", "date", "DATE", "Timestamp", "timestamp"]

# Indian trading calendar heuristic: weekdays only (simplified)
# In production you'd use an exchange calendar library
WEEKEND_DAYS = {5, 6}  # Saturday=5, Sunday=6

# Severity levels
SEV_CRITICAL = "CRITICAL"  # Data is broken, sync will fail or produce garbage
SEV_ERROR = "ERROR"      # Data violation that affects backtest accuracy
SEV_WARNING = "WARNING"  # Suspicious but may be legitimate
SEV_INFO = "INFO"        # Informational


# ============================================================================
# Data Classes
# ============================================================================

class AuditIssue:
    """Single audit finding."""
    def __init__(self, symbol: str, severity: str, category: str,
                 message: str, detail: str = ""):
        self.symbol = symbol
        self.severity = severity
        self.category = category
        self.message = message
        self.detail = detail

    def to_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "severity": self.severity,
            "category": self.category,
            "message": self.message,
            "detail": self.detail,
        }


class SymbolAuditResult:
    """Audit results for one symbol."""
    def __init__(self, symbol: str):
        self.symbol = symbol
        self.issues: list[AuditIssue] = []
        self.csv_rows = 0
        self.parquet_rows = 0
        self.csv_date_start: Optional[str] = None
        self.csv_date_end: Optional[str] = None
        self.parquet_date_start: Optional[str] = None
        self.parquet_date_end: Optional[str] = None
        self.csv_file_size = 0
        self.parquet_file_size = 0
        self.csv_columns: list[str] = []
        self.parquet_columns: list[str] = []
        self.fidelity_match = None  # True/False/None
        self.value_diffs = 0

    @property
    def has_critical(self) -> bool:
        return any(i.severity == SEV_CRITICAL for i in self.issues)

    @property
    def has_errors(self) -> bool:
        return any(i.severity in (SEV_CRITICAL, SEV_ERROR) for i in self.issues)

    @property
    def issue_count(self) -> int:
        return len(self.issues)


class AuditReport:
    """Complete audit report across all symbols."""
    def __init__(self):
        self.results: dict[str, SymbolAuditResult] = {}
        self.start_time: Optional[datetime] = None
        self.end_time: Optional[datetime] = None
        self.csv_dir = ""
        self.parquet_dir = ""
        self.csv_symbols: set[str] = set()
        self.parquet_symbols: set[str] = set()
        self.global_issues: list[AuditIssue] = []

    @property
    def total_issues(self) -> int:
        return sum(r.issue_count for r in self.results.values())

    @property
    def total_critical(self) -> int:
        return sum(
            1 for r in self.results.values()
            for i in r.issues if i.severity == SEV_CRITICAL
        )

    @property
    def total_errors(self) -> int:
        return sum(
            1 for r in self.results.values()
            for i in r.issues if i.severity == SEV_ERROR
        )

    @property
    def total_warnings(self) -> int:
        return sum(
            1 for r in self.results.values()
            for i in r.issues if i.severity == SEV_WARNING
        )

    @property
    def symbols_with_issues(self) -> int:
        return sum(1 for r in self.results.values() if r.issue_count > 0)

    @property
    def symbols_clean(self) -> int:
        return sum(1 for r in self.results.values() if r.issue_count == 0)

    @property
    def fidelity_mismatches(self) -> int:
        return sum(
            1 for r in self.results.values()
            if r.fidelity_match is False
        )


# ============================================================================
# Audit Functions
# ============================================================================

def _add_issue(result: SymbolAuditResult, severity: str, category: str,
               message: str, detail: str = ""):
    result.issues.append(AuditIssue(result.symbol, severity, category, message, detail))


def _detect_date_col(df: pd.DataFrame) -> Optional[str]:
    """Detect which column is the date column."""
    for candidate in DATE_COL_CANDIDATES:
        if candidate in df.columns:
            return candidate
    # Check index
    if isinstance(df.index, pd.DatetimeIndex):
        return "index"
    return None


def _parse_date_col(df: pd.DataFrame, date_col: str) -> pd.Series:
    """Parse date column to datetime."""
    if date_col == "index":
        return pd.to_datetime(df.index, errors="coerce")
    return pd.to_datetime(df[date_col], errors="coerce")


def audit_csv_format(csv_path: Path, result: SymbolAuditResult) -> pd.DataFrame:
    """Audit a single CSV file for format issues. Returns parsed DataFrame."""
    symbol = result.symbol

    # --- File level checks ---
    result.csv_file_size = csv_path.stat().st_size
    if result.csv_file_size == 0:
        _add_issue(result, SEV_CRITICAL, "csv_format",
                    "Empty CSV file (0 bytes)")
        return pd.DataFrame()

    if result.csv_file_size < 50:
        _add_issue(result, SEV_WARNING, "csv_format",
                    f"Very small CSV file ({result.csv_file_size} bytes) - possibly truncated",
                    f"Path: {csv_path}")

    # --- Read CSV ---
    try:
        raw_df = pd.read_csv(csv_path, nrows=5)
        df = pd.read_csv(csv_path)
    except pd.errors.EmptyDataError:
        _add_issue(result, SEV_CRITICAL, "csv_format",
                    "CSV file is empty or has no parsable data")
        return pd.DataFrame()
    except pd.errors.ParserError as e:
        _add_issue(result, SEV_CRITICAL, "csv_format",
                    f"CSV parsing error: {e}",
                    "File may have inconsistent quoting or delimiters")
        return pd.DataFrame()
    except Exception as e:
        _add_issue(result, SEV_CRITICAL, "csv_format",
                    f"Unexpected error reading CSV: {e}")
        return pd.DataFrame()

    if df.empty:
        _add_issue(result, SEV_CRITICAL, "csv_format",
                    "CSV file parsed but contains 0 data rows")
        return pd.DataFrame()

    result.csv_rows = len(df)
    result.csv_columns = list(df.columns)

    # --- Column name check ---
    stripped_cols = {c.strip().lower() for c in df.columns}
    missing_ohlcv = REQUIRED_OHLCV - stripped_cols
    if missing_ohlcv:
        _add_issue(result, SEV_ERROR, "csv_format",
                    f"Missing OHLCV columns: {sorted(missing_ohlcv)}",
                    f"Available columns: {list(df.columns)}")

    # Extra columns beyond OHLCV - informational
    extra_cols = stripped_cols - REQUIRED_OHLCV - {c.lower() for c in DATE_COL_CANDIDATES}
    if extra_cols and not missing_ohlcv:
        _add_issue(result, SEV_INFO, "csv_format",
                    f"Extra columns will be dropped during sync: {sorted(extra_cols)}")

    # --- Date column detection ---
    date_col = _detect_date_col(df)
    if date_col is None:
        _add_issue(result, SEV_CRITICAL, "csv_format",
                    "No date column found. Checked: " + ", ".join(DATE_COL_CANDIDATES),
                    f"Available columns: {list(df.columns)}")
        return df

    # --- Date parsing ---
    dates = _parse_date_col(df, date_col)
    n_bad_dates = dates.isna().sum()
    if n_bad_dates > 0:
        pct = n_bad_dates / len(dates) * 100
        if pct > 10:
            _add_issue(result, SEV_ERROR, "csv_format",
                        f"{n_bad_dates}/{len(dates)} rows ({pct:.1f}%) have unparseable dates",
                        "Check for mixed date formats in the CSV")
        elif pct > 0:
            _add_issue(result, SEV_WARNING, "csv_format",
                        f"{n_bad_dates}/{len(dates)} rows ({pct:.1f}%) have unparseable dates")

    # --- Duplicate dates ---
    valid_dates = dates.dropna()
    if len(valid_dates) > 0:
        n_dupes = valid_dates.duplicated().sum()
        if n_dupes > 0:
            _add_issue(result, SEV_WARNING, "csv_format",
                        f"{n_dupes} duplicate date(s) found",
                        "sync.py deduplicates (keeps last), but verify data accuracy")

        # --- Chronological order ---
        is_sorted = valid_dates.is_monotonic_increasing
        if not is_sorted:
            _add_issue(result, SEV_WARNING, "csv_format",
                        "Dates are not in chronological order",
                        "sync.py sorts by date, so this is auto-corrected")

        # --- Date range ---
        result.csv_date_start = str(valid_dates.min().date())
        result.csv_date_end = str(valid_dates.max().date())

        # --- Stale data check ---
        days_since_last = (datetime.now() - valid_dates.max().to_pydatetime()).days
        if days_since_last > 7:
            _add_issue(result, SEV_WARNING, "stale_data",
                        f"Last data point is {days_since_last} days old (ending {result.csv_date_end})",
                        "CSV may not have been updated recently")

        # --- Trading day gap analysis ---
        if len(valid_dates) >= 5:
            sorted_dates = valid_dates.sort_values()
            date_diffs = sorted_dates.diff().dt.days.dropna()
            # Gaps > 7 days on weekdays are suspicious (beyond normal weekends+holidays)
            large_gaps = date_diffs[date_diffs > 7]
            if len(large_gaps) > 0:
                gap_details = []
                for idx, gap in large_gaps.items():
                    gap_date = sorted_dates.loc[idx]
                    gap_details.append(f"  {pd.Timestamp(gap_date).strftime('%Y-%m-%d')}: {int(gap)} day gap")
                    if len(gap_details) >= 3:
                        gap_details.append(f"  ... and {len(large_gaps) - 3} more")
                        break
                _add_issue(result, SEV_WARNING, "data_gap",
                            f"{len(large_gaps)} suspicious trading-day gap(s) (>7 days):\n"
                            + "\n".join(gap_details),
                            "Could be exchange holidays, but verify against exchange calendar")

    return df


def audit_ohlcv_integrity(df: pd.DataFrame, result: SymbolAuditResult) -> None:
    """Check OHLCV logical consistency."""
    if df.empty:
        return

    stripped_cols = {c.strip().lower() for c in df.columns}

    # Get numeric columns
    numeric_data = {}
    for col_name, std_name in [("open", "open"), ("high", "high"),
                                ("low", "low"), ("close", "close"),
                                ("volume", "volume")]:
        # Find the actual column name (case-insensitive)
        actual_col = None
        for c in df.columns:
            if c.strip().lower() == std_name:
                actual_col = c
                break
        if actual_col is None:
            continue
        numeric_data[std_name] = pd.to_numeric(df[actual_col], errors="coerce")

    if "close" not in numeric_data:
        return

    close = numeric_data["close"]
    n = len(close)

    # --- Non-numeric / NaN in critical columns ---
    for col_name, series in numeric_data.items():
        n_nan = series.isna().sum()
        if n_nan > 0:
            pct = n_nan / n * 100
            if col_name == "close" and pct > 5:
                _add_issue(result, SEV_ERROR, "missing_data",
                            f"{col_name}: {n_nan}/{n} rows ({pct:.1f}%) are NaN or non-numeric")
            elif pct > 20:
                _add_issue(result, SEV_ERROR, "missing_data",
                            f"{col_name}: {n_nan}/{n} rows ({pct:.1f}%) are NaN or non-numeric")
            elif n_nan > 0:
                _add_issue(result, SEV_WARNING, "missing_data",
                            f"{col_name}: {n_nan}/{n} rows ({pct:.1f}%) are NaN or non-numeric")

    # --- Negative prices ---
    for col_name in ["open", "high", "low", "close"]:
        if col_name not in numeric_data:
            continue
        s = numeric_data[col_name]
        n_neg = (s < 0).sum()
        if n_neg > 0:
            _add_issue(result, SEV_ERROR, "invalid_value",
                        f"{col_name}: {n_neg} negative price(s) found",
                        f"Min value: {s.min():.4f}")

    # --- Negative volume ---
    if "volume" in numeric_data:
        n_neg_vol = (numeric_data["volume"] < 0).sum()
        if n_neg_vol > 0:
            _add_issue(result, SEV_ERROR, "invalid_value",
                        f"volume: {n_neg_vol} negative volume(s) found",
                        f"Min volume: {numeric_data['volume'].min():.0f}")

    # --- Zero prices ---
    for col_name in ["open", "high", "low", "close"]:
        if col_name not in numeric_data:
            continue
        s = numeric_data[col_name].dropna()
        if len(s) > 0 and (s == 0).sum() > 0:
            n_zero = (s == 0).sum()
            _add_issue(result, SEV_WARNING, "suspicious_value",
                        f"{col_name}: {n_zero} zero price(s)",
                        "Could be missing data filled with 0 instead of NaN")

    # --- OHLC consistency checks ---
    if all(k in numeric_data for k in ["open", "high", "low", "close"]):
        o, h, l, c = (numeric_data["open"], numeric_data["high"],
                      numeric_data["low"], numeric_data["close"])

        # High must be >= Open, Close, Low
        h_lt_o = (h < o).sum()
        h_lt_c = (h < c).sum()
        h_lt_l = (h < l).sum()

        if h_lt_l > 0:
            _add_issue(result, SEV_ERROR, "ohlcv_violation",
                        f"High < Low in {h_lt_l} row(s)",
                        "Fundamental OHLC violation - data is incorrect")
        if h_lt_o > 0:
            _add_issue(result, SEV_ERROR, "ohlcv_violation",
                        f"High < Open in {h_lt_o} row(s)")
        if h_lt_c > 0:
            _add_issue(result, SEV_ERROR, "ohlcv_violation",
                        f"High < Close in {h_lt_c} row(s)")

        # Low must be <= Open, Close, High
        l_gt_o = (l > o).sum()
        l_gt_c = (l > c).sum()

        if l_gt_o > 0:
            _add_issue(result, SEV_ERROR, "ohlcv_violation",
                        f"Low > Open in {l_gt_o} row(s)")
        if l_gt_c > 0:
            _add_issue(result, SEV_ERROR, "ohlcv_violation",
                        f"Low > Close in {l_gt_c} row(s)")

    # --- Extreme daily returns (potential data errors) ---
    if "close" in numeric_data:
        close_series = numeric_data["close"].dropna()
        if len(close_series) > 1:
            daily_ret = close_series.pct_change().dropna()
            # Indian market: daily circuit limit is typically 5-20% depending on category
            # Flag anything beyond 30% as highly suspicious
            extreme_up = (daily_ret > 0.30).sum()
            extreme_down = (daily_ret < -0.30).sum()
            def _fmt_idx(idx_val):
                """Format index value for display."""
                if isinstance(idx_val, pd.Timestamp):
                    return idx_val.strftime('%Y-%m-%d')
                return str(idx_val)

            if extreme_up > 0:
                worst = daily_ret[daily_ret > 0.30].nlargest(3)
                details = "; ".join(
                    f"{_fmt_idx(d)}: +{r*100:.1f}%"
                    for d, r in worst.items()
                )
                _add_issue(result, SEV_WARNING, "extreme_move",
                            f"{extreme_up} day(s) with >30% gain: {details}",
                            "Could be corporate action (split/bonus) not adjusted, or data error")
            if extreme_down > 0:
                worst = daily_ret[daily_ret < -0.30].nsmallest(3)
                details = "; ".join(
                    f"{_fmt_idx(d)}: {r*100:.1f}%"
                    for d, r in worst.items()
                )
                _add_issue(result, SEV_WARNING, "extreme_move",
                            f"{extreme_down} day(s) with >30% drop: {details}",
                            "Could be corporate action (split/bonus) not adjusted, or data error")

    # --- Zero volume on active trading days ---
    if "volume" in numeric_data and "close" in numeric_data:
        close_series = numeric_data["close"].dropna()
        vol_series = numeric_data["volume"]
        # Days where price changed but volume is 0
        if len(close_series) > 1:
            price_changed = close_series.diff().abs() > 0.001
            zero_vol = (vol_series == 0) | vol_series.isna()
        else:
            price_changed = pd.Series(False, index=close_series.index)
            zero_vol = (vol_series == 0) | vol_series.isna()

        price_changed_no_vol = (price_changed & zero_vol).sum()
        if price_changed_no_vol > 0:
            pct = price_changed_no_vol / len(close_series) * 100
            _add_issue(result, SEV_WARNING, "suspicious_value",
                        f"{price_changed_no_vol} day(s) with price change but zero/missing volume ({pct:.1f}%)",
                        "Suspicious - price moved with no volume recorded")


def audit_statistical_anomalies(df: pd.DataFrame, result: SymbolAuditResult) -> None:
    """Check for statistical anomalies that could indicate data corruption."""
    if df.empty:
        return

    # Get numeric columns
    numeric_data = {}
    for std_name in ["open", "high", "low", "close", "volume"]:
        for c in df.columns:
            if c.strip().lower() == std_name:
                numeric_data[std_name] = pd.to_numeric(df[c], errors="coerce")
                break

    if "close" not in numeric_data:
        return

    close = numeric_data["close"].dropna()
    if len(close) < 20:
        return  # Not enough data for meaningful statistics

    # --- Price precision check ---
    # Indian equity prices should have at most 2 decimal places
    # (some old data may have 4 decimals for very low-priced stocks)
    fractional = close.apply(lambda x: round(x, 2) != x if pd.notna(x) else False)
    n_fractional = fractional.sum()
    if n_fractional > 0:
        pct = n_fractional / len(close) * 100
        if pct > 50:
            _add_issue(result, SEV_WARNING, "precision",
                        f"{n_fractional}/{len(close)} rows ({pct:.1f}%) have >2 decimal places in close",
                        "May cause floating-point comparison issues in backtesting")

    # --- Volume distribution anomalies ---
    if "volume" in numeric_data:
        vol = numeric_data["volume"].dropna()
        vol = vol[vol > 0]  # Exclude zero-volume days
        if len(vol) > 20:
            vol_median = vol.median()
            vol_std = vol.std()
            # Days with volume > 10x median are unusual
            if vol_median > 0:
                vol_spikes = (vol > vol_median * 10).sum()
                if vol_spikes > 0:
                    _add_issue(result, SEV_INFO, "volume_anomaly",
                                f"{vol_spikes} day(s) with volume >10x median ({vol_median:,.0f})",
                                "May be legitimate (block deals, earnings) or data error")

    # --- Streak of identical prices (dead data indicator) ---
    close_vals = close.values
    max_streak = 1
    current_streak = 1
    for i in range(1, len(close_vals)):
        if close_vals[i] == close_vals[i - 1]:
            current_streak += 1
            max_streak = max(max_streak, current_streak)
        else:
            current_streak = 1

    if max_streak >= 10:
        _add_issue(result, SEV_WARNING, "dead_data",
                    f"Close price unchanged for {max_streak} consecutive days",
                    "Possible data freeze - verify the source is still updating")


def audit_parquet_file(parquet_path: Path, result: SymbolAuditResult) -> Optional[pd.DataFrame]:
    """Audit a Parquet file for schema and structural issues."""
    if not parquet_path.exists():
        _add_issue(result, SEV_ERROR, "parquet_missing",
                    f"No Parquet file found (expected: {parquet_path})",
                    "CSV exists but was never synced to Parquet")
        return None

    result.parquet_file_size = parquet_path.stat().st_size

    try:
        df = pd.read_parquet(parquet_path)
    except Exception as e:
        _add_issue(result, SEV_CRITICAL, "parquet_read",
                    f"Failed to read Parquet file: {e}",
                    "File may be corrupted")
        return None

    if df.empty:
        _add_issue(result, SEV_ERROR, "parquet_empty",
                    "Parquet file is empty (0 rows)")
        return df

    result.parquet_rows = len(df)
    result.parquet_columns = list(df.columns)

    # --- Index type check ---
    if not isinstance(df.index, pd.DatetimeIndex):
        # Check if date is in columns
        date_in_cols = any(c.lower() in [d.lower() for d in DATE_COL_CANDIDATES]
                          for c in df.columns)
        if date_in_cols:
            _add_issue(result, SEV_WARNING, "parquet_schema",
                        "Date is stored as a column, not as DatetimeIndex",
                        "repo.py handles this, but index access would fail")
        else:
            _add_issue(result, SEV_ERROR, "parquet_schema",
                        "No DatetimeIndex and no date column detected",
                        f"Index type: {type(df.index).__name__}")
    else:
        # Check for timezone (should be tz-naive)
        if df.index.tz is not None:
            _add_issue(result, SEV_WARNING, "parquet_schema",
                        f"DatetimeIndex has timezone: {df.index.tz}",
                        "repo.py strips timezone on load, but this adds overhead")

        result.parquet_date_start = str(df.index.min().date())
        result.parquet_date_end = str(df.index.max().date())

    # --- Column check ---
    parquet_cols = {c.strip().lower() for c in df.columns}
    missing_in_pq = REQUIRED_OHLCV - parquet_cols
    if missing_in_pq:
        _add_issue(result, SEV_ERROR, "parquet_schema",
                    f"Parquet missing OHLCV columns: {sorted(missing_in_pq)}")

    # --- Data type check ---
    for col in df.columns:
        if col.strip().lower() in REQUIRED_OHLCV:
            if df[col].dtype not in [np.float64, np.float32, np.int64, np.int32]:
                _add_issue(result, SEV_WARNING, "parquet_schema",
                            f"Column '{col}' has unexpected dtype: {df[col].dtype}",
                            "Expected float64 or int64")

    return df


def audit_csv_parquet_fidelity(csv_df: pd.DataFrame, parquet_df: pd.DataFrame,
                                result: SymbolAuditResult) -> None:
    """Compare CSV source data with Parquet to detect data loss or corruption."""
    if csv_df.empty or parquet_df is None or parquet_df.empty:
        return

    symbol = result.symbol

    # --- Normalize both DataFrames for comparison ---
    def normalize_for_compare(df: pd.DataFrame) -> pd.DataFrame:
        """Normalize a DataFrame to a comparable format."""
        df = df.copy()
        # Detect and set date column
        date_col = _detect_date_col(df)
        if date_col and date_col != "index":
            df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
            df = df.dropna(subset=[date_col])
            df = df.set_index(date_col)
        elif isinstance(df.index, pd.DatetimeIndex):
            pass
        else:
            return pd.DataFrame()

        # Strip timezone
        if isinstance(df.index, pd.DatetimeIndex) and df.index.tz is not None:
            df.index = df.index.tz_localize(None)
        df.index.name = "date"

        # Standardize column names
        df.columns = [c.strip().lower() for c in df.columns]

        # Keep only OHLCV, convert to numeric
        keep_cols = [c for c in REQUIRED_OHLCV if c in df.columns]
        for col in keep_cols:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df[keep_cols].sort_index()
        return df

    csv_norm = normalize_for_compare(csv_df)
    pq_norm = normalize_for_compare(parquet_df)

    if csv_norm.empty or pq_norm.empty:
        return

    # --- Row count comparison ---
    row_diff = abs(len(csv_norm) - len(pq_norm))
    if row_diff > 0:
        _add_issue(result, SEV_ERROR, "fidelity",
                    f"Row count mismatch: CSV={len(csv_norm)}, Parquet={len(pq_norm)} (diff={row_diff})",
                    "Data was lost or duplicated during sync")
        result.fidelity_match = False
    else:
        result.fidelity_match = True

    # --- Date range comparison ---
    csv_start = csv_norm.index.min()
    csv_end = csv_norm.index.max()
    pq_start = pq_norm.index.min()
    pq_end = pq_norm.index.max()

    if csv_start != pq_start:
        _add_issue(result, SEV_ERROR, "fidelity",
                    f"Start date mismatch: CSV={csv_start.date()}, Parquet={pq_start.date()}",
                    "Earliest data point lost or not synced")
        result.fidelity_match = False

    if csv_end != pq_end:
        _add_issue(result, SEV_WARNING, "fidelity",
                    f"End date mismatch: CSV={csv_end.date()}, Parquet={pq_end.date()}",
                    "Parquet may be stale - run sync with --update")
        if result.fidelity_match is not False:
            result.fidelity_match = False

    # --- Value-level comparison (sample-based for performance) ---
    common_dates = csv_norm.index.intersection(pq_norm.index)
    if len(common_dates) > 0:
        csv_sample = csv_norm.loc[common_dates]
        pq_sample = pq_norm.loc[common_dates]

        value_diffs = 0
        diff_details = []

        for col in REQUIRED_OHLCV:
            if col not in csv_sample.columns or col not in pq_sample.columns:
                continue

            csv_vals = csv_sample[col].astype(np.float64)
            pq_vals = pq_sample[col].astype(np.float64)

            # Compare with tolerance for floating-point
            diff = (csv_vals - pq_vals).abs()
            mask = diff > 0.005  # More than half paisa difference
            n_diff = mask.sum()

            if n_diff > 0:
                value_diffs += n_diff
                max_diff = diff.max()
                mean_diff = diff[mask].mean()
                diff_details.append(
                    f"  {col}: {n_diff} values differ (max diff: {max_diff:.4f}, "
                    f"mean diff: {mean_diff:.4f})"
                )

        result.value_diffs = value_diffs

        if value_diffs > 0:
            total_cells = len(common_dates) * min(len(csv_sample.columns), len(pq_sample.columns))
            pct = value_diffs / total_cells * 100 if total_cells > 0 else 0
            _add_issue(result, SEV_ERROR, "fidelity",
                        f"{value_diffs}/{total_cells} values differ between CSV and Parquet ({pct:.2f}%):\n"
                        + "\n".join(diff_details[:5]),
                        "Data corruption during CSV-to-Parquet conversion")
            result.fidelity_match = False
        else:
            _add_issue(result, SEV_INFO, "fidelity",
                        f"All {len(common_dates)} common date values match perfectly")

    # --- Missing dates in Parquet that exist in CSV ---
    csv_only_dates = csv_norm.index.difference(pq_norm.index)
    if len(csv_only_dates) > 0:
        _add_issue(result, SEV_WARNING, "fidelity",
                    f"{len(csv_only_dates)} date(s) in CSV but missing from Parquet",
                    f"First 5 missing: {[d.strftime('%Y-%m-%d') for d in csv_only_dates[:5]]}")

    # --- Missing dates in CSV that exist in Parquet ---
    pq_only_dates = pq_norm.index.difference(csv_norm.index)
    if len(pq_only_dates) > 0:
        _add_issue(result, SEV_INFO, "fidelity",
                    f"{len(pq_only_dates)} date(s) in Parquet but not in CSV",
                    f"Likely from a previous sync with different source data")


# ============================================================================
# Report Generation
# ============================================================================

def generate_text_report(report: AuditReport) -> str:
    """Generate a human-readable text report."""
    lines = []
    w = lines.append

    duration = (report.end_time - report.start_time).total_seconds() if report.start_time and report.end_time else 0

    w("")
    w("=" * 72)
    w("  APOLLO DATA AUDIT REPORT")
    w("=" * 72)
    w(f"  Generated : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    w(f"  Duration  : {duration:.1f}s")
    w(f"  CSV Dir   : {report.csv_dir}")
    w(f"  Parquet   : {report.parquet_dir or '(not checked)'}")
    w("=" * 72)
    w("")

    # --- Summary ---
    w("-" * 72)
    w("  SUMMARY")
    w("-" * 72)
    total_symbols = len(report.results)
    w(f"  Total symbols audited  : {total_symbols}")
    w(f"  Symbols with issues    : {report.symbols_with_issues}")
    w(f"  Clean symbols          : {report.symbols_clean}")
    w(f"  CRITICAL issues        : {report.total_critical}")
    w(f"  ERROR issues           : {report.total_errors}")
    w(f"  WARNING issues         : {report.total_warnings}")
    w(f"  Fidelity mismatches    : {report.fidelity_mismatches}")
    w("")

    # --- Global issues ---
    if report.global_issues:
        w("-" * 72)
        w("  GLOBAL ISSUES (cross-symbol)")
        w("-" * 72)
        for issue in report.global_issues:
            w(f"  [{issue.severity}] {issue.message}")
            if issue.detail:
                for dl in issue.detail.split("\n"):
                    w(f"    {dl}")
        w("")

    # --- Per-symbol issues ---
    w("-" * 72)
    w("  SYMBOL-LEVEL ISSUES")
    w("-" * 72)

    # Sort: critical/error first, then alphabetical
    sorted_results = sorted(
        report.results.values(),
        key=lambda r: (0 if r.has_critical else 1 if r.has_errors else 2, r.symbol)
    )

    for res in sorted_results:
        if res.issue_count == 0:
            continue

        w(f"")
        severity_flag = "!!!" if res.has_critical else "!!" if res.has_errors else "!"
        w(f"  {severity_flag} {res.symbol}")
        w(f"     CSV: {res.csv_rows} rows ({res.csv_date_start or 'N/A'} to {res.csv_date_end or 'N/A'})"
          f" | Parquet: {res.parquet_rows} rows ({res.parquet_date_start or 'N/A'} to {res.parquet_date_end or 'N/A'})")

        for issue in res.issues:
            w(f"     [{issue.severity}] ({issue.category}) {issue.message}")
            if issue.detail:
                for dl in issue.detail.split("\n"):
                    w(f"       {dl}")

    # --- Clean symbols (abbreviated) ---
    clean = [r.symbol for r in report.results.values() if r.issue_count == 0]
    if clean:
        w(f"")
        w("-" * 72)
        w(f"  CLEAN SYMBOLS ({len(clean)} total)")
        w("-" * 72)
        # Show first 20, then summary
        display_clean = clean[:20]
        w(f"  {', '.join(display_clean)}")
        if len(clean) > 20:
            w(f"  ... and {len(clean) - 20} more")

    # --- Health Score ---
    w("")
    w("-" * 72)
    w("  DATA HEALTH SCORE")
    w("-" * 72)
    if total_symbols == 0:
        w("  No symbols to evaluate.")
    else:
        # Weighted score: critical=-10, error=-3, warning=-1, info=0
        score = 100.0
        for r in report.results.values():
            for i in r.issues:
                if i.severity == SEV_CRITICAL:
                    score -= 2.0
                elif i.severity == SEV_ERROR:
                    score -= 0.5
                elif i.severity == SEV_WARNING:
                    score -= 0.1

        score = max(0, min(100, score))
        if score >= 95:
            grade = "EXCELLENT"
        elif score >= 85:
            grade = "GOOD"
        elif score >= 70:
            grade = "NEEDS ATTENTION"
        elif score >= 50:
            grade = "POOR"
        else:
            grade = "CRITICAL"

        w(f"  Score: {score:.1f}/100  [{grade}]")
        if score < 85:
            w("")
            w("  Top recommendations:")
            if report.total_critical > 0:
                w(f"  1. Fix {report.total_critical} CRITICAL issues first (broken files/parsing)")
            if report.total_errors > 0:
                w(f"  2. Investigate {report.total_errors} ERROR issues (data integrity)")
            if report.fidelity_mismatches > 0:
                w(f"  3. Re-sync {report.fidelity_mismatches} symbols with fidelity mismatches")
            if report.total_warnings > 0:
                w(f"  4. Review {report.total_warnings} warnings for potential data quality issues")

    w("")
    w("=" * 72)
    w("  END OF AUDIT REPORT")
    w("=" * 72)
    w("")

    return "\n".join(lines)


def generate_html_report(report: AuditReport) -> str:
    """Generate a styled HTML report."""
    duration = (report.end_time - report.start_time).total_seconds() if report.start_time and report.end_time else 0
    total_symbols = len(report.results)

    # Health score
    score = 100.0
    for r in report.results.values():
        for i in r.issues:
            if i.severity == SEV_CRITICAL:
                score -= 2.0
            elif i.severity == SEV_ERROR:
                score -= 0.5
            elif i.severity == SEV_WARNING:
                score -= 0.1
    score = max(0, min(100, score))

    if score >= 95: grade, gcolor = "EXCELLENT", "#22c55e"
    elif score >= 85: grade, gcolor = "GOOD", "#84cc16"
    elif score >= 70: grade, gcolor = "NEEDS ATTENTION", "#f59e0b"
    elif score >= 50: grade, gcolor = "POOR", "#f97316"
    else: grade, gcolor = "CRITICAL", "#ef4444"

    # Build issue rows
    issue_rows_html = ""
    sorted_results = sorted(
        report.results.values(),
        key=lambda r: (0 if r.has_critical else 1 if r.has_errors else 2, r.symbol)
    )
    for res in sorted_results:
        if res.issue_count == 0:
            continue
        for issue in res.issues:
            sev_color = {
                SEV_CRITICAL: "#dc2626",
                SEV_ERROR: "#ea580c",
                SEV_WARNING: "#d97706",
                SEV_INFO: "#6b7280",
            }.get(issue.severity, "#6b7280")
            detail_html = f"<br><small>{issue.detail.replace(chr(10), '<br>')}</small>" if issue.detail else ""
            issue_rows_html += f"""
            <tr>
                <td><strong>{res.symbol}</strong></td>
                <td style="color:{sev_color};font-weight:600">{issue.severity}</td>
                <td>{issue.category}</td>
                <td>{issue.message}{detail_html}</td>
            </tr>"""

    # Clean symbols
    clean = [r.symbol for r in report.results.values() if r.issue_count == 0]
    clean_html = ", ".join(clean[:50])
    if len(clean) > 50:
        clean_html += f" ... and {len(clean) - 50} more"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Apollo Data Audit Report - {datetime.now().strftime('%Y-%m-%d')}</title>
<style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0f172a; color: #e2e8f0; line-height: 1.6; }}
    .container {{ max-width: 1200px; margin: 0 auto; padding: 24px; }}
    .header {{ text-align: center; padding: 32px; margin-bottom: 24px; background: linear-gradient(135deg, #1e293b, #334155); border-radius: 12px; border: 1px solid #334155; }}
    .header h1 {{ font-size: 28px; color: #f8fafc; margin-bottom: 8px; }}
    .header p {{ color: #94a3b8; font-size: 14px; }}
    .score-card {{ text-align: center; padding: 32px; margin-bottom: 24px; background: linear-gradient(135deg, #1e293b, #334155); border-radius: 12px; border: 1px solid #334155; }}
    .score-value {{ font-size: 64px; font-weight: 700; color: {gcolor}; }}
    .score-grade {{ font-size: 20px; color: {gcolor}; font-weight: 600; margin-top: 8px; }}
    .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 16px; margin-bottom: 24px; }}
    .stat-card {{ background: #1e293b; padding: 20px; border-radius: 8px; border: 1px solid #334155; text-align: center; }}
    .stat-value {{ font-size: 32px; font-weight: 700; }}
    .stat-label {{ font-size: 12px; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px; }}
    .stat-critical .stat-value {{ color: #dc2626; }}
    .stat-error .stat-value {{ color: #ea580c; }}
    .stat-warning .stat-value {{ color: #d97706; }}
    .stat-clean .stat-value {{ color: #22c55e; }}
    .section {{ background: #1e293b; border-radius: 12px; border: 1px solid #334155; margin-bottom: 24px; overflow: hidden; }}
    .section-header {{ padding: 16px 24px; background: #334155; font-size: 16px; font-weight: 600; color: #f8fafc; }}
    .section-body {{ padding: 16px 24px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
    th {{ text-align: left; padding: 10px 12px; background: #1e293b; color: #94a3b8; font-weight: 600; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; border-bottom: 1px solid #475569; position: sticky; top: 0; }}
    td {{ padding: 10px 12px; border-bottom: 1px solid #1e293b; vertical-align: top; }}
    tr:hover {{ background: #334155; }}
    .table-scroll {{ max-height: 600px; overflow-y: auto; }}
    .clean-list {{ color: #94a3b8; font-size: 13px; line-height: 1.8; }}
    .recommendations {{ list-style: none; padding: 0; }}
    .recommendations li {{ padding: 12px 0; border-bottom: 1px solid #334155; font-size: 14px; }}
    .recommendations li:last-child {{ border-bottom: none; }}
    .recommendations strong {{ color: #f8fafc; }}
    .footer {{ text-align: center; padding: 24px; color: #64748b; font-size: 12px; }}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Apollo Data Audit Report</h1>
        <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | Duration: {duration:.1f}s</p>
        <p>CSV: {report.csv_dir} | Parquet: {report.parquet_dir or 'Not checked'}</p>
    </div>

    <div class="score-card">
        <div class="score-value">{score:.1f}</div>
        <div class="score-grade">{grade}</div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value">{total_symbols}</div>
            <div class="stat-label">Total Symbols</div>
        </div>
        <div class="stat-card stat-clean">
            <div class="stat-value">{report.symbols_clean}</div>
            <div class="stat-label">Clean</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{report.symbols_with_issues}</div>
            <div class="stat-label">With Issues</div>
        </div>
        <div class="stat-card stat-critical">
            <div class="stat-value">{report.total_critical}</div>
            <div class="stat-label">Critical</div>
        </div>
        <div class="stat-card stat-error">
            <div class="stat-value">{report.total_errors}</div>
            <div class="stat-label">Errors</div>
        </div>
        <div class="stat-card stat-warning">
            <div class="stat-value">{report.total_warnings}</div>
            <div class="stat-label">Warnings</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{report.fidelity_mismatches}</div>
            <div class="stat-label">Fidelity Mismatches</div>
        </div>
    </div>

    <div class="section">
        <div class="section-header">Issues Detail ({report.total_issues} total)</div>
        <div class="table-scroll">
            <table>
                <thead>
                    <tr><th>Symbol</th><th>Severity</th><th>Category</th><th>Issue</th></tr>
                </thead>
                <tbody>
                    {issue_rows_html if issue_rows_html else '<tr><td colspan="4" style="text-align:center;color:#64748b;padding:32px">No issues found - all data is clean!</td></tr>'}
                </tbody>
            </table>
        </div>
    </div>

    <div class="section">
        <div class="section-header">Clean Symbols ({len(clean)} total)</div>
        <div class="section-body clean-list">
            {clean_html if clean_html else '<span style="color:#64748b">No clean symbols</span>'}
        </div>
    </div>

    <div class="footer">
        Apollo Data Audit Tool v1.0 | Data quality is the foundation of reliable backtesting
    </div>
</div>
</body>
</html>"""

    return html


# ============================================================================
# Main Audit Orchestrator
# ============================================================================

def run_audit(csv_dir: str, parquet_dir: Optional[str] = None,
              symbols: Optional[list[str]] = None, strict: bool = False) -> AuditReport:
    """Run the complete data audit."""
    report = AuditReport()
    report.start_time = datetime.now()
    report.csv_dir = csv_dir
    report.parquet_dir = parquet_dir or ""

    csv_path = Path(csv_dir)
    if not csv_path.is_dir():
        print(f"ERROR: CSV directory not found: {csv_dir}")
        return report

    # Get list of CSV files
    csv_files = sorted(csv_path.glob("*.csv"))
    if not csv_files:
        print(f"ERROR: No CSV files found in {csv_dir}")
        return report

    # Filter to specific symbols if requested
    if symbols:
        symbol_set = {s.upper().strip() for s in symbols}
        csv_files = [f for f in csv_files if f.stem.upper() in symbol_set]
        if not csv_files:
            print(f"ERROR: None of the requested symbols found: {symbols}")
            return report

    # Get Parquet files if comparing
    pq_path = None
    if parquet_dir:
        pq_path = Path(parquet_dir)
        if not pq_path.is_dir():
            print(f"WARNING: Parquet directory not found: {parquet_dir}")
            print("  Running CSV-only audit.")
            pq_path = None

    # Get symbol sets for cross-checking
    report.csv_symbols = {f.stem.upper() for f in csv_path.glob("*.csv")}
    if pq_path:
        report.parquet_symbols = {f.stem.upper() for f in pq_path.glob("*.parquet")}

    # Cross-symbol checks
    if pq_path:
        csv_only = report.csv_symbols - report.parquet_symbols
        pq_only = report.parquet_symbols - report.csv_symbols

        if csv_only:
            report.global_issues.append(AuditIssue(
                "*", SEV_WARNING, "sync_gap",
                f"{len(csv_only)} symbols in CSV but NOT in Parquet (never synced)",
                f"Examples: {sorted(csv_only)[:10]}"
            ))
        if pq_only:
            report.global_issues.append(AuditIssue(
                "*", SEV_INFO, "sync_gap",
                f"{len(pq_only)} symbols in Parquet but NOT in CSV (source removed?)",
                f"Examples: {sorted(pq_only)[:10]}"
            ))

    # Process each symbol
    total = len(csv_files)
    last_pct = -1

    for idx, csv_file in enumerate(csv_files):
        symbol = csv_file.stem.upper()
        result = SymbolAuditResult(symbol)

        # Progress
        pct = int((idx + 1) / total * 100)
        if pct % 10 == 0 and pct != last_pct:
            print(f"  Auditing... {pct}% ({idx + 1}/{total}) [{symbol}]", flush=True)
            last_pct = pct

        # 1. CSV format audit
        csv_df = audit_csv_format(csv_file, result)

        # 2. OHLCV integrity check
        if not csv_df.empty:
            audit_ohlcv_integrity(csv_df, result)

        # 3. Statistical anomaly check
        if not csv_df.empty:
            audit_statistical_anomalies(csv_df, result)

        # 4. Parquet audit and fidelity (if comparing)
        if pq_path:
            parquet_file = pq_path / f"{symbol}.parquet"
            parquet_df = audit_parquet_file(parquet_file, result)
            if parquet_df is not None and not csv_df.empty:
                audit_csv_parquet_fidelity(csv_df, parquet_df, result)

        report.results[symbol] = result

    report.end_time = datetime.now()
    return report


# ============================================================================
# Default Paths (hardcoded for this Apollo installation)
# ============================================================================

DEFAULT_CSV_DIR = r"C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\eod2-main\eod2-main\src\eod2_data\daily"
DEFAULT_PARQUET_DIR = r"C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\APOLLO_DATA_REPOSITORY"


# ============================================================================
# CLI Entry Point
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Apollo Data Audit Tool v1.0 - Validate CSV and Parquet data integrity",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s                              (uses hardcoded default paths)
  %(prog)s --symbols SBIN,RELIANCE       (audit specific symbols only)
  %(prog)s --report audit.html          (save HTML + JSON report)
  %(prog)s --csv-dir "C:\\other"       (override default CSV path)
        """
    )
    parser.add_argument("--csv-dir", default=DEFAULT_CSV_DIR,
                        help=f"Directory containing eod2 CSV files (default: {DEFAULT_CSV_DIR})")
    parser.add_argument("--parquet-dir", default=DEFAULT_PARQUET_DIR,
                        help=f"Parquet repository directory (default: {DEFAULT_PARQUET_DIR})")
    parser.add_argument("--symbols", default=None,
                        help="Comma-separated list of symbols to audit (default: all)")
    parser.add_argument("--report", default=None,
                        help="Output HTML report to this file path")
    parser.add_argument("--strict", action="store_true",
                        help="Exit with error code if any OHLCV violations found")
    args = parser.parse_args()

    # Parse symbols
    symbols = None
    if args.symbols:
        symbols = [s.strip().upper() for s in args.symbols.split(",")]

    print()
    print("=" * 60)
    print("  Apollo Data Audit Tool v1.0")
    print("=" * 60)
    print(f"  CSV Dir   : {args.csv_dir}")
    print(f"  Parquet   : {args.parquet_dir or '(not checking)'}")
    print(f"  Symbols   : {', '.join(symbols) if symbols else 'ALL'}")
    print("=" * 60)
    print()

    # Run audit
    report = run_audit(
        csv_dir=args.csv_dir,
        parquet_dir=args.parquet_dir,
        symbols=symbols,
        strict=args.strict,
    )

    if not report.results:
        print("No symbols were audited. Check paths and try again.")
        sys.exit(1)

    # Print text report to console
    text_report = generate_text_report(report)
    print(text_report)

    # Save HTML report if requested
    if args.report:
        html_report = generate_html_report(report)
        report_path = Path(args.report)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(html_report, encoding="utf-8")
        print(f"  HTML report saved to: {report_path}")
        print()

    # Save JSON machine-readable report alongside HTML
    if args.report:
        json_path = report_path.with_suffix(".json")
        json_data = {
            "generated": datetime.now().isoformat(),
            "csv_dir": report.csv_dir,
            "parquet_dir": report.parquet_dir,
            "total_symbols": len(report.results),
            "health_score": max(0, min(100, 100.0 - sum(
                2.0 if i.severity == SEV_CRITICAL else 0.5 if i.severity == SEV_ERROR else 0.1 if i.severity == SEV_WARNING else 0
                for r in report.results.values() for i in r.issues
            ))),
            "total_critical": report.total_critical,
            "total_errors": report.total_errors,
            "total_warnings": report.total_warnings,
            "symbols_with_issues": report.symbols_with_issues,
            "symbols_clean": report.symbols_clean,
            "fidelity_mismatches": report.fidelity_mismatches,
            "issues": [
                i.to_dict()
                for r in sorted(report.results.values(),
                               key=lambda r: (0 if r.has_critical else 1 if r.has_errors else 2, r.symbol))
                for i in r.issues
            ],
        }
        json_path.write_text(json.dumps(json_data, indent=2, default=str), encoding="utf-8")
        print(f"  JSON report saved to: {json_path}")
        print()

    # Exit code
    if args.strict and (report.total_critical > 0 or report.total_errors > 0):
        print(f"  STRICT MODE: Exiting with error code (critical={report.total_critical}, errors={report.total_errors})")
        sys.exit(1)


if __name__ == "__main__":
    main()

"""Apollo Simulator — Indicator exit sweep and walk-forward analysis.

Standalone scripts for testing INDICATOR_SL exit modes against
the Apollo scoring engine. Uses APOLLO_DATA_ROOT from apollo_core.config.

Scripts:
    indicator_engine_test  — Engine-based INDICATOR_SL sweep
    indicator_sweep       — Consistent close-to-close metric sweep
    walk_forward          — Walk-forward config selection (honest OOS test)
    regime_analysis       — Drawdown-regime analysis
"""

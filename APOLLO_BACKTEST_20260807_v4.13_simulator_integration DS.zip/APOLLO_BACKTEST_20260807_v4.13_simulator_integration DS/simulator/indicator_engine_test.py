"""Apollo Simulator — Engine-based INDICATOR_SL sweep.

Runs the full engine (gap-aware fills) for each INDICATOR_SL mode
with disaster SL backstops. Validates that FIXED_SL baseline is
reproduced correctly.

Usage:
    python -m simulator.indicator_engine_test [SYMBOL]
"""

from __future__ import annotations
import sys
import os
import warnings
warnings.filterwarnings("ignore")

_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_this_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

import numpy as np
from backtest_engine.backtest import run_stock_backtest
from apollo_core.config import APOLLO_DATA_ROOT

SYMBOL = sys.argv[1] if len(sys.argv) > 1 else "APOLLO"
DATA = APOLLO_DATA_ROOT
S = "2018-01-22"
E = "2026-08-04"


def kpis(r):
    c = r["completed"]
    rets = np.array([e["pnl"] for e in c]) / 100.0
    comp = np.prod(1 + rets) - 1 if len(rets) else 0
    n = len(c)
    yrs = 8.54
    ann = (1 + comp) ** (1 / yrs) - 1 if comp > -1 else float("-inf")
    win = (np.mean(rets > 0) * 100) if n else 0
    from collections import Counter
    reasons = Counter()
    for e in r["trades"]:
        if e["type"] != "EXIT":
            continue
        for k in ["HARD_SL", "TRAILING_SL", "DIVERGENCE",
                   "INDICATOR_", "SCORE<", "DI_CROSSOVER", "PERIOD_END"]:
            if k in e.get("exit_reason", ""):
                reasons[k] = reasons.get(k, 0) + 1
                break
    return f"n={n:3d} comp={comp*100:+7.1f}% ann={ann*100:+6.1f}% win={win:4.1f}%  {dict(reasons)}"


print(f"=== INDICATOR_SL ENGINE SWEEP: {SYMBOL} ===")
print()

# Validation: FIXED_SL 5% baseline
base = run_stock_backtest(
    data_dir=DATA, symbol=SYMBOL, start_date=S, end_date=E,
    exit_mode="FIXED_SL", sl_percent=5.0, entry_threshold=70, exit_threshold=50,
)
print(f"FIXED_SL 5% (baseline):")
print(f"  {kpis(base)}")
print()

# INDICATOR_SL sweep
print("INDICATOR_SL sweep (disaster SL = sl_percent backstop):")
modes = [
    ("SMA20",), ("SMA50",), ("MACD",), ("MACD_HIST",), ("ADX",),
    ("RSI_SAT",), ("STOCH",), ("DI",),
]
for ind in modes:
    for sl in (15.0, 20.0, 25.0):
        r = run_stock_backtest(
            data_dir=DATA, symbol=SYMBOL, start_date=S, end_date=E,
            exit_mode="INDICATOR_SL", sl_percent=sl,
            entry_threshold=70, exit_threshold=50, indicator_exit=ind[0],
        )
        print(f"  {ind[0]:10s} +disasterSL {sl:4.1f}% : {kpis(r)}")

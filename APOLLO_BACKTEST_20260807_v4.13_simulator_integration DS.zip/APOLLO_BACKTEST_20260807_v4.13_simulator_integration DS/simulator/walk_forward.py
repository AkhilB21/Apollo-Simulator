"""Apollo Simulator — Walk-forward indicator exit selection.

Config selected on PRIOR data only, evaluated on SUBSEQUENT trades.
This is the honest out-of-sample test.

Usage:
    python -m simulator.walk_forward [SYMBOL]
"""

from __future__ import annotations
import sys
import os
import warnings
warnings.filterwarnings("ignore")

_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_this_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

import pandas as pd
import numpy as np
from backtest_engine.backtest import run_stock_backtest
from backtest_engine.eod2_loader import load_eod2_stock
from apollo_core.config import APOLLO_DATA_ROOT

SYMBOL = sys.argv[1] if len(sys.argv) > 1 else "APOLLO"
DATA = APOLLO_DATA_ROOT
START = "2018-01-22"
END = "2026-08-04"

df_d, _, _ = load_eod2_stock(DATA, SYMBOL)
close = df_d["close"].values
idx = pd.DatetimeIndex(df_d.index)


def iof(dt):
    return idx.get_indexer([pd.Timestamp(dt)], method="nearest")[0]


def trades_for(cfg, start=START, end=END):
    mode, sl, ind = cfg
    r = run_stock_backtest(
        data_dir=DATA, symbol=SYMBOL, start_date=start, end_date=end,
        exit_mode=mode, sl_percent=sl,
        entry_threshold=70, exit_threshold=50, indicator_exit=ind,
    )
    rows = []
    for c in r["completed"]:
        ei = iof(c["entry_date"])
        xi = iof(c["date"])
        if xi > ei and xi < len(close):
            rows.append({
                "ret": close[xi] / close[ei] - 1,
                "exit_date": pd.Timestamp(c["date"]),
                "entry_date": pd.Timestamp(c["entry_date"]),
            })
    return pd.DataFrame(rows)


def perf(df, T=None, after=None):
    if df.empty:
        return dict(n=0, comp=0.0, ann=0.0, win=0.0)
    d = df
    if T is not None:
        d = d[d["exit_date"] <= T]
    if after is not None:
        d = d[d["entry_date"] >= after]
    if len(d) == 0:
        return dict(n=0, comp=0.0, ann=0.0, win=0.0)
    comp = np.prod(1 + d["ret"]) - 1
    years = max((d["exit_date"].max() - d["entry_date"].min()).days, 30) / 365.25
    ann = ((1 + comp) ** (1 / years) - 1) * 100
    return dict(n=len(d), comp=comp, ann=ann, win=(d["ret"] > 0).mean() * 100)


def bh(a, b):
    ai = iof(a)
    bi = iof(b)
    y = (idx[bi] - idx[ai]).days / 365.25
    r = close[bi] / close[ai] - 1
    return r * 100, ((1 + r) ** (1 / y) - 1) * 100, y


# Candidate configs
CANDIDATES = []
for sl in (5.0, 10.0, 15.0, 20.0, 25.0):
    CANDIDATES.append(("FIXED_SL", sl, ""))
for ind in ("SMA20", "SMA50", "MACD_HIST", "RSI_SAT", "DI", "STOCH", "ADX", "MACD"):
    for sl in (15.0, 20.0, 25.0):
        CANDIDATES.append(("INDICATOR_SL", sl, ind))

FOLDS = [("2023-01-01", "2026-08-04"), ("2024-01-01", "2026-08-04")]

print("=" * 74, flush=True)
print(f"WALK-FORWARD: {SYMBOL} — config selected on PRIOR data only", flush=True)
print("=" * 74, flush=True)

for T, test_end in FOLDS:
    print(f"\n--- Fold: train < {T}, test [{T}..{test_end}] ---", flush=True)
    sel = {}
    for cfg in CANDIDATES:
        mode, sl, ind = cfg
        df = trades_for(cfg, START, test_end)
        tr = perf(df, T=T)
        sel[cfg] = tr
    ranked = sorted(sel.items(), key=lambda kv: kv[1]["ann"], reverse=True)
    print("  Top-8 configs by TRAIN ann:")
    for cfg, tr in ranked[:8]:
        print(
            f"    {cfg[0]:12s} {cfg[1]:4.0f} {cfg[2]:9s}: "
            f"n={tr['n']:3d} ann={tr['ann']:+6.1f}% comp={tr['comp']*100:+8.1f}%",
            flush=True,
        )
    eligible = {cfg: tr for cfg, tr in sel.items() if tr["n"] >= 8}
    best = max(eligible, key=lambda c: eligible[c]["ann"])
    print(
        f"  >> SELECTED: {best[0]} sl={best[1]:.0f} ind={best[2]!r} "
        f"(train ann={eligible[best]['ann']:+.1f}%, n={eligible[best]['n']})",
        flush=True,
    )

    oos = perf(trades_for(best, START, test_end), after=T)
    bh_pct, bh_ann, y = bh(T, test_end)
    for label, cfg in [
        ("SL20 baseline", ("FIXED_SL", 20.0, "")),
        ("RSI_SAT+20", ("INDICATOR_SL", 20.0, "RSI_SAT")),
        ("SL5 status quo", ("FIXED_SL", 5.0, "")),
    ]:
        o = perf(trades_for(cfg, START, test_end), after=T)
        print(
            f"    [{label:30s}]: n={o['n']:3d} "
            f"comp={o['comp']*100:+8.1f}% ann={o['ann']:+6.1f}% win={o['win']:4.0f}%",
            flush=True,
        )
    print(f"  OUT-OF-SAMPLE [{T}..{test_end}] ({y:.1f}y):", flush=True)
    print(
        f"    >> SELECTED {best[0]} sl={best[1]:.0f} ind={best[2]!r}: "
        f"n={oos['n']} comp={oos['comp']*100:+8.1f}% "
        f"ann={oos['ann']:+6.1f}% win={oos['win']:.0f}%",
        flush=True,
    )
    print(f"    Buy & hold span: comp={bh_pct:+8.1f}% ann={bh_ann:+6.1f}%", flush=True)

print("\n=== DONE ===", flush=True)

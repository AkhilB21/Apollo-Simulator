"""Apollo Simulator — Drawdown-regime analysis.

Tags each trading day by drawdown-from-60d-high regime, then
analyzes trade entry distribution and per-trade P&L/MaxDD by regime.

Usage:
    python -m simulator.regime_analysis [SYMBOL]
"""

from __future__ import annotations
import sys
import os
import warnings
warnings.filterwarnings("ignore")

_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_this_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

import pandas as pd
import numpy as np
from backtest_engine.eod2_loader import load_eod2_stock
from backtest_engine.backtest import run_stock_backtest
from apollo_core.config import APOLLO_DATA_ROOT
from collections import Counter

SYMBOL = sys.argv[1] if len(sys.argv) > 1 else "APOLLO"
DATA = APOLLO_DATA_ROOT

df_d, _, _ = load_eod2_stock(DATA, SYMBOL)
close = df_d["close"].values
high = df_d["high"].values
idx = pd.DatetimeIndex(df_d.index)

# Regime proxy: drawdown from rolling 60d high of high
roll_high = pd.Series(high, index=idx).rolling(60, min_periods=20).max()
dd = pd.Series(close, index=idx) / roll_high - 1
ddf = dd.to_frame("dd")


def regime_tag(dd_val):
    if dd_val <= -0.20:
        return "CRASH(>20% dd)"
    if dd_val <= -0.10:
        return "BEAR(10-20% dd)"
    if dd_val <= -0.05:
        return "CORR(5-10% dd)"
    return "BULL(<5% dd)"


ddf["regime"] = ddf["dd"].map(regime_tag)
ddf["date"] = idx

# Time distribution and forward returns
print(f"=== Regime Analysis: {SYMBOL} ===")
print("\nTime distribution & 20d forward return by drawdown regime:")
c = close
ddf["fwd20"] = np.nan
for i in range(len(ddf) - 20):
    ddf.iloc[i, ddf.columns.get_loc("fwd20")] = c[i + 20] / c[i] - 1

for reg, grp in ddf.groupby("regime"):
    n = len(grp)
    pct = n / len(ddf) * 100
    fw = grp["fwd20"].mean() * 100
    print(f"  {reg:18s}: {pct:5.1f}% of days (n={n:4d})  20d fwd mean {fw:+6.1f}%")

# Trade entry regime distribution
print(f"\nRegime at TRADE ENTRY (FIXED_SL 20%):")
r = run_stock_backtest(
    data_dir=DATA, symbol=SYMBOL, start_date="2018-01-22", end_date="2026-08-04",
    exit_mode="FIXED_SL", sl_percent=20.0, entry_threshold=70, exit_threshold=50,
)
ent_reg = Counter()
for e in r["entries"]:
    d = pd.Timestamp(e["date"])
    try:
        ent_reg[regime_tag(dd.loc[d])] += 1
    except KeyError:
        pass
for reg, cnt in ent_reg.most_common():
    print(f"  {reg:18s}: {cnt}")

# Per-trade max DD vs regime
print("\nPer-trade max drawdown vs regime (FIXED_SL 20%):")
exc = []
for c_ in r["completed"]:
    ei = idx.get_indexer([pd.Timestamp(c_["entry_date"])], method="nearest")[0]
    xi = idx.get_indexer([pd.Timestamp(c_["date"])], method="nearest")[0]
    low_seg = df_d["low"].iloc[ei:xi + 1]
    mdd = (low_seg.min() / c_["entry_price"] - 1) * 100 if low_seg.min() > 0 else -99
    try:
        exc.append((regime_tag(dd.iloc[ei]), c_["pnl"], mdd, (xi - ei)))
    except (KeyError, IndexError):
        pass
if exc:
    exdf = pd.DataFrame(exc, columns=["regime", "pnl", "mdd", "hold"])
    print(exdf.groupby("regime").agg(
        n=("pnl", "size"), avg_pnl=("pnl", "mean"),
        avg_mdd=("mdd", "mean"), avg_hold=("hold", "mean"),
    ))

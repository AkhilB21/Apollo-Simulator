@echo off
REM ============================================================
REM  Apollo v4.8 — Build Dynamic Universe JSON
REM ============================================================
REM
REM  Run this AFTER syncing Parquet data (run_sync_data.bat)
REM  to update apollo_universe.json with accurate has_parquet flags.
REM

echo.
echo ============================================================
echo   APOLLO v4.8 — BUILD DYNAMIC UNIVERSE
echo ============================================================
echo.

python build_universe.py

echo.
pause

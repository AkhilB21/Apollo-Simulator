"""Apollo Backtest Engine — I/O Wrapper (Phase 1 Refactored)

Handles CSV loading, Layer 1 pre-filter, and KPI computation.
All core logic lives in apollo_core/.

Functions:
    run_stock_backtest — high-level: load -> score -> extract -> KPIs
"""

from __future__ import annotations

import sys
import os
# Ensure project root is on sys.path so apollo_core is importable
_this_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_this_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

import numpy as np
import pandas as pd

from apollo_core.constants import (
    ENTRY_THRESHOLD, EXIT_THRESHOLD, DIVERGENCE_RSI_DROP, DIVERGENCE_COOLDOWN,
    SIGNAL_DEFS, POOL_ORDER, POOL_MAX, POOL_NAMES, POOL_DESC,
    IPO_SIGNAL_DEFS, IPO_POOL_ORDER, IPO_POOL_MAX, IPO_POOL_NAMES,
    DEFAULT_MIN_TRADING_DAYS,
)
from apollo_core.indicators import compute_all_indicators
from apollo_core.bucket_classifier import (
    compute_bucket_metrics, classify_bucket, get_score_multiplier,
    SKIP_BUCKETS,  # retained for UI colour-coding only — never used as a gate
)
from apollo_core.ipo_lookup import is_ipo_by_listing_date, get_listing_close_price
from apollo_core.trade_engine import run_backtest, run_ipo_backtest, extract_trades
from apollo_core.types import TradeEvent, DailyResult, SignalResult


def run_stock_backtest(
    data_dir: str,
    symbol: str,
    start_date: str,
    end_date: str,
    exit_mode: str = "FIXED_SL",
    sl_percent: float = 5.0,
    trailing_sl_percent: float = 3.0,
    trailing_activate_pct: float = 5.0,
    entry_threshold: float = 70,
    exit_threshold: float = 50,
    min_trading_days: int | None = None,
    fundamental_profile: dict | None = None,
    indicator_exit: str = "",
) -> dict:
    """End-to-end backtest for one stock.

    Steps:
      0. Load data via ``eod2_loader.load_eod2_stock``.
      1. Layer 1 pre-filter: detect IPO / skip Structural Decline / Range-Bound.
      2. For IPOs: use ``run_ipo_backtest`` (12 signals, normalized to 0-100).
         For mature stocks: use ``run_backtest`` (21 signals, existing logic).
      3. Extract trades with the chosen exit mode.
      4. Compute KPIs (cum_pnl, win_rate, max_drawdown, ...).

    Returns
    -------
    dict with keys: symbol, exit_mode, daily_df, trades, cum_pnl,
    win_rate, avg_pnl_per_trade, max_drawdown, n_trades, sl_exits,
    div_exits, score_exits, period_end_exits, entries, completed,
    bucket (str), bucket_metrics (dict), is_ipo (bool).
    """
    from backtest_engine.eod2_loader import load_eod2_stock

    if min_trading_days is None:
        min_trading_days = DEFAULT_MIN_TRADING_DAYS

    # (a) Load
    df_d, df_4h, df_w = load_eod2_stock(data_dir, symbol)

    # v4.6: Resolve the trailing PE for the G1 valuation gate from the
    # optional fundamental profile (etmoney snapshot). Absent → G1 skipped.
    pe = None
    if fundamental_profile:
        profile = fundamental_profile.get(symbol.upper()) or fundamental_profile.get(symbol)
        if profile:
            pe = profile.get("pe")

    # (a-b) Layer 0: Listing-date-aware IPO detection (before bucket classifier)
    # Uses ipo_lookup.json for known symbols; falls back to bar-count heuristic.
    ipo_detected, ipo_info = is_ipo_by_listing_date(
        symbol, df_d, min_trading_days,
    )

    # Determine the best listing close price for signal I3
    ipo_listing_close = ipo_info.get("listing_close")

    if ipo_detected:
        # IPO path — skip bucket classifier, go straight to IPO scoring
        layer1_bucket = "IPO / New Listing"
        layer1_metrics = ipo_info
    else:
        # Mature stock or unknown → classify bucket for DISPLAY ONLY (no gating).
        # Every stock reaches the Apollo engine with its raw score intact.
        # The bucket is a label, not a filter — see "BUCKET IS REFERENCE-ONLY"
        # guard in apollo_core/trade_engine.py.
        from apollo_core.bucket_classifier import classify_stock_bucket
        layer1_bucket, layer1_metrics = classify_stock_bucket(
            df_d, min_trading_days=min_trading_days,
        )

    _empty_result = {
        "symbol": symbol,
        "exit_mode": exit_mode,
        "daily_df": pd.DataFrame(),
        "trades": [],
        "cum_pnl": 0.0,
        "win_rate": 0.0,
        "avg_pnl_per_trade": 0.0,
        "max_drawdown": 0.0,
        "n_trades": 0,
        "sl_exits": [],
        "div_exits": [],
        "score_exits": [],
        "period_end_exits": [],
        "entries": [],
        "completed": [],
        "bucket": layer1_bucket,
        "bucket_skipped": False,  # always False — bucket is reference-only
        "bucket_metrics": layer1_metrics,
        "is_ipo": False,
        "ipo_info": ipo_info,
    }

    # ── IPO PATH: dedicated scoring ──
    is_ipo = layer1_bucket == "IPO / New Listing"
    if is_ipo:
        daily_df, daily_results, _default_trades = run_ipo_backtest(
            df_d, df_4h, start_date, end_date,
            entry_threshold=entry_threshold,
            exit_threshold=exit_threshold,
            listing_close=ipo_listing_close,
        )
    else:
        # ── MATURE STOCK PATH: existing 21-signal scoring (UNCHANGED) ──
        daily_df, daily_results, _default_trades = run_backtest(
            df_d, df_4h, df_w, start_date, end_date,
            entry_threshold=entry_threshold,
            exit_threshold=exit_threshold,
            pe=pe,
        )

    if daily_df.empty:
        return {
            **_empty_result,
            "daily_df": daily_df,
            "bucket": layer1_bucket,
            "bucket_skipped": False,
            "bucket_metrics": layer1_metrics,
            "is_ipo": is_ipo,
        }

    # (c) Extract trades with the requested exit mode
    trades = extract_trades(
        daily_results, df_d,
        exit_mode=exit_mode,
        sl_percent=sl_percent,
        trailing_sl_percent=trailing_sl_percent,
        trailing_activate_pct=trailing_activate_pct,
        divergence_rsi_drop=DIVERGENCE_RSI_DROP,
        divergence_cooldown=DIVERGENCE_COOLDOWN,
        exit_threshold=exit_threshold,
        entry_threshold=entry_threshold,
        indicator_exit=indicator_exit,
    )

    # (d) KPIs
    entries = [e for e in trades if e["type"] == "ENTRY"]
    exits = [e for e in trades if e["type"] == "EXIT"]
    completed = [e for e in exits if "pnl" in e and e.get("exit_reason") != ""]
    cum_pnl = sum(e["pnl"] for e in completed) if completed else 0.0
    winning = [e for e in completed if e["pnl"] > 0]
    win_rate = round(len(winning) / len(completed) * 100, 1) if completed else 0.0
    avg_pnl = round(cum_pnl / len(completed), 2) if completed else 0.0

    sl_exits = [
        e for e in exits
        if "HARD_SL" in e.get("exit_reason", "")
        or "TRAILING_SL" in e.get("exit_reason", "")
    ]
    div_exits = [e for e in exits if "DIVERGENCE" in e.get("exit_reason", "")]
    score_exits = [e for e in exits if "SCORE<" in e.get("exit_reason", "")]
    period_end_exits = [e for e in exits if e.get("exit_reason") == "PERIOD_END"]

    # Max drawdown from peak cumulative P&L
    pnl_series = [e["pnl"] for e in completed]
    if pnl_series:
        cum = np.cumsum(pnl_series)
        running_max = np.maximum.accumulate(cum)
        drawdowns = cum - running_max
        max_dd = round(float(min(drawdowns)) if len(drawdowns) > 0 else 0.0, 2)
    else:
        max_dd = 0.0

    # --- Price context: CMP, period low, recovery from low ---
    # daily_df's 'close' column holds the last close for each scoring day.
    # We derive CMP from the last row and the period low from df_d (full OHLCV).
    if not daily_df.empty and "close" in daily_df.columns:
        cmp = round(float(daily_df["close"].iloc[-1]), 2)
    else:
        cmp = 0.0

    # Period low from df_d within the backtesting date range
    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    period_mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    period_df = df_d.loc[period_mask]
    if not period_df.empty and "low" in period_df.columns:
        period_low = round(float(period_df["low"].min()), 2)
    else:
        period_low = 0.0

    if period_low > 0:
        recovery_pct = round((cmp - period_low) / period_low * 100, 2)
    else:
        recovery_pct = 0.0

    # Determine dominant bucket (most common non-NaN in daily_df)
    dominant_bucket = layer1_bucket
    if "bucket" in daily_df.columns:
        vc = daily_df["bucket"].dropna().value_counts()
        if len(vc) > 0:
            dominant_bucket = vc.index[0]

    return {
        "symbol": symbol,
        "exit_mode": exit_mode,
        "daily_df": daily_df,
        "raw_df_d": df_d,
        "trades": trades,
        "cum_pnl": cum_pnl,
        "win_rate": win_rate,
        "avg_pnl_per_trade": avg_pnl,
        "max_drawdown": max_dd,
        "n_trades": len(completed),
        "sl_exits": sl_exits,
        "div_exits": div_exits,
        "score_exits": score_exits,
        "period_end_exits": period_end_exits,
        "entries": entries,
        "completed": completed,
        "bucket": dominant_bucket,
        "bucket_skipped": False,
        "bucket_metrics": layer1_metrics,
        "daily_results": daily_results,
        "is_ipo": is_ipo,
        "ipo_info": ipo_info,
        "cmp": cmp,
        "period_low": period_low,
        "recovery_pct": recovery_pct,
    }

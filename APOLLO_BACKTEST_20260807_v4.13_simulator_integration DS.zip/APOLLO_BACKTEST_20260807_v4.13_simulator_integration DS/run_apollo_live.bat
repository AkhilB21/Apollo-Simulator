@echo off
REM ============================================================
REM  Apollo Live Engine v1.1 — Launcher
REM  Phase 2 Step 3 — Live dashboard (Streamlit UI)
REM ============================================================
REM
REM  Double-click this file to launch the Streamlit dashboard.
REM  The dashboard opens at http://localhost:8501 — from there
REM  you can pick a symbol, start the monitor, and confirm or
REM  dismiss exits with a click.
REM
REM  For headless CLI mode (no UI), run from a command prompt:
REM
REM      python -m live_engine --symbol CYIENTDLM --start 2024-01-01
REM
REM  For the dashboard with custom port:
REM
REM      python live_engine\run_live.py --port 8888
REM

cd /d "%~dp0"

echo.
echo === Apollo Live Engine v1.1 — Dashboard Launcher ===
echo.
echo Starting Streamlit dashboard at http://localhost:8501
echo.
echo Instructions:
echo   1. Pick a symbol (e.g., CYIENTDLM) and date range in the sidebar.
echo   2. Leave "Auto-confirm exits" UNCHECKED for human-in-the-loop mode.
echo   3. Click "Start Monitor" to begin processing bars.
echo   4. When an EXIT alert fires, click "Confirm Exit" or "Dismiss".
echo.
echo Press Ctrl+C in this window to stop the dashboard.
echo.

python live_engine\run_live.py

echo.
echo === Dashboard stopped ===
echo.
pause
